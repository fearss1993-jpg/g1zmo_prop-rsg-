#!/usr/bin/env python3
"""Build data/game_objects_list.json from femga rdr3_discoveries object_list.lua (archetype names)."""
import argparse
import json
import re
import sys
import urllib.request

DEFAULT_URL = (
    "https://raw.githubusercontent.com/femga/rdr3_discoveries/master/objects/object_list.lua"
)
LINE_RE = re.compile(r'\[\s*-?\d+\s*\]\s*=\s*"([^"]+)"')


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("out_json", help="Output path, e.g. ../data/game_objects_list.json")
    p.add_argument("--url", default=DEFAULT_URL)
    p.add_argument("--from-file", dest="from_file", help="Read local .lua instead of URL")
    args = p.parse_args()
    if args.from_file:
        with open(args.from_file, "r", encoding="utf-8", errors="replace") as f:
            raw = f.read()
    else:
        req = urllib.request.Request(args.url, headers={"User-Agent": "vorp_prop_gizmo/1.0"})
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read().decode("utf-8", errors="replace")
    names = sorted(set(LINE_RE.findall(raw)))
    doc = {
        "_meta": {
            "source": args.from_file or args.url,
            "count": len(names),
        },
        "names": names,
    }
    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, separators=(",", ":"))
    print(f"Wrote {len(names)} names to {args.out_json}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
