(function () {
    var resourceName = 'rsg_prop_gizmo';
    var catalogTree = {};
    var allProps = [];
    var currentView = 'all';
    var categoryCatKey = null;
    var categorySubKey = null;
    var placedList = [];
    var placedPage = 1;
    var placedPageSize = 100;
    /** '' = all; '__none__' = props not in any folder; else folder id */
    var placedFolderFilter = '';
    /** Server-synced folders: { id, name, propIds: [] } */
    var placedFolders = [];
    var playerSkinSelectedModel = null;
    var catalogPage = 1;
    var catalogPageSize = 120;
    var favoritesCache = [];
    var searchQuery = '';
    var thumbBase = '';
    var lang = 'ru';
    var skinRosterCache = { online: [], history: [] };
    /** Match site: categories nested under “Spooni Props”. */
    var wrapSpooniRoot = true;
    /** If wrap on: start with Spooni group expanded. */
    var spooniRootExpanded = true;
    var pedsCatalog = [];
    var blipsCatalog = [];
    var blipNameToRow = {};
    var animationsScenarios = {};
    var animationsClips = {};
    var pairSlotA = null;
    var pairSlotB = null;
    var animPickerMode = 'scenario';
    var animCategoryKey = '';
    var redLookupBaseUrl = 'https://redlookup.com';
    var redLookupPedImageUrl = '';
    var redLookupBlipImageUrl = '';
    /** null = not loaded yet; [] = loaded empty / failed */
    var gameObjectsCatalog = null;
    var gameObjectsListAvailable = false;
    var freeCamEnabled = true;
    var savedPlacedSetsEnabled = true;
    var savedPlacedSetNames = [];
    var assembliesEnabled = true;
    var ymapEnabled = true;
    var ymapExportNames = [];
    var placedSelectedPropIds = {};
    var gameObjectsListPath = 'data/game_objects_list.json';
    var gameObjectsFetchInProgress = false;

    var textModalResolve = null;
    var confirmModalResolve = null;

    /** Legacy prop-only favorites key (migrated once). */
    var FAV_KEY = 'prop_gizmo_favorites';
    /** Unified: entries like prop:name, ped:name, blip:name */
    var FAV_UNIFIED_KEY = 'prop_gizmo_favorites_unified';
    var I18N = {
        en: {
            categories: 'Categories',
            allProps: 'All Props',
            favorites: 'Favorites',
            peds: 'Peds',
            blips: 'Blips',
            placed: 'Placed',
            spawnPed: 'Spawn',
            title: 'Props Gallery',
            searchPlaceholder: 'Search props, peds, blips…',
            placement: 'Placement',
            move: 'Move',
            speed: 'Speed',
            freeMove: 'Free move (WASD + mouse + V)',
            rotate: 'Rotate (Z)',
            height: 'Height',
            pitch: 'Pitch',
            roll: 'Roll',
            place: 'Place',
            resetPosition: 'Reset position',
            cancel: 'Cancel',
            hintEsc: 'ESC - cancel. Hold LMB on move buttons.',
            noPreview: 'No preview',
            copy: 'Copy',
            placeBtn: 'Place',
            nothingFound: 'Nothing found.',
            noPlacedYet: 'No placed props, blips, or spawned peds yet.',
            noSearchPlaced: 'No matches for your search.',
            pedBadge: 'Ped',
            pedImmortal: 'Immortal',
            pedFrozen: 'Frozen in place',
            pedMissing: 'not in world',
            tableModel: 'Model',
            tableCoords: 'Coords',
            teleport: 'Teleport',
            copyCoords: 'Copy coords',
            del: 'Delete',
            copied: 'Copied',
            copyFailed: 'Copy failed',
            prev: 'Prev',
            next: 'Next',
            page: 'Page',
            propsTotal: 'Props',
            playerSkinNav: 'Player skin',
            playerSkinTitle: 'Player skin',
            playerSkinHint: 'Type a ped name below and/or pick a card, then Save & apply. Target: leave both empty = you; or server id (number from scoreboard); or full steam:… from F8 (hex after steam:). "Select" only picks a card — it does not change your ped until you press Save & apply. May conflict with vorp_character / multichar.',
            playerSkinSteamPh: 'steam:1100001ab… (optional, full from F8)',
            playerSkinServerIdPh: 'Server id (optional)',
            playerSkinModelPh: 'Ped model e.g. a_c_horse_01',
            playerSkinSelected: 'Selected',
            playerSkinApply: 'Save & apply',
            playerSkinDelete: 'Delete skin',
            playerSkinTargetSelf: 'Who: you (your character)',
            playerSkinTargetId: 'Who: server player #',
            playerSkinTargetSteam: 'Who: Steam',
            placedFolderFilter: 'Folder filter',
            placedFolderAll: 'All',
            placedFolderNone: 'Not in any folder',
            placedFolderCol: 'Folders',
            placedNewFolder: 'New folder',
            placedPickFolder: 'Add prop to folder…',
            placedDeleteFolder: 'Delete folder',
            placedRemoveFromFolder: 'Remove from this folder',
            skinSelect: 'Select',
            placedActions: 'Actions',
            folderNamePrompt: 'Folder name',
            folderDeleteConfirm: 'Delete this folder? Props stay in the world.',
            modalOk: 'OK',
            modalCancel: 'Cancel',
            skinRosterTitle: 'Who has a saved skin',
            skinRosterOnline: 'Online (saved skin)',
            skinRosterHistory: 'Recent assignments',
            skinRosterRefresh: 'Refresh list',
            skinRosterColTime: 'Time',
            skinRosterColAdmin: 'By',
            skinRosterColPlayer: 'Player',
            skinRosterColModel: 'Model',
            skinRosterColName: 'Name',
            skinRosterColId: 'Server ID',
            skinRosterColActions: '\u00a0',
            skinRosterDeleteSkin: 'Remove saved skin for this player',
            skinRosterEmpty: 'No data yet.',
            animsNav: 'Scenes',
            gameObjectsNav: 'Game objects',
            gameObjectsTitle: 'Game objects (names list)',
            gameObjectsLoading: 'Loading object name list…',
            gameObjectsEmpty: 'No list or failed to load. Run: py -3 tools/gen_game_objects_list.py data/game_objects_list.json',
            freecamNav: 'Camera',
            freecamTitle: 'Free camera',
            freecamLead: 'Fly with a scripted camera: move, look, change speed — built into this resource only.',
            freecamBullets: 'W/A/S/D — move on the ground plane¤Mouse — look¤Space / Jump — up¤Shift / Sprint — down¤Mouse wheel or Page Up/Down — speed¤Del — exit flight¤F6 — toggle while the menu is closed',
            freecamNote: 'Activate closes this menu so the game receives keys. Open /gizmo again to return (flight stops automatically).',
            freecamActivate: 'Activate free camera',
            animsScenarios: 'Scenarios',
            animsClips: 'Clips',
            animsCategory: 'Category',
            animsSlotA: 'Ped A',
            animsSlotB: 'Ped B',
            animsOnA: 'On A',
            animsOnB: 'On B',
            animsMove: 'Move',
            animsExportPair: 'Export pair JSON',
            animsImportPair: 'Import pair JSON',
            animsExportProps: 'Export props JSON',
            animsImportTitle: 'Paste pair JSON',
            animsEmpty: 'No animation catalog. Check data/animations_catalog.json.',
            placedSetSlotA: '→A',
            placedSetSlotB: '→B',
            placedPedMove: 'Move',
            animsHowTo: 'How to use a scenario on an NPC: 1) Peds — spawn the ped. 2) Placed — paste scenario name in the field on that row, press «Scenario», or use →A/→B then the manual field on Scenes. Many scenarios need a chair/zone in the world.',
            animsManualScenario: 'Scenario name:',
            pedScenarioPh: 'e.g. WORLD_HUMAN_SMOKE',
            pedScenarioApply: 'Scenario',
            animsListFileHint: 'No cards here — use the text field above or next to the ped in Placed. List of names (~538 lines, NPC-friendly): rsg_prop_gizmo/data/scenario_types_reference.txt on the server/PC.',
            animsEmptyClips: 'No clips in this category.',
            exportPropsHint: 'Export props JSON: copies all world props this client knows from the server (placed_props_sync). To move only two props to another server: export, open the JSON, delete extra lines in the props array until two objects remain, then paste into your importer or place manually on the other server.',
            placedSavedSetsLabel: 'Local sets',
            placedSavedSetSave: 'Save current props…',
            placedSavedSetLoad: 'Apply set',
            placedSavedSetReplace: 'Replace all server props',
            placedSavedSetDelete: 'Delete set',
            placedSavedSetHint:
                'Presets live in RedM client KVP on this PC only (not in placed_props_sync.json). Names: Latin letters, digits, _ and -. Apply adds props for everyone; replace wipes all synced props first — dangerous.',
            placedSavedSetNamePrompt: 'Set name',
            placedSavedSetDeleteConfirm: 'Delete saved set «[[name]]» from this PC?',
            placedSavedSetReplaceWarn:
                'This will REMOVE every synced prop on the server world, then place the preset. Folder links are cleared. Continue?',
            assemblySelectCol: '✓',
            assemblyToolbarHint:
                'Tick two or more synced props → create an assembly → use «Move assembly» to drag/rotate them as one rigid group. Saved to server with your world props.',
            assemblyCreateFromSelection: 'Create assembly from selection',
            assemblyClearSelection: 'Clear ticks',
            assemblyDissolveSelected: 'Dissolve selected assembly',
            assemblyDissolveConfirm: 'Dissolve this assembly on the server for everyone? Props stay; only the link is removed.',
            assemblyMoveGroup: 'Move assembly',
            assemblyLeaveGroup: 'Leave assembly',
            assemblyBarLabel: 'Assemblies',
            placedPropGroupCol: 'Export group',
            ymapBarLabel: 'YMAP (CodeWalker)',
            ymapScopeAll: 'All props',
            ymapScopeGroup: 'By export group',
            ymapScopeFolder: 'By folder',
            ymapScopeSelection: 'Ticked only',
            ymapFileNamePh: 'file name (e.g. dock_ferry)',
            ymapAssignGroupPh: 'group name',
            ymapAssignGroupBtn: 'Set group on ticked',
            ymapExportBtn: 'Export YMAP → disk + clipboard',
            ymapImportBtn: 'Import YMAP from text',
            ymapLoadDiskBtn: 'Import from disk',
            ymapImportTitle: 'Paste YMAP XML',
            ymapImportReplace: 'Replace all server props first',
            ymapHint:
                '1) Tick props → enter group name → «Set group on ticked». 2) Scope «By export group» → same name → Export. File: rsg_prop_gizmo/exports/ymap/name.ymap.xml. Open in CodeWalker → export binary .ymap for stream resource.',
            ymapExportCopied: 'YMAP XML copied to clipboard.',
            manualPropLabel: 'Custom prop',
            manualPedLabel: 'Custom ped',
            manualPropPlace: 'Place in world',
            manualPropPh: 'Drawable name only (not .ytd / +hidr), e.g. pai_01_home_hd',
            manualPedPh: 'e.g. a_m_m_skpclerk_01',
            manualBarHint: 'Not in the catalog? Use drawable id only — .ytd and +hidr are files; the game binds textures when the ydr/ytyp streams. Also 0x… / digits or prefix_0xHASH from CodeWalker.',
        },
        ru: {
            categories: 'Категории',
            allProps: 'Все пропы',
            favorites: 'Избранное',
            peds: 'Педы',
            blips: 'Блипы',
            placed: 'Установленные',
            spawnPed: 'Спавн',
            title: 'Галерея пропов',
            searchPlaceholder: 'Поиск пропов, педов, блипов…',
            placement: 'Размещение',
            move: 'Движение',
            speed: 'Скорость',
            freeMove: 'Свободное управление (WASD + мышь + V)',
            rotate: 'Поворот (Z)',
            height: 'Высота',
            pitch: 'Наклон',
            roll: 'Крен',
            place: 'Установить',
            resetPosition: 'Сброс позиции',
            cancel: 'Отмена',
            hintEsc: 'ESC - отмена. Удерживайте ЛКМ на кнопках движения.',
            noPreview: 'Нет превью',
            copy: 'Копировать',
            placeBtn: 'Установить',
            nothingFound: 'Ничего не найдено.',
            noPlacedYet: 'Пока нет пропов, блипов или заспавненных педов.',
            noSearchPlaced: 'Нет совпадений по поиску.',
            pedBadge: 'Пед',
            pedImmortal: 'Бессмертный',
            pedFrozen: 'Заморожен на месте',
            pedMissing: 'нет в мире',
            tableModel: 'Модель',
            tableCoords: 'Координаты',
            teleport: 'Телепорт',
            copyCoords: 'Копировать координаты',
            del: 'Удалить',
            copied: 'Скопировано',
            copyFailed: 'Не удалось скопировать',
            prev: 'Назад',
            next: 'Далее',
            page: 'Страница',
            propsTotal: 'Пропов',
            playerSkinNav: 'Скин игрока',
            playerSkinTitle: 'Скин игрока',
            playerSkinHint: 'Введите имя педа ниже и/или выберите карточку, затем «Сохранить и применить». Цель: оба поля пусты = вы; или id игрока на сервере; или полный steam:… из F8 (после steam: буквы a–f). «Выбрать» только отмечает карточку — модель не применится, пока не нажмёте «Сохранить и применить». Может конфликтовать с vorp_character / multichar.',
            playerSkinSteamPh: 'steam:1100001ab… (необязательно, целиком из F8)',
            playerSkinServerIdPh: 'ID игрока на сервере (необязательно)',
            playerSkinModelPh: 'Модель педа, напр. a_c_horse_01',
            playerSkinSelected: 'Выбрано',
            playerSkinApply: 'Сохранить и применить',
            playerSkinDelete: 'Удалить скин',
            playerSkinTargetSelf: 'Кому: вы сами',
            playerSkinTargetId: 'Кому: игрок с ID сервера ',
            playerSkinTargetSteam: 'Кому: ',
            placedFolderFilter: 'Фильтр папки',
            placedFolderAll: 'Все',
            placedFolderNone: 'Без папки',
            placedFolderCol: 'Папки',
            placedNewFolder: 'Новая папка',
            placedPickFolder: 'Добавить проп в папку…',
            placedDeleteFolder: 'Удалить папку',
            placedRemoveFromFolder: 'Убрать из этой папки',
            skinSelect: 'Выбрать',
            placedActions: 'Действия',
            folderNamePrompt: 'Имя папки',
            folderDeleteConfirm: 'Удалить папку? Пропы в мире останутся.',
            modalOk: 'ОК',
            modalCancel: 'Отмена',
            skinRosterTitle: 'Кому выдан скин',
            skinRosterOnline: 'Сейчас онлайн (есть сохранённый скин)',
            skinRosterHistory: 'Последние назначения',
            skinRosterRefresh: 'Обновить список',
            skinRosterColTime: 'Время',
            skinRosterColAdmin: 'Кто выдал',
            skinRosterColPlayer: 'Игрок',
            skinRosterColModel: 'Модель',
            skinRosterColName: 'Имя',
            skinRosterColId: 'ID сервера',
            skinRosterColActions: '\u00a0',
            skinRosterDeleteSkin: 'Снять сохранённый скин с этого игрока',
            skinRosterEmpty: 'Пока нет данных.',
            animsNav: 'Сцены',
            gameObjectsNav: 'Объекты игры',
            gameObjectsTitle: 'Объекты игры (список имён)',
            gameObjectsLoading: 'Загрузка списка имён…',
            gameObjectsEmpty: 'Нет файла или ошибка загрузки. Сгенерируйте: py -3 tools/gen_game_objects_list.py data/game_objects_list.json',
            freecamNav: 'Камера',
            freecamTitle: 'Свободная камера',
            freecamLead: 'Режим полёта на скриптовой камере: движение, обзор, скорость — всё внутри этого ресурса.',
            freecamBullets: 'W/A/S/D — движение по горизонтали¤Мышь — обзор¤Пробел / прыжок — вверх¤Shift / спринт — вниз¤Колёсико или PgUp/PgDn — скорость¤Del — выйти из полёта¤F6 — переключить при закрытом меню',
            freecamNote: '«Активировать» закроет меню, иначе клавиши не дойдут до камеры. Снова /gizmo — вернуться (полёт остановится сам).',
            freecamActivate: 'Активировать свободную камеру',
            animsScenarios: 'Сценарии',
            animsClips: 'Клипы',
            animsCategory: 'Категория',
            animsSlotA: 'Пед A',
            animsSlotB: 'Пед B',
            animsOnA: 'На A',
            animsOnB: 'На B',
            animsMove: 'Двигать',
            animsExportPair: 'Экспорт пары (JSON)',
            animsImportPair: 'Импорт пары (JSON)',
            animsExportProps: 'Экспорт пропов (JSON)',
            animsImportTitle: 'Вставьте JSON пары',
            animsEmpty: 'Нет каталога анимаций. Проверьте data/animations_catalog.json.',
            placedSetSlotA: '→A',
            placedSetSlotB: '→B',
            placedPedMove: 'Двигать',
            animsHowTo: 'Как включить сцену у NPC: 1) «Педы» — заспавни. 2) «Установленные» — в поле у этой строки вставь имя сценария (как в справочнике) и нажми «Сценарий». Либо →A/→B и в «Сцены» введи имя сверху и «На A»/«На B». Часть сцен нуждается в стуле/зоне в мире.',
            animsManualScenario: 'Имя сценария:',
            pedScenarioPh: 'напр. WORLD_HUMAN_SMOKE',
            pedScenarioApply: 'Сценарий',
            animsListFileHint: 'Карточек нет — введите имя в поле выше или у педа в «Установленные». Список имён (~538 строк, под NPC): файл rsg_prop_gizmo/data/scenario_types_reference.txt на машине с сервером.',
            animsEmptyClips: 'В этой категории нет клипов.',
            exportPropsHint: 'Экспорт пропов JSON — копирует все пропы мира, которые знает клиент (как на сервере placed_props_sync). Чтобы перенести только два пропа: экспортируйте JSON, откройте файл, в массиве props оставьте только два объекта с нужными model/x/y/z/heading, остальное удалите; на другом сервере вставьте через свой импорт или расставьте вручную по координатам.',
            placedSavedSetsLabel: 'Локальные наборы',
            placedSavedSetSave: 'Сохранить текущие пропы…',
            placedSavedSetLoad: 'Применить набор',
            placedSavedSetReplace: 'Заменить все пропы на сервере',
            placedSavedSetDelete: 'Удалить набор',
            placedSavedSetHint:
                'Пресеты хранятся в KVP клиента RedM на этом ПК (не в placed_props_sync.json). Имя набора: латиница, цифры, _ и -. Применить — добавить пропы всем; замена сначала удаляет синхронные пропы сервера — опасно.',
            placedSavedSetNamePrompt: 'Имя набора',
            placedSavedSetDeleteConfirm: 'Удалить сохранённый набор «[[name]]» с этого ПК?',
            placedSavedSetReplaceWarn:
                'Будут УДАЛЕНЫ все синхронные пропы в мире сервера, затем установлен этот пресет. Папки сбросятся. Продолжить?',
            assemblySelectCol: '✓',
            assemblyToolbarHint:
                'Отметьте два и больше синхронных пропов → «Создать сборку» → «Двигать сборку» переносит и крутит их как один жёсткий блок. Сервер сохраняет связь.',
            assemblyCreateFromSelection: 'Создать сборку из отмеченных',
            assemblyClearSelection: 'Снять отметки',
            assemblyDissolveSelected: 'Расформировать выбранную сборку',
            assemblyDissolveConfirm: 'Убрать связь сборки для всех? Пропы останутся — только связь удалится.',
            assemblyMoveGroup: 'Двигать сборку',
            assemblyLeaveGroup: 'Из сборки',
            assemblyBarLabel: 'Сборки',
            placedPropGroupCol: 'Группа экспорта',
            ymapBarLabel: 'YMAP (CodeWalker)',
            ymapScopeAll: 'Все пропы',
            ymapScopeGroup: 'По группе экспорта',
            ymapScopeFolder: 'По папке',
            ymapScopeSelection: 'Только отмеченные',
            ymapFileNamePh: 'имя файла (напр. dock_ferry)',
            ymapAssignGroupPh: 'имя группы',
            ymapAssignGroupBtn: 'Группа на отмеченные',
            ymapExportBtn: 'Экспорт YMAP → диск + буфер',
            ymapImportBtn: 'Импорт YMAP из текста',
            ymapLoadDiskBtn: 'Импорт с диска',
            ymapImportTitle: 'Вставьте YMAP XML',
            ymapImportReplace: 'Сначала удалить все пропы сервера',
            ymapHint:
                '1) Отметьте пропы → имя группы → «Группа на отмеченные». 2) Область «По группе» → то же имя → Экспорт. Файл: rsg_prop_gizmo/exports/ymap/имя.ymap.xml. CodeWalker → бинарный .ymap → stream-ресурс.',
            ymapExportCopied: 'YMAP XML скопирован в буфер.',
            manualPropLabel: 'Проп вручную',
            manualPedLabel: 'Пед вручную',
            manualPropPlace: 'В мир',
            manualPropPh: 'Только имя drawable (не .ytd / +hidr), напр. pai_01_home_hd',
            manualPedPh: 'напр. a_m_m_skpclerk_01',
            manualBarHint: 'Нет в списке — только id drawable; .ytd и +hidr — файлы, не имя модели: текстуры подтянутся сами при stream. Либо 0x… / цифры / префикс_0xХЭШ из CodeWalker.',
        }
    };

    function tr(key) {
        var dict = I18N[lang] || I18N.en;
        return dict[key] || (I18N.en[key] || key);
    }

    function copyTextToClipboard(text, onDone) {
        function done(ok) {
            if (typeof onDone === 'function') onDone(ok);
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
                done(true);
            }).catch(function () {
                var ta = document.createElement('textarea');
                ta.value = text;
                ta.setAttribute('readonly', 'readonly');
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                var ok = false;
                try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
                document.body.removeChild(ta);
                done(ok);
            });
            return;
        }
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', 'readonly');
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        var ok2 = false;
        try { ok2 = document.execCommand('copy'); } catch (e2) { ok2 = false; }
        document.body.removeChild(ta);
        done(ok2);
    }

    function getRes() {
        return typeof GetParentResourceName !== 'undefined' ? GetParentResourceName() : resourceName;
    }

    function post(callbackName, data) {
        fetch('https://' + getRes() + '/' + callbackName, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data || {})
        }).catch(function () {});
    }

    function isTextModalOpen() {
        var el = document.getElementById('nui-text-modal');
        return el && !el.classList.contains('hidden');
    }

    function isConfirmModalOpen() {
        var el = document.getElementById('nui-confirm-modal');
        return el && !el.classList.contains('hidden');
    }

    function closeTextModalWithValue(value) {
        var root = document.getElementById('nui-text-modal');
        if (root) root.classList.add('hidden');
        var fn = textModalResolve;
        textModalResolve = null;
        if (typeof fn === 'function') fn(value);
    }

    function closeConfirmModalWithValue(value) {
        var root = document.getElementById('nui-confirm-modal');
        if (root) root.classList.add('hidden');
        var fn = confirmModalResolve;
        confirmModalResolve = null;
        if (typeof fn === 'function') fn(!!value);
    }

    function openTextModal(title, defaultValue) {
        return new Promise(function (resolve) {
            textModalResolve = resolve;
            var root = document.getElementById('nui-text-modal');
            var tit = document.getElementById('nui-text-modal-title');
            var inp = document.getElementById('nui-text-modal-input');
            if (tit) tit.textContent = title || '';
            if (inp) {
                inp.value = defaultValue != null ? String(defaultValue) : '';
            }
            if (root) root.classList.remove('hidden');
            if (inp) {
                setTimeout(function () {
                    inp.focus();
                    inp.select();
                }, 30);
            }
        });
    }

    function openConfirmModal(message) {
        return new Promise(function (resolve) {
            confirmModalResolve = resolve;
            var root = document.getElementById('nui-confirm-modal');
            var msg = document.getElementById('nui-confirm-modal-msg');
            if (msg) msg.textContent = message || '';
            if (root) root.classList.remove('hidden');
        });
    }

    function relabelNuiModalButtons() {
        var ok = document.getElementById('nui-text-modal-ok');
        var ca = document.getElementById('nui-text-modal-cancel');
        if (ok) ok.textContent = tr('modalOk');
        if (ca) ca.textContent = tr('modalCancel');
        var cok = document.getElementById('nui-confirm-modal-ok');
        var cca = document.getElementById('nui-confirm-modal-cancel');
        if (cok) cok.textContent = tr('modalOk');
        if (cca) cca.textContent = tr('modalCancel');
    }

    function initNuiModals() {
        relabelNuiModalButtons();
        var ok = document.getElementById('nui-text-modal-ok');
        var ca = document.getElementById('nui-text-modal-cancel');
        if (ok) ok.addEventListener('click', function () {
            var inp = document.getElementById('nui-text-modal-input');
            closeTextModalWithValue(inp ? inp.value : '');
        });
        if (ca) ca.addEventListener('click', function () {
            closeTextModalWithValue(null);
        });
        var inpEl = document.getElementById('nui-text-modal-input');
        if (inpEl) {
            inpEl.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    closeTextModalWithValue(inpEl.value);
                }
            });
        }
        var cok = document.getElementById('nui-confirm-modal-ok');
        var cca = document.getElementById('nui-confirm-modal-cancel');
        if (cok) cok.addEventListener('click', function () {
            closeConfirmModalWithValue(true);
        });
        if (cca) cca.addEventListener('click', function () {
            closeConfirmModalWithValue(false);
        });
        document.querySelectorAll('.nui-modal-backdrop').forEach(function (bd) {
            bd.addEventListener('click', function (ev) {
                var root = ev.target && ev.target.closest && ev.target.closest('.nui-modal');
                if (!root) return;
                if (root.id === 'nui-text-modal') closeTextModalWithValue(null);
                if (root.id === 'nui-confirm-modal') closeConfirmModalWithValue(false);
            });
        });
    }

    function migrateLegacyFavorites() {
        try {
            if (localStorage.getItem(FAV_UNIFIED_KEY)) return;
            var raw = localStorage.getItem(FAV_KEY);
            if (!raw) return;
            var arr = JSON.parse(raw);
            if (!Array.isArray(arr)) return;
            var next = [];
            for (var i = 0; i < arr.length; i++) {
                var m = arr[i];
                if (typeof m !== 'string' || m === '') continue;
                if (m.indexOf('prop:') === 0 || m.indexOf('ped:') === 0 || m.indexOf('blip:') === 0) {
                    next.push(m);
                } else {
                    next.push('prop:' + m);
                }
            }
            localStorage.setItem(FAV_UNIFIED_KEY, JSON.stringify(next));
        } catch (e) {}
    }

    function loadUnifiedFavorites() {
        migrateLegacyFavorites();
        try {
            var raw = localStorage.getItem(FAV_UNIFIED_KEY);
            if (!raw) return [];
            var arr = JSON.parse(raw);
            return Array.isArray(arr) ? arr : [];
        } catch (e2) {
            return [];
        }
    }

    function saveUnifiedFavorites(arr) {
        try {
            localStorage.setItem(FAV_UNIFIED_KEY, JSON.stringify(arr));
        } catch (e) {}
    }

    function refreshFavoritesCache() {
        favoritesCache = loadUnifiedFavorites();
    }

    function favEntryKey(kind, ref) {
        if (kind === 'blip' && ref && typeof ref.name === 'string') return 'blip:' + ref.name;
        if (kind === 'ped') return 'ped:' + String(ref);
        return 'prop:' + String(ref);
    }

    function isFavoriteKey(key) {
        return favoritesCache.indexOf(key) !== -1;
    }

    function toggleFavoriteKey(key) {
        var f = favoritesCache.slice();
        var i = f.indexOf(key);
        if (i === -1) f.push(key);
        else f.splice(i, 1);
        saveUnifiedFavorites(f);
        favoritesCache = f;
        render();
    }

    function matchesSearch(name) {
        if (!searchQuery) return true;
        return String(name || '').toLowerCase().indexOf(searchQuery.toLowerCase()) !== -1;
    }

    function labelCat(s) {
        if (!s) return '';
        return String(s).split(/[\s_]+/).filter(Boolean).map(function (w) {
            return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
        }).join(' ');
    }

    /** RedM/Cfx иногда отдаёт списки пропов как объект { "0": "…", "1": "…" }, не как массив. */
    function isPropIdList(v) {
        if (!v || typeof v !== 'object') return false;
        if (Array.isArray(v)) return v.every(function (x) { return typeof x === 'string'; });
        var keys = Object.keys(v);
        if (keys.length === 0) return false;
        for (var i = 0; i < keys.length; i++) {
            if (!/^\d+$/.test(keys[i])) return false;
            if (typeof v[keys[i]] !== 'string') return false;
        }
        return true;
    }

    function normalizePropList(v) {
        if (!v || typeof v !== 'object') return [];
        if (Array.isArray(v)) return v.filter(function (x) { return typeof x === 'string'; });
        return Object.keys(v)
            .filter(function (k) { return /^\d+$/.test(k); })
            .sort(function (a, b) { return Number(a) - Number(b); })
            .map(function (k) { return v[k]; })
            .filter(function (x) { return typeof x === 'string'; });
    }

    function normalizeIndexedArrayLike(v) {
        if (!v || typeof v !== 'object') return [];
        if (Array.isArray(v)) return v.slice();
        return Object.keys(v)
            .filter(function (k) { return /^\d+$/.test(k); })
            .sort(function (a, b) { return Number(a) - Number(b); })
            .map(function (k) { return v[k]; });
    }

    function normalizeStringList(v) {
        return normalizeIndexedArrayLike(v).filter(function (x) { return typeof x === 'string' && x !== ''; });
    }

    function applyRedLookupTemplate(tpl, name, sprite) {
        if (!tpl || typeof tpl !== 'string') return '';
        var enc = encodeURIComponent(name || '');
        return tpl.split('{name}').join(enc).split('{sprite}').join(sprite != null ? String(sprite) : '');
    }

    function dedupeUrls(urls) {
        var seen = {};
        var out = [];
        for (var i = 0; i < urls.length; i++) {
            var u = urls[i];
            if (!u || typeof u !== 'string' || seen[u]) continue;
            seen[u] = true;
            out.push(u);
        }
        return out;
    }

    /**
     * BryceCanyonCounty rdr3-nativedb-data uses names like a_c_deer_01x1.jpg / a_c_wolfx1.jpg (not plain _01.jpg).
     * Try jsDelivr first — often loads in NUI when raw.githubusercontent.com is blocked or finicky.
     */
    var nativedbPedRawBase = 'https://raw.githubusercontent.com/BryceCanyonCounty/rdr3-nativedb-data/master/objects/images/';
    var nativedbPedJsdBase = 'https://cdn.jsdelivr.net/gh/BryceCanyonCounty/rdr3-nativedb-data@master/objects/images/';

    function pushNativedbPedJpegs(urls, stem) {
        if (!stem) return;
        var s = String(stem).toLowerCase();
        var enc = encodeURIComponent(s);
        var bases = [nativedbPedJsdBase, nativedbPedRawBase];
        for (var bi = 0; bi < bases.length; bi++) {
            var base = bases[bi];
            urls.push(base + enc + 'x1.jpg');
            urls.push(base + s + 'x1.jpg');
            urls.push(base + enc + 'x2.jpg');
            urls.push(base + s + 'x2.jpg');
            urls.push(base + enc + 'x3.jpg');
            urls.push(base + s + 'x3.jpg');
            urls.push(base + enc + '.jpg');
            urls.push(base + s + '.jpg');
        }
    }

    function pedImageCandidates(name) {
        var raw = String(name || '').trim();
        var lo = raw.toLowerCase();
        var enc = encodeURIComponent(lo);
        var urls = [];
        pushNativedbPedJpegs(urls, lo);
        var u = applyRedLookupTemplate(redLookupPedImageUrl, raw, null);
        if (u) urls.push(u);
        var b = (redLookupBaseUrl || 'https://redlookup.com').replace(/\/$/, '');
        urls.push(b + '/_nuxt/peds/' + enc + '.webp');
        urls.push(b + '/peds/thumbnail/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/ui_textures/peds/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/peds/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/peds/' + lo + '.png');
        urls.push('img/peds/' + enc + '.png');
        urls.push('https://ui-avatars.com/api/?background=374151&color=e5e7eb&size=160&font-size=0.33&bold=true&name=' + enc);
        return dedupeUrls(urls);
    }

    function blipImageCandidates(row) {
        var n = row.name;
        var enc = encodeURIComponent(n);
        var urls = [];
        var u = applyRedLookupTemplate(redLookupBlipImageUrl, n, row.sprite);
        if (u) urls.push(u);
        var rlb = (redLookupBaseUrl || 'https://redlookup.com').replace(/\/$/, '');
        urls.push(rlb + '/_nuxt/blips/' + enc + '.webp');
        urls.push(rlb + '/blips/thumbnail/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/ui_textures_no_bg/blips_mp/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/ui_textures/blips_mp/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/ui_textures_no_bg/blips/' + enc + '.png');
        urls.push('https://femga.com:8080/images/samples/ui_textures/blips/' + enc + '.png');
        urls.push('img/blips/' + enc + '.png');
        return dedupeUrls(urls);
    }

    function propImageSrc(model) {
        if (thumbBase) {
            return thumbBase + '/' + encodeURIComponent(model) + '.webp';
        }
        return 'img/' + encodeURIComponent(model) + '.png';
    }

    function renderAnimsToolbarAndGrid() {
        var tb = document.getElementById('anims-toolbar');
        var grid = document.getElementById('anims-grid');
        if (!tb || !grid) return;
        tb.innerHTML = '';
        var slotLine = function (labelKey, id) {
            var sp = document.createElement('span');
            sp.className = 'anims-slot';
            sp.textContent = tr(labelKey) + ': ' + (id ? String(id) : '—');
            return sp;
        };
        tb.appendChild(slotLine('animsSlotA', pairSlotA));
        tb.appendChild(slotLine('animsSlotB', pairSlotB));

        var hasSc = Object.keys(animationsScenarios || {}).length > 0;
        var hasCl = Object.keys(animationsClips || {}).length > 0;
        if (animPickerMode === 'scenario' && !hasSc && hasCl) {
            animPickerMode = 'clips';
        }
        if (animPickerMode === 'clips' && !hasCl && hasSc) {
            animPickerMode = 'scenario';
        }

        var cust = document.createElement('div');
        cust.className = 'anims-custom-wrap';
        var labMan = document.createElement('span');
        labMan.style.color = '#aaa';
        labMan.style.marginRight = '6px';
        labMan.textContent = tr('animsManualScenario');
        var inpC = document.createElement('input');
        inpC.type = 'text';
        inpC.className = 'anims-scenario-manual-inp';
        inpC.placeholder = tr('pedScenarioPh');
        inpC.setAttribute('autocomplete', 'off');
        cust.appendChild(labMan);
        cust.appendChild(inpC);
        [['a', tr('animsOnA')], ['b', tr('animsOnB')]].forEach(function (slot) {
            var bx = document.createElement('button');
            bx.type = 'button';
            bx.className = 'btn-anims';
            bx.textContent = slot[1];
            bx.addEventListener('click', function () {
                var v = (inpC.value || '').trim();
                if (!v) return;
                post('pedPlayScenario', { pedSlot: slot[0], scenario: v });
            });
            cust.appendChild(bx);
        });
        tb.appendChild(cust);

        var modeSel = document.createElement('select');
        modeSel.className = 'anims-cat-select';
        [['scenario', tr('animsScenarios')], ['clips', tr('animsClips')]].forEach(function (opt) {
            var o = document.createElement('option');
            o.value = opt[0];
            o.textContent = opt[1];
            modeSel.appendChild(o);
        });
        modeSel.querySelectorAll('option').forEach(function (op) {
            if (op.value === 'scenario') op.disabled = !hasSc;
            if (op.value === 'clips') op.disabled = !hasCl;
        });
        modeSel.value = animPickerMode;
        modeSel.addEventListener('change', function () {
            animPickerMode = modeSel.value;
            var keys = animPickerMode === 'scenario'
                ? Object.keys(animationsScenarios).sort()
                : Object.keys(animationsClips).sort();
            animCategoryKey = keys[0] || '';
            renderAnimsToolbarAndGrid();
        });
        tb.appendChild(modeSel);

        var catKeys = animPickerMode === 'scenario'
            ? Object.keys(animationsScenarios).sort()
            : Object.keys(animationsClips).sort();
        if (animCategoryKey && catKeys.indexOf(animCategoryKey) === -1) {
            animCategoryKey = catKeys[0] || '';
        }
        var catSel = document.createElement('select');
        catSel.className = 'anims-cat-select';
        catKeys.forEach(function (ck) {
            var o = document.createElement('option');
            o.value = ck;
            o.textContent = ck;
            catSel.appendChild(o);
        });
        if (catKeys.length === 0) {
            var oz = document.createElement('option');
            oz.value = '';
            oz.textContent = '—';
            catSel.appendChild(oz);
            catSel.disabled = true;
        } else {
            catSel.disabled = false;
        }
        catSel.value = animCategoryKey || catKeys[0] || '';
        animCategoryKey = catSel.value;
        catSel.addEventListener('change', function () {
            animCategoryKey = catSel.value;
            renderAnimsToolbarAndGrid();
        });
        var labCat = document.createElement('span');
        labCat.style.color = '#888';
        labCat.textContent = tr('animsCategory');
        tb.appendChild(labCat);
        tb.appendChild(catSel);

        var bEx = document.createElement('button');
        bEx.type = 'button';
        bEx.className = 'btn-anims';
        bEx.textContent = tr('animsExportPair');
        bEx.addEventListener('click', function () { post('exportPairScene', {}); });
        tb.appendChild(bEx);
        var bIm = document.createElement('button');
        bIm.type = 'button';
        bIm.className = 'btn-anims';
        bIm.textContent = tr('animsImportPair');
        bIm.addEventListener('click', function () {
            openTextModal(tr('animsImportTitle'), '').then(function (txt) {
                if (txt && String(txt).trim()) post('importPairScene', { json: String(txt).trim() });
            });
        });
        tb.appendChild(bIm);
        var bEp = document.createElement('button');
        bEp.type = 'button';
        bEp.className = 'btn-anims';
        bEp.textContent = tr('animsExportProps');
        bEp.addEventListener('click', function () { post('exportPlacedPropsJson', {}); });
        tb.appendChild(bEp);

        var how = document.createElement('div');
        how.className = 'anims-howto';
        how.textContent = tr('animsHowTo');
        tb.appendChild(how);
        var how2 = document.createElement('div');
        how2.className = 'anims-howto';
        how2.style.borderTop = 'none';
        how2.style.paddingTop = '2px';
        how2.textContent = tr('exportPropsHint');
        tb.appendChild(how2);

        grid.innerHTML = '';
        var q = (searchQuery || '').toLowerCase().trim();
        var gridCount = 0;
        if (animPickerMode === 'scenario') {
            var list = animationsScenarios[animCategoryKey] || [];
            list.forEach(function (sc) {
                if (!sc || typeof sc !== 'string') return;
                if (q && sc.toLowerCase().indexOf(q) === -1) return;
                var card = document.createElement('div');
                card.className = 'anims-card prop-card';
                var nm = document.createElement('div');
                nm.className = 'anims-name';
                nm.textContent = sc;
                var act = document.createElement('div');
                act.className = 'anims-actions';
                [['a', tr('animsOnA')], ['b', tr('animsOnB')]].forEach(function (slot) {
                    var b1 = document.createElement('button');
                    b1.type = 'button';
                    b1.className = 'btn-anims';
                    b1.textContent = slot[1];
                    b1.addEventListener('click', function () {
                        post('pedPlayScenario', { pedSlot: slot[0], scenario: sc });
                    });
                    act.appendChild(b1);
                });
                [['a', 'A'], ['b', 'B']].forEach(function (slot) {
                    var bm = document.createElement('button');
                    bm.type = 'button';
                    bm.className = 'btn-anims';
                    bm.textContent = tr('animsMove') + ' ' + slot[1];
                    bm.addEventListener('click', function () {
                        post('beginPedAdjust', { pedSlot: slot[0] });
                    });
                    act.appendChild(bm);
                });
                card.appendChild(nm);
                card.appendChild(act);
                grid.appendChild(card);
                gridCount += 1;
            });
        } else {
            var clips = animationsClips[animCategoryKey] || [];
            clips.forEach(function (row) {
                if (!row || typeof row.dict !== 'string') return;
                var line = (row.label || '') + ' ' + row.dict + ' / ' + row.anim;
                if (q && line.toLowerCase().indexOf(q) === -1) return;
                var card = document.createElement('div');
                card.className = 'anims-card prop-card';
                var nm = document.createElement('div');
                nm.className = 'anims-name';
                nm.textContent = row.label ? (row.label + '\n') : '';
                nm.textContent += row.dict + '\n' + row.anim;
                var act = document.createElement('div');
                act.className = 'anims-actions';
                [['a', tr('animsOnA')], ['b', tr('animsOnB')]].forEach(function (slot) {
                    var b1 = document.createElement('button');
                    b1.type = 'button';
                    b1.className = 'btn-anims';
                    b1.textContent = slot[1];
                    b1.addEventListener('click', function () {
                        post('pedPlayClip', { pedSlot: slot[0], dict: row.dict, anim: row.anim });
                    });
                    act.appendChild(b1);
                });
                [['a', 'A'], ['b', 'B']].forEach(function (slot) {
                    var bm = document.createElement('button');
                    bm.type = 'button';
                    bm.className = 'btn-anims';
                    bm.textContent = tr('animsMove') + ' ' + slot[1];
                    bm.addEventListener('click', function () {
                        post('beginPedAdjust', { pedSlot: slot[0] });
                    });
                    act.appendChild(bm);
                });
                card.appendChild(nm);
                card.appendChild(act);
                grid.appendChild(card);
                gridCount += 1;
            });
        }
        if (gridCount === 0) {
            var hint = document.createElement('div');
            hint.style.color = '#777';
            hint.style.padding = '14px';
            hint.style.fontSize = '12px';
            hint.style.lineHeight = '1.45';
            hint.textContent = animPickerMode === 'scenario' ? tr('animsListFileHint') : tr('animsEmptyClips');
            grid.appendChild(hint);
        }
    }

    function updateNavActive() {
        document.querySelectorAll('#sidebar-nav .nav-btn').forEach(function (b) {
            var v = b.getAttribute('data-view');
            var active = false;
            if (currentView === 'category' && v === 'category') {
                active = b.getAttribute('data-cat') === categoryCatKey && b.getAttribute('data-sub') === categorySubKey;
            } else if (currentView !== 'category' && v === currentView && !b.getAttribute('data-cat')) {
                active = true;
            }
            b.classList.toggle('active', active);
        });
        updateTitleLogos();
    }

    /** Gizmo logo by default; Spooni (старый) логотип — только в режиме подкатегории каталога (как на скрине: Fireplace и т.д.). */
    function updateTitleLogos() {
        var gizmo = document.getElementById('title-logo-gizmo');
        var spooni = document.getElementById('title-logo-spooni');
        if (!gizmo || !spooni) return;
        var useSpooni = currentView === 'category';
        gizmo.classList.toggle('hidden', useSpooni);
        spooni.classList.toggle('hidden', !useSpooni);
    }

    function refreshMainTitle() {
        var title = document.querySelector('.title');
        if (title) {
            var t =
                currentView === 'gameobjects'
                    ? tr('gameObjectsTitle')
                    : currentView === 'freecam'
                      ? tr('freecamTitle')
                      : tr('title');
            title.textContent = t;
        }
    }

    function buildFreecamHelpPanel() {
        var lead = document.getElementById('freecam-lead');
        var list = document.getElementById('freecam-list');
        var note = document.getElementById('freecam-note');
        var btn = document.getElementById('freecam-activate');
        if (!lead || !list || !note || !btn) return;
        lead.textContent = tr('freecamLead');
        note.textContent = tr('freecamNote');
        btn.textContent = tr('freecamActivate');
        list.innerHTML = '';
        String(tr('freecamBullets') || '')
            .split(/\u00A4/)
            .map(function (s) {
                return s.trim();
            })
            .filter(Boolean)
            .forEach(function (line) {
                var li = document.createElement('li');
                li.textContent = line;
                list.appendChild(li);
            });
    }

    function applyStaticI18n() {
        var sidebarHead = document.querySelector('.sidebar-head');
        if (sidebarHead) sidebarHead.textContent = tr('categories');
        var bAll = document.querySelector('#sidebar-nav .nav-btn[data-view="all"]');
        if (bAll) bAll.textContent = tr('allProps');
        var bFav = document.querySelector('#sidebar-nav .nav-btn[data-view="favorites"]');
        if (bFav) bFav.textContent = tr('favorites');
        var bPeds = document.querySelector('#sidebar-nav .nav-btn[data-view="peds"]');
        if (bPeds) bPeds.textContent = tr('peds');
        var bBlips = document.querySelector('#sidebar-nav .nav-btn[data-view="blips"]');
        if (bBlips) bBlips.textContent = tr('blips');
        var bGame = document.getElementById('nav-btn-gameobjects');
        if (bGame) bGame.textContent = tr('gameObjectsNav');
        var bAnims = document.querySelector('#sidebar-nav .nav-btn[data-view="anims"]');
        if (bAnims) bAnims.textContent = tr('animsNav');
        var bPlaced = document.querySelector('#sidebar-nav .nav-btn[data-view="placed"]');
        if (bPlaced) bPlaced.textContent = tr('placed');
        var bSkin = document.querySelector('#sidebar-nav .nav-btn[data-view="playerSkin"]');
        if (bSkin) bSkin.textContent = tr('playerSkinNav');
        var bFreecam = document.getElementById('nav-btn-freecam');
        if (bFreecam) bFreecam.textContent = tr('freecamNav');
        refreshMainTitle();
        var search = document.getElementById('search-input');
        if (search) search.placeholder = tr('searchPlaceholder');
        var pTitle = document.querySelector('.placement-title');
        if (pTitle) pTitle.textContent = tr('placement');
        var labels = document.querySelectorAll('.pl-label');
        if (labels[0]) labels[0].textContent = tr('move');
        if (labels[1]) labels[1].textContent = tr('speed');
        if (labels[2]) labels[2].textContent = tr('rotate');
        if (labels[3]) labels[3].textContent = tr('height');
        if (labels[4]) labels[4].textContent = tr('pitch');
        if (labels[5]) labels[5].textContent = tr('roll');
        var freeMoveLabel = document.getElementById('pl-free-move-label');
        if (freeMoveLabel) freeMoveLabel.textContent = tr('freeMove');
        var c = document.getElementById('pl-confirm');
        if (c) c.textContent = tr('place');
        var r = document.getElementById('pl-reset');
        if (r) r.textContent = tr('resetPosition');
        var x = document.getElementById('pl-cancel');
        if (x) x.textContent = tr('cancel');
        var hint = document.querySelector('.pl-hint');
        if (hint) hint.textContent = tr('hintEsc');
        updateManualModelBar();
        buildFreecamHelpPanel();
    }

    function setGridOrPlaced(mode) {
        var gridWrap = document.getElementById('content-grid-wrap');
        var placedEl = document.getElementById('content-placed');
        var skinEl = document.getElementById('content-player-skin');
        var animsEl = document.getElementById('content-anims');
        var freecamEl = document.getElementById('content-freecam');
        var isPlaced = mode === 'placed';
        var isSkin = mode === 'playerSkin';
        var isAnims = mode === 'anims';
        var isFreecam = mode === 'freecam';
        var isGrid = mode === 'grid';
        if (gridWrap) gridWrap.classList.toggle('hidden', !isGrid);
        if (placedEl) placedEl.classList.toggle('hidden', !isPlaced);
        if (skinEl) skinEl.classList.toggle('hidden', !isSkin);
        if (animsEl) animsEl.classList.toggle('hidden', !isAnims);
        if (freecamEl) freecamEl.classList.toggle('hidden', !isFreecam);
        var searchInp = document.getElementById('search-input');
        if (searchInp) searchInp.classList.toggle('hidden', isFreecam);
        if (isPlaced) renderPlaced();
        if (isSkin) {
            buildPlayerSkinToolbar();
            render();
        }
        if (isAnims) renderAnimsToolbarAndGrid();
        if (isFreecam) buildFreecamHelpPanel();
        if (isGrid) render();
    }

    function setView(view) {
        currentView = view;
        categoryCatKey = null;
        categorySubKey = null;
        catalogPage = 1;
        if (view === 'placed') placedPage = 1;
        updateNavActive();
        if (view === 'placed') {
            setGridOrPlaced('placed');
        } else if (view === 'playerSkin') {
            setGridOrPlaced('playerSkin');
        } else if (view === 'anims') {
            setGridOrPlaced('anims');
        } else if (view === 'freecam') {
            setGridOrPlaced('freecam');
        } else {
            setGridOrPlaced('grid');
        }
        refreshMainTitle();
        updateManualModelBar();
    }

    function setCategoryView(cat, sub) {
        currentView = 'category';
        categoryCatKey = cat;
        categorySubKey = sub;
        catalogPage = 1;
        placedPage = 1;
        updateNavActive();
        setGridOrPlaced('grid');
        refreshMainTitle();
        updateManualModelBar();
    }

    function makeCategoryGroup(catKey, nested) {
        var subs = catalogTree[catKey];
        var subKeys = Object.keys(subs).filter(function (sk) {
            return isPropIdList(subs[sk]);
        }).sort();
        if (subKeys.length === 0) return null;
        var group = document.createElement('div');
        group.className = 'nav-group' + (nested ? ' nav-group-nested' : '');
        var toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'nav-group-toggle';
        toggle.textContent = labelCat(catKey);
        var subWrap = document.createElement('div');
        subWrap.className = 'nav-sub hidden';
        subKeys.forEach(function (subKey) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'nav-btn';
            btn.setAttribute('data-view', 'category');
            btn.setAttribute('data-cat', catKey);
            btn.setAttribute('data-sub', subKey);
            btn.textContent = labelCat(subKey);
            subWrap.appendChild(btn);
        });
        group.appendChild(toggle);
        group.appendChild(subWrap);
        return group;
    }

    function buildCategoryNav() {
        var container = document.getElementById('category-nav');
        if (!container) return;
        container.innerHTML = '';
        var keys = Object.keys(catalogTree).filter(function (k) {
            var o = catalogTree[k];
            return o && typeof o === 'object' && !Array.isArray(o);
        }).sort();
        if (keys.length === 0) return;

        if (wrapSpooniRoot) {
            var outer = document.createElement('div');
            outer.className = 'nav-group nav-spooni-root';
            var otoggle = document.createElement('button');
            otoggle.type = 'button';
            otoggle.className = 'nav-group-toggle';
            otoggle.textContent = 'Spooni Props';
            var osub = document.createElement('div');
            osub.className = 'nav-sub nav-spooni-nested hidden';
            var any = false;
            keys.forEach(function (catKey) {
                var g = makeCategoryGroup(catKey, true);
                if (g) {
                    osub.appendChild(g);
                    any = true;
                }
            });
            if (any) {
                outer.appendChild(otoggle);
                outer.appendChild(osub);
                container.appendChild(outer);
                if (spooniRootExpanded) {
                    outer.classList.add('open');
                    osub.classList.remove('hidden');
                }
                return;
            }
            /* empty catalog: draw flat */
        }

        keys.forEach(function (catKey) {
            var g = makeCategoryGroup(catKey, false);
            if (g) container.appendChild(g);
        });
    }

    function getModelsForView() {
        if (currentView === 'all') {
            return allProps.filter(matchesSearch);
        }
        if (currentView === 'favorites') {
            return favoritesCache.filter(matchesSearch);
        }
        if (currentView === 'peds') {
            return pedsCatalog.filter(matchesSearch);
        }
        if (currentView === 'playerSkin') {
            return pedsCatalog.filter(matchesSearch);
        }
        if (currentView === 'blips') {
            return blipsCatalog.filter(function (row) {
                if (!row || typeof row.name !== 'string') return false;
                if (!searchQuery) return true;
                var q = searchQuery.toLowerCase();
                var h = row.sprite != null ? String(row.sprite) : '';
                return (row.name + ' ' + h).toLowerCase().indexOf(q) !== -1;
            });
        }
        if (currentView === 'gameobjects') {
            if (!Array.isArray(gameObjectsCatalog)) return [];
            return gameObjectsCatalog.filter(matchesSearch);
        }
        if (currentView === 'category' && categoryCatKey && categorySubKey) {
            var subs = catalogTree[categoryCatKey];
            if (subs && isPropIdList(subs[categorySubKey])) {
                return normalizePropList(subs[categorySubKey]).filter(matchesSearch);
            }
        }
        return [];
    }

    function renderCard(model) {
        var isBlip = false;
        var isPed = false;
        var displayModel = model;
        var blipRow = null;
        var favStorageKey = null;

        if (currentView === 'favorites' && typeof model === 'string') {
            favStorageKey = model;
            if (model.indexOf('ped:') === 0) {
                isPed = true;
                displayModel = model.slice(4);
            } else if (model.indexOf('blip:') === 0) {
                isBlip = true;
                var bn = model.slice(5);
                blipRow = blipNameToRow[bn] || { name: bn, sprite: 0 };
                displayModel = blipRow;
            } else if (model.indexOf('prop:') === 0) {
                displayModel = model.slice(5);
            } else {
                displayModel = model;
                favStorageKey = 'prop:' + model;
            }
        } else if (currentView === 'blips') {
            isBlip = model && typeof model === 'object' && typeof model.name === 'string';
            blipRow = isBlip ? model : null;
            displayModel = model;
            favStorageKey = favEntryKey('blip', model);
        } else if (currentView === 'peds') {
            isPed = true;
            displayModel = model;
            favStorageKey = favEntryKey('ped', model);
        } else if (currentView === 'playerSkin') {
            isPed = true;
            displayModel = model;
            favStorageKey = null;
        } else {
            displayModel = model;
            favStorageKey = favEntryKey('prop', model);
        }

        var card = document.createElement('div');
        card.className = 'prop-card' + (currentView === 'playerSkin' && playerSkinSelectedModel === displayModel ? ' prop-card-selected' : '');

        var tw = document.createElement('div');
        tw.className = 'prop-thumb-wrap';
        var img = document.createElement('img');
        img.className = 'prop-thumb';
        img.alt = '';
        var extCandidates = [];
        if (isBlip && blipRow) {
            extCandidates = blipImageCandidates(blipRow);
            img.dataset.extTry = '0';
            img.src = extCandidates[0] || '';
        } else if (isPed) {
            extCandidates = pedImageCandidates(displayModel);
            img.dataset.extTry = '0';
            img.src = extCandidates[0] || '';
        } else {
            img.src = propImageSrc(displayModel);
        }
        img.onerror = function () {
            if (isBlip || isPed) {
                var ei = parseInt(img.dataset.extTry || '0', 10) + 1;
                if (ei < extCandidates.length) {
                    img.dataset.extTry = String(ei);
                    img.src = extCandidates[ei];
                    return;
                }
                img.style.display = 'none';
                if (!tw.querySelector('.prop-thumb-ph')) {
                    var phb = document.createElement('div');
                    phb.className = 'prop-thumb-ph';
                    phb.textContent = tr('noPreview');
                    tw.appendChild(phb);
                }
                return;
            }
            if (thumbBase && img.dataset.fallback !== '1') {
                img.dataset.fallback = '1';
                img.src = 'img/' + encodeURIComponent(displayModel) + '.png';
                return;
            }
            if (img.dataset.fallback === '1' && img.dataset.fallback2 !== '1') {
                img.dataset.fallback2 = '1';
                img.src = 'img/' + encodeURIComponent(displayModel) + '.webp';
                return;
            }
            img.style.display = 'none';
            if (!tw.querySelector('.prop-thumb-ph')) {
                var ph = document.createElement('div');
                ph.className = 'prop-thumb-ph';
                ph.textContent = tr('noPreview');
                tw.appendChild(ph);
            }
        };
        tw.appendChild(img);

        var bar = document.createElement('div');
        bar.className = 'prop-bar';
        var name = document.createElement('div');
        name.className = 'prop-name';
        if (isBlip && blipRow) {
            name.textContent = blipRow.name + (blipRow.sprite != null ? '  #' + blipRow.sprite : '');
        } else {
            name.textContent = displayModel;
        }

        var actions = document.createElement('div');
        actions.className = 'prop-actions';

        var btnCopy = document.createElement('button');
        btnCopy.type = 'button';
        btnCopy.className = 'btn-copy';
        btnCopy.textContent = tr('copy');
        btnCopy.addEventListener('click', function (e) {
            e.stopPropagation();
            var t = isBlip && blipRow ? (blipRow.name + ' ' + blipRow.sprite) : displayModel;
            copyTextToClipboard(t);
        });
        actions.appendChild(btnCopy);

        if (currentView !== 'playerSkin') {
            var btnFav = document.createElement('button');
            btnFav.type = 'button';
            var fk = favStorageKey || favEntryKey(isBlip ? 'blip' : (isPed ? 'ped' : 'prop'), isBlip ? blipRow : displayModel);
            btnFav.className = 'btn-fav' + (isFavoriteKey(fk) ? ' on' : '');
            btnFav.textContent = isFavoriteKey(fk) ? '★' : '☆';
            btnFav.addEventListener('click', function (e) {
                e.stopPropagation();
                toggleFavoriteKey(fk);
            });
            actions.appendChild(btnFav);
        }

        var btnPlace = document.createElement('button');
        btnPlace.type = 'button';
        btnPlace.className = 'btn-place';
        if (currentView === 'playerSkin') {
            btnPlace.textContent = tr('skinSelect');
            btnPlace.addEventListener('click', function (e) {
                e.stopPropagation();
                playerSkinSelectedModel = displayModel;
                updatePlayerSkinSelectedLabel();
                render();
            });
        } else {
            btnPlace.textContent = isPed ? tr('spawnPed') : tr('placeBtn');
            btnPlace.addEventListener('click', function (e) {
                e.stopPropagation();
                if (isBlip && blipRow) post('beginPlaceBlip', { name: blipRow.name });
                else if (isPed) post('spawnPedAtPlayer', { model: displayModel });
                else post('beginPlace', { model: displayModel });
            });
        }
        actions.appendChild(btnPlace);
        bar.appendChild(name);
        bar.appendChild(actions);
        card.appendChild(tw);
        card.appendChild(bar);
        return card;
    }

    function getActiveCatalogGrid() {
        return currentView === 'playerSkin'
            ? document.getElementById('player-skin-grid')
            : document.getElementById('props-grid');
    }

    function getActiveCatalogWrap() {
        return currentView === 'playerSkin'
            ? document.getElementById('content-grid-wrap-skin')
            : document.getElementById('content-grid-wrap');
    }

    function updatePlayerSkinSelectedLabel() {
        var el = document.getElementById('player-skin-selected-label');
        if (el) el.textContent = tr('playerSkinSelected') + ': ' + (playerSkinSelectedModel || '—');
    }

    function updatePlayerSkinTargetSummary() {
        var el = document.getElementById('player-skin-target-info');
        if (!el) return;
        var stEl = document.getElementById('player-skin-steam');
        var sidEl = document.getElementById('player-skin-server-id');
        var steamV = stEl && stEl.value ? String(stEl.value).trim() : '';
        var sidRaw = sidEl && sidEl.value ? String(sidEl.value).trim() : '';
        var sidNum = sidRaw ? parseInt(sidRaw, 10) : NaN;
        if (!isNaN(sidNum) && sidNum > 0) {
            el.textContent = tr('playerSkinTargetId') + String(sidNum);
            return;
        }
        if (steamV) {
            var disp = steamV.length > 42 ? steamV.slice(0, 39) + '…' : steamV;
            el.textContent = tr('playerSkinTargetSteam') + disp;
            return;
        }
        el.textContent = tr('playerSkinTargetSelf');
    }

    function formatSkinTs(ts) {
        if (ts == null || ts === '') return '—';
        var n = Number(ts);
        if (!Number.isFinite(n) || n <= 0) return '—';
        try {
            return new Date(n * 1000).toLocaleString('ru-RU');
        } catch (e) {
            return String(ts);
        }
    }

    function renderSkinRosterPanel(host, data) {
        if (!host) return;
        data = data || skinRosterCache;
        host.innerHTML = '';
        var h2 = document.createElement('h3');
        h2.className = 'player-skin-roster-title';
        h2.textContent = tr('skinRosterTitle');
        host.appendChild(h2);
        var bRef = document.createElement('button');
        bRef.type = 'button';
        bRef.className = 'btn-place player-skin-roster-refresh';
        bRef.textContent = tr('skinRosterRefresh');
        bRef.addEventListener('click', function () {
            post('skinRosterRefresh', {});
        });
        host.appendChild(bRef);

        function mkTable(titleKey, columns, rows, rowFn) {
            if (!rows || rows.length === 0) return;
            var sec = document.createElement('div');
            sec.className = 'player-skin-roster-section';
            var th = document.createElement('h4');
            th.textContent = tr(titleKey);
            sec.appendChild(th);
            var tbl = document.createElement('table');
            tbl.className = 'player-skin-roster-table';
            var thead = document.createElement('thead');
            var trh = document.createElement('tr');
            columns.forEach(function (col) {
                var thc = document.createElement('th');
                thc.textContent = tr(col.labelKey);
                if (col.thClass) thc.className = col.thClass;
                trh.appendChild(thc);
            });
            thead.appendChild(trh);
            tbl.appendChild(thead);
            var tbody = document.createElement('tbody');
            rows.forEach(function (row) {
                tbody.appendChild(rowFn(row));
            });
            tbl.appendChild(tbody);
            sec.appendChild(tbl);
            host.appendChild(sec);
        }

        mkTable('skinRosterOnline', [
            { labelKey: 'skinRosterColName' },
            { labelKey: 'skinRosterColId' },
            { labelKey: 'skinRosterColModel' },
            { labelKey: 'skinRosterColActions', thClass: 'player-skin-roster-th-actions' },
        ], data.online || [], function (r) {
            var trEl = document.createElement('tr');
            var td1 = document.createElement('td');
            td1.textContent = r.name || '—';
            var td2 = document.createElement('td');
            td2.textContent = r.serverId != null ? String(r.serverId) : '—';
            var td3 = document.createElement('td');
            td3.textContent = r.model || '—';
            var td4 = document.createElement('td');
            td4.className = 'player-skin-roster-cell-action';
            var sidNum = r.serverId != null ? Number(r.serverId) : NaN;
            if (!Number.isNaN(sidNum) && sidNum > 0) {
                var del = document.createElement('button');
                del.type = 'button';
                del.className = 'btn-skin-roster-delete';
                del.setAttribute('aria-label', tr('skinRosterDeleteSkin'));
                del.setAttribute('title', tr('skinRosterDeleteSkin'));
                del.innerHTML =
                    '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>';
                del.addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    post('playerSkinClear', { targetServerId: sidNum, targetSteam: '' });
                });
                td4.appendChild(del);
            } else {
                td4.textContent = '—';
            }
            trEl.appendChild(td1);
            trEl.appendChild(td2);
            trEl.appendChild(td3);
            trEl.appendChild(td4);
            return trEl;
        });

        mkTable('skinRosterHistory', [
            { labelKey: 'skinRosterColTime' },
            { labelKey: 'skinRosterColAdmin' },
            { labelKey: 'skinRosterColPlayer' },
            { labelKey: 'skinRosterColModel' },
        ], data.history || [], function (r) {
            var trEl = document.createElement('tr');
            [formatSkinTs(r.ts), r.admin || '—', r.targetName || '—', r.model || '—'].forEach(function (t) {
                var td = document.createElement('td');
                td.textContent = t;
                trEl.appendChild(td);
            });
            return trEl;
        });

        if (!host.querySelector('.player-skin-roster-section')) {
            var empty = document.createElement('p');
            empty.className = 'player-skin-roster-empty';
            empty.textContent = tr('skinRosterEmpty');
            host.appendChild(empty);
        }
    }

    function buildPlayerSkinToolbar() {
        var tb = document.getElementById('player-skin-toolbar');
        if (!tb) return;
        tb.innerHTML = '';
        var hint = document.createElement('p');
        hint.className = 'player-skin-hint';
        hint.textContent = tr('playerSkinHint');
        var row = document.createElement('div');
        row.className = 'player-skin-controls';
        var modelInp = document.createElement('input');
        modelInp.type = 'text';
        modelInp.className = 'player-skin-steam';
        modelInp.placeholder = tr('playerSkinModelPh');
        modelInp.id = 'player-skin-model-input';
        modelInp.autocomplete = 'off';
        var sidInp = document.createElement('input');
        sidInp.type = 'text';
        sidInp.inputMode = 'numeric';
        sidInp.className = 'player-skin-steam';
        sidInp.style.minWidth = '100px';
        sidInp.placeholder = tr('playerSkinServerIdPh');
        sidInp.id = 'player-skin-server-id';
        sidInp.autocomplete = 'off';
        var steam = document.createElement('input');
        steam.type = 'text';
        steam.className = 'player-skin-steam';
        steam.placeholder = tr('playerSkinSteamPh');
        steam.id = 'player-skin-steam';
        steam.autocomplete = 'off';
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn-place';
        btn.textContent = tr('playerSkinApply');
        btn.addEventListener('click', function () {
            var manual = modelInp.value ? String(modelInp.value).trim() : '';
            var model = manual || playerSkinSelectedModel;
            if (!model) return;
            var st = document.getElementById('player-skin-steam');
            var sidRaw = sidInp.value ? String(sidInp.value).trim() : '';
            var sidNum = sidRaw ? parseInt(sidRaw, 10) : NaN;
            var payload = {
                model: model,
                targetSteam: st && st.value ? String(st.value).trim() : '',
            };
            if (!isNaN(sidNum) && sidNum > 0) {
                payload.targetServerId = sidNum;
            }
            post('playerSkinApply', payload);
        });
        row.appendChild(modelInp);
        row.appendChild(sidInp);
        row.appendChild(steam);
        row.appendChild(btn);

        var targetRow = document.createElement('div');
        targetRow.className = 'player-skin-target-row';
        var info = document.createElement('div');
        info.className = 'player-skin-target-info';
        info.id = 'player-skin-target-info';
        var btnDel = document.createElement('button');
        btnDel.type = 'button';
        btnDel.className = 'btn-player-skin-delete';
        btnDel.textContent = tr('playerSkinDelete');
        btnDel.setAttribute('title', tr('playerSkinDelete'));
        btnDel.addEventListener('click', function () {
            var st = document.getElementById('player-skin-steam');
            var sidRaw = sidInp.value ? String(sidInp.value).trim() : '';
            var sidNum = sidRaw ? parseInt(sidRaw, 10) : NaN;
            var clrPayload = {
                targetSteam: st && st.value ? String(st.value).trim() : '',
            };
            if (!isNaN(sidNum) && sidNum > 0) {
                clrPayload.targetServerId = sidNum;
            }
            post('playerSkinClear', clrPayload);
        });
        targetRow.appendChild(info);
        targetRow.appendChild(btnDel);

        function onTargetFieldsInput() {
            updatePlayerSkinTargetSummary();
        }
        sidInp.addEventListener('input', onTargetFieldsInput);
        steam.addEventListener('input', onTargetFieldsInput);

        tb.appendChild(hint);
        tb.appendChild(row);
        tb.appendChild(targetRow);
        updatePlayerSkinTargetSummary();
        var rosterWrap = document.createElement('div');
        rosterWrap.id = 'player-skin-roster-wrap';
        rosterWrap.className = 'player-skin-roster-wrap';
        tb.appendChild(rosterWrap);
        renderSkinRosterPanel(rosterWrap, skinRosterCache);
        post('skinRosterRefresh', {});
    }

    function validManualModelId(s) {
        if (!s || typeof s !== 'string') return false;
        if (s.length > 128) return false;
        if (/^0[xX][0-9a-fA-F]+$/.test(s)) return true;
        if (/^\d+$/.test(s)) return true;
        return /^[\w%.+\-]+$/.test(s);
    }

    function updateManualModelBar() {
        var bar = document.getElementById('manual-model-bar');
        var inp = document.getElementById('manual-model-input');
        var btn = document.getElementById('manual-model-action');
        var lab = document.getElementById('manual-bar-label');
        var hint = document.getElementById('manual-model-hint');
        if (!bar || !inp || !btn || !lab) return;
        var isPedView = currentView === 'peds';
        var isPropLike = currentView === 'all' || currentView === 'favorites' || currentView === 'category' || currentView === 'gameobjects';
        var show = isPedView || isPropLike;
        bar.classList.toggle('hidden', !show);
        if (!show) return;
        if (isPedView) {
            lab.textContent = tr('manualPedLabel');
            btn.textContent = tr('spawnPed');
            inp.placeholder = tr('manualPedPh');
        } else {
            lab.textContent = tr('manualPropLabel');
            btn.textContent = tr('manualPropPlace');
            inp.placeholder = tr('manualPropPh');
        }
        if (hint) hint.textContent = tr('manualBarHint');
    }

    function submitManualModel() {
        var inp = document.getElementById('manual-model-input');
        if (!inp) return;
        var v = (inp.value || '').trim();
        if (!validManualModelId(v)) return;
        if (currentView === 'peds') {
            post('spawnPedAtPlayer', { model: v });
        } else {
            post('beginPlace', { model: v });
        }
    }

    function render() {
        updateManualModelBar();
        var grid = getActiveCatalogGrid();
        if (!grid) return;
        grid.innerHTML = '';
        var wrap = getActiveCatalogWrap();
        if (wrap) {
            var old = wrap.querySelector('.catalog-pagination');
            if (old) old.remove();
        }
        var models = getModelsForView();
        if (models.length === 0) {
            var empty = document.createElement('div');
            empty.style.gridColumn = '1 / -1';
            empty.style.color = '#666';
            empty.style.padding = '24px';
            empty.style.lineHeight = '1.45';
            empty.style.fontSize = '13px';
            if (currentView === 'gameobjects') {
                if (gameObjectsCatalog === null) {
                    empty.textContent = tr('gameObjectsLoading');
                } else {
                    empty.textContent = searchQuery ? tr('nothingFound') : tr('gameObjectsEmpty');
                }
            } else {
                empty.textContent = tr('nothingFound');
            }
            grid.appendChild(empty);
            return;
        }
        var pageCount = Math.max(1, Math.ceil(models.length / catalogPageSize));
        if (catalogPage > pageCount) catalogPage = pageCount;
        if (catalogPage < 1) catalogPage = 1;
        var start = (catalogPage - 1) * catalogPageSize;
        var pageModels = models.slice(start, start + catalogPageSize);
        pageModels.forEach(function (m) {
            grid.appendChild(renderCard(m));
        });
        if (pageCount > 1 && wrap) {
            var pg = document.createElement('div');
            pg.className = 'catalog-pagination';
            var bPrev = document.createElement('button');
            bPrev.type = 'button';
            bPrev.textContent = tr('prev');
            bPrev.disabled = catalogPage <= 1;
            bPrev.addEventListener('click', function () {
                if (catalogPage > 1) {
                    catalogPage -= 1;
                    render();
                }
            });
            var info = document.createElement('span');
            info.textContent = tr('page') + ' ' + catalogPage + ' / ' + pageCount + ' · ' + tr('propsTotal') + ': ' + models.length;
            var bNext = document.createElement('button');
            bNext.type = 'button';
            bNext.textContent = tr('next');
            bNext.disabled = catalogPage >= pageCount;
            bNext.addEventListener('click', function () {
                if (catalogPage < pageCount) {
                    catalogPage += 1;
                    render();
                }
            });
            pg.appendChild(bPrev);
            pg.appendChild(info);
            pg.appendChild(bNext);
            wrap.appendChild(pg);
        }
    }

    function formatVec(row) {
        var x = Number(row.x).toFixed(2);
        var y = Number(row.y).toFixed(2);
        var z = Number(row.z).toFixed(2);
        return x + ', ' + y + ', ' + z;
    }

    function folderContainsProp(folder, propId) {
        if (!folder || !propId) return false;
        var ids = folder.propIds;
        if (!Array.isArray(ids)) return false;
        return ids.indexOf(propId) !== -1;
    }

    function propInAnyFolder(propId) {
        for (var i = 0; i < placedFolders.length; i++) {
            if (folderContainsProp(placedFolders[i], propId)) return true;
        }
        return false;
    }

    function findFolderById(folderId) {
        for (var i = 0; i < placedFolders.length; i++) {
            if (placedFolders[i].id === folderId) return placedFolders[i];
        }
        return null;
    }

    function buildPlacedFolderCell(row) {
        var tdG = document.createElement('td');
        tdG.className = 'placed-folder-cell';
        if ((row.kind || 'prop') !== 'prop') {
            tdG.textContent = '—';
            tdG.style.color = '#555';
            return tdG;
        }
        var wrap = document.createElement('div');
        wrap.className = 'placed-folder-cell-inner';
        var sel = document.createElement('select');
        sel.className = 'placed-row-group-select';
        function addOpt(v, label) {
            var o = document.createElement('option');
            o.value = v;
            o.textContent = label;
            sel.appendChild(o);
        }
        addOpt('', tr('placedPickFolder'));
        placedFolders.forEach(function (f) {
            if (f && f.id && f.name) addOpt(f.id, f.name);
        });
        addOpt('__new__', '+ ' + tr('folderNamePrompt'));
        sel.value = '';
        sel.addEventListener('change', function () {
            var v = sel.value;
            sel.value = '';
            if (v === '' || v === '__new__') {
                if (v === '__new__') {
                    openTextModal(tr('folderNamePrompt'), '').then(function (name) {
                        if (name != null && String(name).trim()) {
                            post('createPlacedFolder', { name: String(name).trim() });
                        }
                    });
                }
                return;
            }
            post('addPlacedPropToFolder', { folderId: v, propId: row.id });
        });
        wrap.appendChild(sel);
        var names = [];
        placedFolders.forEach(function (f) {
            if (folderContainsProp(f, row.id) && f.name) names.push(f.name);
        });
        if (names.length > 0) {
            var badges = document.createElement('div');
            badges.className = 'placed-folder-badges';
            badges.textContent = names.join(', ');
            wrap.appendChild(badges);
        }
        var ff = placedFolderFilter;
        if (ff && ff !== '' && ff !== '__none__' && folderContainsProp(findFolderById(ff), row.id)) {
            var brm = document.createElement('button');
            brm.type = 'button';
            brm.className = 'btn-folder-remove';
            brm.textContent = tr('placedRemoveFromFolder');
            brm.addEventListener('click', function () {
                post('removePlacedPropFromFolder', { folderId: ff, propId: row.id });
            });
            wrap.appendChild(brm);
        }
        tdG.appendChild(wrap);
        return tdG;
    }

    function getAssemblySelectedPropIds() {
        var ids = [];
        Object.keys(placedSelectedPropIds).forEach(function (id) {
            if (!placedSelectedPropIds[id]) return;
            for (var i = 0; i < placedList.length; i++) {
                var r = placedList[i];
                if (r.id === id && (r.kind || 'prop') === 'prop') {
                    ids.push(id);
                    return;
                }
            }
        });
        return ids;
    }

    function appendPlacedAssemblyBar(parent) {
        if (!parent || !assembliesEnabled) return;
        var bar = document.createElement('div');
        bar.className = 'placed-assembly-bar';
        var lab = document.createElement('span');
        lab.className = 'placed-toolbar-label';
        lab.textContent = tr('assemblyBarLabel');

        var bCreate = document.createElement('button');
        bCreate.type = 'button';
        bCreate.className = 'btn-anims';
        bCreate.textContent = tr('assemblyCreateFromSelection');
        bCreate.addEventListener('click', function () {
            var ids = getAssemblySelectedPropIds();
            if (ids.length < 2) return;
            post('createPropAssembly', { propIds: ids });
            placedSelectedPropIds = {};
            renderPlaced();
        });

        var bClr = document.createElement('button');
        bClr.type = 'button';
        bClr.className = 'btn-anims';
        bClr.textContent = tr('assemblyClearSelection');
        bClr.addEventListener('click', function () {
            placedSelectedPropIds = {};
            renderPlaced();
        });

        var bDiss = document.createElement('button');
        bDiss.type = 'button';
        bDiss.className = 'btn-anims';
        bDiss.textContent = tr('assemblyDissolveSelected');
        bDiss.addEventListener('click', function () {
            var ids = getAssemblySelectedPropIds();
            if (ids.length !== 1) return;
            var row = placedList.filter(function (r) {
                return r.id === ids[0];
            })[0];
            if (!row || !row.assemblyId) return;
            openConfirmModal(tr('assemblyDissolveConfirm')).then(function (ok) {
                if (ok) {
                    post('dissolvePropAssembly', { assemblyId: row.assemblyId });
                    placedSelectedPropIds = {};
                    renderPlaced();
                }
            });
        });

        var hint = document.createElement('p');
        hint.className = 'placed-assembly-hint';
        hint.textContent = tr('assemblyToolbarHint');

        bar.appendChild(lab);
        bar.appendChild(bCreate);
        bar.appendChild(bClr);
        bar.appendChild(bDiss);
        bar.appendChild(hint);
        parent.appendChild(bar);
    }

    function getUniquePropGroups() {
        var seen = {};
        var out = [];
        placedList.forEach(function (r) {
            if ((r.kind || 'prop') !== 'prop') return;
            var g = String(r.group || '').trim();
            if (!g || seen[g]) return;
            seen[g] = true;
            out.push(g);
        });
        out.sort();
        return out;
    }

    function appendPlacedYmapBar(parent) {
        if (!parent || !ymapEnabled) return;
        var bar = document.createElement('div');
        bar.className = 'placed-ymap-bar';
        var lab = document.createElement('span');
        lab.className = 'placed-toolbar-label';
        lab.textContent = tr('ymapBarLabel');

        var scopeSel = document.createElement('select');
        scopeSel.className = 'placed-ymap-scope';
        [
            ['all', tr('ymapScopeAll')],
            ['group', tr('ymapScopeGroup')],
            ['folder', tr('ymapScopeFolder')],
            ['selection', tr('ymapScopeSelection')]
        ].forEach(function (pair) {
            var o = document.createElement('option');
            o.value = pair[0];
            o.textContent = pair[1];
            scopeSel.appendChild(o);
        });

        var inpGroup = document.createElement('input');
        inpGroup.type = 'text';
        inpGroup.className = 'placed-ymap-group-inp';
        inpGroup.placeholder = tr('ymapAssignGroupPh');
        inpGroup.setAttribute('autocomplete', 'off');
        var groups = getUniquePropGroups();
        if (groups.length > 0) inpGroup.value = groups[0];

        var inpFile = document.createElement('input');
        inpFile.type = 'text';
        inpFile.className = 'placed-ymap-file-inp';
        inpFile.placeholder = tr('ymapFileNamePh');
        inpFile.setAttribute('autocomplete', 'off');

        var bAssign = document.createElement('button');
        bAssign.type = 'button';
        bAssign.className = 'btn-anims';
        bAssign.textContent = tr('ymapAssignGroupBtn');
        bAssign.addEventListener('click', function () {
            var ids = getAssemblySelectedPropIds();
            if (ids.length === 0) return;
            post('setPropGroupBatch', { propIds: ids, group: (inpGroup.value || '').trim() });
            placedSelectedPropIds = {};
            renderPlaced();
        });

        var bExport = document.createElement('button');
        bExport.type = 'button';
        bExport.className = 'btn-anims';
        bExport.textContent = tr('ymapExportBtn');
        bExport.addEventListener('click', function () {
            var scope = scopeSel.value;
            var payload = {
                scope: scope,
                fileName: (inpFile.value || inpGroup.value || 'export').trim(),
                saveToDisk: true
            };
            if (scope === 'group') payload.groupName = (inpGroup.value || '').trim();
            if (scope === 'folder') {
                var ff = placedFolderFilter || '';
                if (ff === '' || ff === '__none__') return;
                payload.folderId = ff;
            }
            if (scope === 'selection') payload.propIds = getAssemblySelectedPropIds();
            post('exportYmap', payload);
        });

        var diskSel = document.createElement('select');
        diskSel.className = 'placed-ymap-disk-sel';
        var o0 = document.createElement('option');
        o0.value = '';
        o0.textContent = '—';
        diskSel.appendChild(o0);
        ymapExportNames.forEach(function (n) {
            if (!n) return;
            var o = document.createElement('option');
            o.value = n;
            o.textContent = n + '.ymap.xml';
            diskSel.appendChild(o);
        });

        var repWrap = document.createElement('label');
        repWrap.className = 'placed-saved-set-replace-wrap';
        var inpRep = document.createElement('input');
        inpRep.type = 'checkbox';
        repWrap.appendChild(inpRep);
        repWrap.appendChild(document.createTextNode(' ' + tr('ymapImportReplace')));

        var bImportDisk = document.createElement('button');
        bImportDisk.type = 'button';
        bImportDisk.className = 'btn-anims';
        bImportDisk.textContent = tr('ymapLoadDiskBtn');
        bImportDisk.addEventListener('click', function () {
            var n = diskSel.value;
            if (!n) return;
            post('importYmap', { fileName: n, replace: inpRep.checked });
        });

        var bImport = document.createElement('button');
        bImport.type = 'button';
        bImport.className = 'btn-anims';
        bImport.textContent = tr('ymapImportBtn');
        bImport.addEventListener('click', function () {
            openTextModal(tr('ymapImportTitle'), '').then(function (txt) {
                if (txt && String(txt).trim()) {
                    post('importYmap', { xml: String(txt).trim(), replace: inpRep.checked });
                }
            });
        });

        var hint = document.createElement('p');
        hint.className = 'placed-ymap-hint';
        hint.textContent = tr('ymapHint');

        bar.appendChild(lab);
        bar.appendChild(scopeSel);
        bar.appendChild(inpGroup);
        bar.appendChild(inpFile);
        bar.appendChild(bAssign);
        bar.appendChild(bExport);
        bar.appendChild(diskSel);
        bar.appendChild(bImportDisk);
        bar.appendChild(bImport);
        bar.appendChild(repWrap);
        bar.appendChild(hint);
        parent.appendChild(bar);
    }

    function appendPlacedSavedSetsBar(parent) {
        if (!parent || !savedPlacedSetsEnabled) return;
        var bar = document.createElement('div');
        bar.className = 'placed-saved-sets-bar';
        var lab = document.createElement('span');
        lab.className = 'placed-toolbar-label';
        lab.textContent = tr('placedSavedSetsLabel');
        var sel = document.createElement('select');
        sel.className = 'placed-saved-set-select';
        var o0 = document.createElement('option');
        o0.value = '';
        o0.textContent = '—';
        sel.appendChild(o0);
        savedPlacedSetNames.forEach(function (n) {
            if (!n || typeof n !== 'string') return;
            var o = document.createElement('option');
            o.value = n;
            o.textContent = n;
            sel.appendChild(o);
        });

        var bSave = document.createElement('button');
        bSave.type = 'button';
        bSave.className = 'btn-anims';
        bSave.textContent = tr('placedSavedSetSave');
        bSave.addEventListener('click', function () {
            openTextModal(tr('placedSavedSetNamePrompt'), '').then(function (name) {
                if (name != null && String(name).trim()) {
                    post('savePlacedSavedSet', { name: String(name).trim() });
                }
            });
        });

        var repWrap = document.createElement('label');
        repWrap.className = 'placed-saved-set-replace-wrap';
        var inpRep = document.createElement('input');
        inpRep.type = 'checkbox';
        repWrap.appendChild(inpRep);
        repWrap.appendChild(document.createTextNode(' ' + tr('placedSavedSetReplace')));

        var bLoad = document.createElement('button');
        bLoad.type = 'button';
        bLoad.className = 'btn-anims';
        bLoad.textContent = tr('placedSavedSetLoad');
        bLoad.addEventListener('click', function () {
            var n = sel.value;
            if (!n) return;
            var replace = inpRep.checked;
            function apply() {
                post('applyPlacedSavedSet', { name: n, replace: replace });
            }
            if (replace) {
                openConfirmModal(tr('placedSavedSetReplaceWarn')).then(function (ok) {
                    if (ok) apply();
                });
            } else apply();
        });

        var bDel = document.createElement('button');
        bDel.type = 'button';
        bDel.className = 'btn-anims';
        bDel.textContent = tr('placedSavedSetDelete');
        bDel.addEventListener('click', function () {
            var n = sel.value;
            if (!n) return;
            openConfirmModal(tr('placedSavedSetDeleteConfirm').split('[[name]]').join(n)).then(function (ok) {
                if (ok) post('deletePlacedSavedSet', { name: n });
            });
        });

        var hint = document.createElement('p');
        hint.className = 'placed-saved-sets-hint';
        hint.textContent = tr('placedSavedSetHint');

        bar.appendChild(lab);
        bar.appendChild(sel);
        bar.appendChild(bSave);
        bar.appendChild(bLoad);
        bar.appendChild(bDel);
        bar.appendChild(repWrap);
        bar.appendChild(hint);
        parent.appendChild(bar);
    }

    function renderPlaced() {
        var el = document.getElementById('content-placed');
        if (!el) return;
        el.innerHTML = '';
        el.style.padding = '14px 18px';

        var toolbar = document.createElement('div');
        toolbar.className = 'placed-toolbar';
        var bPlus = document.createElement('button');
        bPlus.type = 'button';
        bPlus.className = 'btn-folder-plus';
        bPlus.title = tr('placedNewFolder');
        bPlus.setAttribute('aria-label', tr('placedNewFolder'));
        bPlus.textContent = '+';
        bPlus.addEventListener('click', function () {
            openTextModal(tr('folderNamePrompt'), '').then(function (name) {
                if (name != null && String(name).trim()) {
                    post('createPlacedFolder', { name: String(name).trim() });
                }
            });
        });
        var lab = document.createElement('span');
        lab.className = 'placed-toolbar-label';
        lab.textContent = tr('placedFolderFilter');
        var fsel = document.createElement('select');
        fsel.className = 'placed-group-filter';
        [['', tr('placedFolderAll')], ['__none__', tr('placedFolderNone')]].forEach(function (pair) {
            var o = document.createElement('option');
            o.value = pair[0];
            o.textContent = pair[1];
            fsel.appendChild(o);
        });
        placedFolders.forEach(function (f) {
            if (f && f.id && f.name) {
                var o = document.createElement('option');
                o.value = f.id;
                o.textContent = f.name;
                fsel.appendChild(o);
            }
        });
        fsel.value = placedFolderFilter || '';
        fsel.addEventListener('change', function () {
            placedFolderFilter = fsel.value;
            placedPage = 1;
            renderPlaced();
        });
        toolbar.appendChild(bPlus);
        toolbar.appendChild(lab);
        toolbar.appendChild(fsel);
        el.appendChild(toolbar);
        appendPlacedAssemblyBar(el);
        appendPlacedYmapBar(el);
        appendPlacedSavedSetsBar(el);

        var ff = placedFolderFilter || '';
        if (ff !== '' && ff !== '__none__') {
            var bDel = document.createElement('button');
            bDel.type = 'button';
            bDel.className = 'btn-folder-delete';
            bDel.textContent = tr('placedDeleteFolder');
            bDel.addEventListener('click', function () {
                openConfirmModal(tr('folderDeleteConfirm')).then(function (ok) {
                    if (ok) {
                        post('deletePlacedFolder', { folderId: ff });
                        placedFolderFilter = '';
                        placedPage = 1;
                        renderPlaced();
                    }
                });
            });
            toolbar.appendChild(bDel);
        }

        var filtered = placedList.filter(function (row) {
            var hay = (row.model || '') + ' ' + (row.kind || '');
            if (!matchesSearch(hay)) return false;
            var fk = row.kind || 'prop';
            if (fk !== 'prop') return true;
            var gpf = placedFolderFilter || '';
            if (gpf === '') return true;
            if (gpf === '__none__') return !propInAnyFolder(row.id);
            var fo = findFolderById(gpf);
            return fo ? folderContainsProp(fo, row.id) : true;
        });
        if (filtered.length === 0) {
            var empty = document.createElement('div');
            empty.style.color = '#666';
            empty.style.padding = '16px 0';
            empty.textContent = placedList.length === 0 ? tr('noPlacedYet') : tr('noSearchPlaced');
            el.appendChild(empty);
            return;
        }
        var pageCount = Math.max(1, Math.ceil(filtered.length / placedPageSize));
        if (placedPage > pageCount) placedPage = pageCount;
        if (placedPage < 1) placedPage = 1;
        var start = (placedPage - 1) * placedPageSize;
        var pageRows = filtered.slice(start, start + placedPageSize);

        var table = document.createElement('table');
        table.className = 'placed-table';
        var thead = document.createElement('thead');
        var trh = document.createElement('tr');
        if (assembliesEnabled) {
            var thSel = document.createElement('th');
            thSel.className = 'placed-th-sel';
            thSel.textContent = tr('assemblySelectCol');
            trh.appendChild(thSel);
        }
        ['tableModel', 'tableCoords', 'placedPropGroupCol', 'placedFolderCol', 'placedActions'].forEach(function (key) {
            var th = document.createElement('th');
            th.textContent = tr(key);
            trh.appendChild(th);
        });
        thead.appendChild(trh);
        table.appendChild(thead);
        var tbody = document.createElement('tbody');
        pageRows.forEach(function (row) {
            var rowEl = document.createElement('tr');
            if (assembliesEnabled) {
                var tdSel = document.createElement('td');
                tdSel.className = 'placed-sel-cell';
                if ((row.kind || 'prop') === 'prop') {
                    var pch = document.createElement('input');
                    pch.type = 'checkbox';
                    pch.checked = !!placedSelectedPropIds[row.id];
                    pch.addEventListener('change', function () {
                        if (pch.checked) placedSelectedPropIds[row.id] = true;
                        else delete placedSelectedPropIds[row.id];
                    });
                    tdSel.appendChild(pch);
                }
                rowEl.appendChild(tdSel);
            }
            var tdM = document.createElement('td');
            if (row.kind === 'ped') {
                var badge = document.createElement('span');
                badge.className = 'placed-kind-badge';
                badge.textContent = tr('pedBadge');
                tdM.appendChild(badge);
                tdM.appendChild(document.createTextNode(' ' + row.model));
                if (row.entityAlive === false) {
                    var miss = document.createElement('span');
                    miss.className = 'placed-ped-missing';
                    miss.textContent = ' (' + tr('pedMissing') + ')';
                    tdM.appendChild(miss);
                }
            } else {
                tdM.appendChild(document.createTextNode(row.model));
                if (assembliesEnabled && row.assemblyId) {
                    var ab = document.createElement('span');
                    ab.className = 'placed-asm-badge';
                    ab.textContent = ' ' + String(row.assemblyId);
                    tdM.appendChild(ab);
                }
            }
            var tdC = document.createElement('td');
            tdC.style.fontSize = '11px';
            tdC.style.color = '#aaa';
            tdC.textContent = formatVec(row);
            var tdGrp = document.createElement('td');
            tdGrp.className = 'placed-group-cell';
            if ((row.kind || 'prop') === 'prop') {
                var inpGrp = document.createElement('input');
                inpGrp.type = 'text';
                inpGrp.className = 'placed-row-export-group-inp';
                inpGrp.placeholder = tr('ymapAssignGroupPh');
                inpGrp.setAttribute('autocomplete', 'off');
                if (row.group) inpGrp.value = String(row.group);
                inpGrp.addEventListener('change', function () {
                    post('setPropGroup', { id: row.id, group: (inpGrp.value || '').trim() });
                });
                tdGrp.appendChild(inpGrp);
            } else {
                tdGrp.textContent = '—';
                tdGrp.style.color = '#555';
            }
            var tdG = buildPlacedFolderCell(row);
            var tdA = document.createElement('td');
            tdA.className = 'placed-actions';
            if (row.kind === 'ped') {
                var flagsWrap = document.createElement('div');
                flagsWrap.className = 'placed-ped-flags';
                var alive = row.entityAlive !== false;
                var mkChk = function (labelKey, flagName, checked) {
                    var lab = document.createElement('label');
                    lab.className = 'placed-ped-flag-label';
                    var inp = document.createElement('input');
                    inp.type = 'checkbox';
                    inp.setAttribute('data-flag', flagName);
                    inp.checked = !!checked;
                    inp.disabled = !alive;
                    lab.appendChild(inp);
                    lab.appendChild(document.createTextNode(' ' + tr(labelKey)));
                    flagsWrap.appendChild(lab);
                };
                mkChk('pedImmortal', 'invincible', row.invincible);
                mkChk('pedFrozen', 'frozen', row.frozen);
                flagsWrap.querySelectorAll('input[type="checkbox"]').forEach(function (inp) {
                    inp.addEventListener('change', function () {
                        var inv = flagsWrap.querySelector('input[data-flag="invincible"]');
                        var fro = flagsWrap.querySelector('input[data-flag="frozen"]');
                        post('placedPedSetFlags', {
                            id: row.id,
                            invincible: inv ? inv.checked : false,
                            frozen: fro ? fro.checked : false
                        });
                    });
                });
                tdA.appendChild(flagsWrap);
                if (alive) {
                    var pairRow = document.createElement('div');
                    pairRow.className = 'placed-ped-pair-btns';
                    var mkPair = function (slot, label) {
                        var bx = document.createElement('button');
                        bx.type = 'button';
                        bx.className = 'btn-anims';
                        bx.textContent = label;
                        bx.addEventListener('click', function () {
                            post('setPairPedSlot', { slot: slot, id: row.id });
                        });
                        return bx;
                    };
                    pairRow.appendChild(mkPair('a', tr('placedSetSlotA')));
                    pairRow.appendChild(mkPair('b', tr('placedSetSlotB')));
                    var bMv = document.createElement('button');
                    bMv.type = 'button';
                    bMv.className = 'btn-anims';
                    bMv.textContent = tr('placedPedMove');
                    bMv.addEventListener('click', function () {
                        post('beginPedAdjust', { pedId: row.id });
                    });
                    pairRow.appendChild(bMv);
                    tdA.appendChild(pairRow);
                    var scRow = document.createElement('div');
                    scRow.className = 'placed-ped-scenario-row';
                    var inpSc = document.createElement('input');
                    inpSc.type = 'text';
                    inpSc.className = 'placed-ped-scenario-inp';
                    inpSc.placeholder = tr('pedScenarioPh');
                    inpSc.setAttribute('autocomplete', 'off');
                    if (row.scenario) inpSc.value = String(row.scenario);
                    var bSc = document.createElement('button');
                    bSc.type = 'button';
                    bSc.className = 'btn-anims';
                    bSc.textContent = tr('pedScenarioApply');
                    bSc.addEventListener('click', function () {
                        var v = (inpSc.value || '').trim();
                        if (!v) return;
                        post('pedPlayScenario', { pedId: row.id, scenario: v });
                    });
                    scRow.appendChild(inpSc);
                    scRow.appendChild(bSc);
                    tdA.appendChild(scRow);
                }
            }
            if (assembliesEnabled && (row.kind || 'prop') === 'prop') {
                var asmAct = document.createElement('div');
                asmAct.className = 'placed-asm-actions';
                if (row.assemblyId) {
                    var bAsmM = document.createElement('button');
                    bAsmM.type = 'button';
                    bAsmM.className = 'btn-anims';
                    bAsmM.textContent = tr('assemblyMoveGroup');
                    bAsmM.addEventListener('click', function () {
                        post('beginAssemblyAdjust', { assemblyId: row.assemblyId });
                    });
                    asmAct.appendChild(bAsmM);
                    var bAsmL = document.createElement('button');
                    bAsmL.type = 'button';
                    bAsmL.className = 'btn-anims';
                    bAsmL.textContent = tr('assemblyLeaveGroup');
                    bAsmL.addEventListener('click', function () {
                        post('leavePropAssemblyProp', { propId: row.id });
                    });
                    asmAct.appendChild(bAsmL);
                }
                tdA.appendChild(asmAct);
            }
            var bTp = document.createElement('button');
            bTp.type = 'button';
            bTp.textContent = tr('teleport');
            bTp.addEventListener('click', function () {
                post('placedTeleport', { id: row.id });
            });
            var bCp = document.createElement('button');
            bCp.type = 'button';
            bCp.textContent = tr('copyCoords');
            bCp.addEventListener('click', function () {
                var t = formatVec(row);
                copyTextToClipboard(t);
            });
            var bDel = document.createElement('button');
            bDel.type = 'button';
            bDel.className = 'danger';
            bDel.textContent = tr('del');
            bDel.addEventListener('click', function () {
                post('placedDelete', { id: row.id, kind: row.kind || 'prop' });
            });
            tdA.appendChild(bTp);
            tdA.appendChild(bCp);
            tdA.appendChild(bDel);
            rowEl.appendChild(tdM);
            rowEl.appendChild(tdC);
            rowEl.appendChild(tdGrp);
            rowEl.appendChild(tdG);
            rowEl.appendChild(tdA);
            tbody.appendChild(rowEl);
        });
        table.appendChild(tbody);
        el.appendChild(table);

        if (pageCount > 1) {
            var pg = document.createElement('div');
            pg.className = 'placed-pagination';
            var bPrev = document.createElement('button');
            bPrev.type = 'button';
            bPrev.textContent = tr('prev');
            bPrev.disabled = placedPage <= 1;
            bPrev.addEventListener('click', function () {
                if (placedPage > 1) {
                    placedPage -= 1;
                    renderPlaced();
                }
            });
            var info = document.createElement('span');
            info.textContent = tr('page') + ' ' + placedPage + ' / ' + pageCount + ' (' + filtered.length + ')';
            var bNext = document.createElement('button');
            bNext.type = 'button';
            bNext.textContent = tr('next');
            bNext.disabled = placedPage >= pageCount;
            bNext.addEventListener('click', function () {
                if (placedPage < pageCount) {
                    placedPage += 1;
                    renderPlaced();
                }
            });
            pg.appendChild(bPrev);
            pg.appendChild(info);
            pg.appendChild(bNext);
            el.appendChild(pg);
        }
    }

    function showPlacement(data) {
        var root = document.getElementById('app-root');
        if (root) root.classList.add('placement-world-visible');
        var shell = document.querySelector('.gizmo-shell');
        if (shell) shell.classList.add('hidden');
        var dock = document.getElementById('placement-dock');
        var label = document.getElementById('placement-model-label');
        if (label && data.model) label.textContent = data.model;
        document.querySelectorAll('.pl-ped-hideable').forEach(function (el) {
            el.classList.toggle('hidden', data.pedAdjust === true);
        });
        var range = document.getElementById('pl-speed');
        var pct = document.getElementById('pl-speed-pct');
        if (range && data.speedMin != null) {
            range.min = String(data.speedMin);
            range.max = String(data.speedMax);
            range.step = String(data.speedStep || 5);
            range.value = String(data.speedPercent != null ? data.speedPercent : 100);
        }
        if (pct && range) pct.textContent = range.value + '%';
        var freeMove = document.getElementById('pl-free-move');
        if (freeMove) {
            freeMove.checked = false;
            post('placementSetFreeMove', { enabled: false });
        }
        var fmWrap = document.getElementById('pl-free-move-wrap');
        if (fmWrap) fmWrap.classList.toggle('hidden', data.placementAssembly === true);
        if (dock) dock.classList.remove('hidden');
    }

    function hidePlacement() {
        var root = document.getElementById('app-root');
        if (root) root.classList.remove('placement-world-visible');
        var shell = document.querySelector('.gizmo-shell');
        if (shell) shell.classList.remove('hidden');
        var dock = document.getElementById('placement-dock');
        if (dock) dock.classList.add('hidden');
        document.querySelectorAll('.pl-ped-hideable').forEach(function (el) {
            el.classList.remove('hidden');
        });
        var fmWrap = document.getElementById('pl-free-move-wrap');
        if (fmWrap) fmWrap.classList.remove('hidden');
    }

    function setupPlacementControls() {
        function sendMove(dir, pressed) {
            post('placementMove', { direction: dir, pressed: pressed });
        }
        var dock = document.getElementById('placement-dock');
        if (!dock) return;
        dock.querySelectorAll('.pl-btn[data-dir]').forEach(function (btn) {
            var dir = btn.getAttribute('data-dir');
            btn.addEventListener('mousedown', function () { sendMove(dir, true); });
            btn.addEventListener('mouseup', function () { sendMove(dir, false); });
            btn.addEventListener('mouseleave', function () { sendMove(dir, false); });
        });
        var range = document.getElementById('pl-speed');
        var pct = document.getElementById('pl-speed-pct');
        function sendSpeed() {
            if (!range) return;
            var v = parseInt(range.value, 10);
            if (pct) pct.textContent = v + '%';
            post('placementSetSpeed', { percent: v });
        }
        if (range) {
            range.addEventListener('input', sendSpeed);
            range.addEventListener('change', sendSpeed);
        }
        var confirm = document.getElementById('pl-confirm');
        var reset = document.getElementById('pl-reset');
        var cancel = document.getElementById('pl-cancel');
        var freeMove = document.getElementById('pl-free-move');
        if (confirm) confirm.addEventListener('click', function () { post('placeConfirm', {}); });
        if (reset) reset.addEventListener('click', function () { post('placementReset', {}); });
        if (cancel) cancel.addEventListener('click', function () { post('placementCancel', {}); });
        if (freeMove) {
            freeMove.addEventListener('change', function () {
                post('placementSetFreeMove', { enabled: freeMove.checked });
            });
        }
    }

    function openApp(data) {
        catalogTree = data.tree || {};
        allProps = normalizePropList(data.allProps || []);
        pedsCatalog = normalizeStringList(data.peds || []);
        blipsCatalog = normalizeIndexedArrayLike(data.blips || [])
            .map(function (row) {
                if (!row || typeof row !== 'object') return null;
                var n = row.name;
                var sp = row.sprite != null ? Number(row.sprite) : null;
                if (typeof n !== 'string' || n === '' || !Number.isFinite(sp)) return null;
                return { name: n, sprite: sp };
            })
            .filter(function (x) { return x != null; });
        blipNameToRow = {};
        for (var bi = 0; bi < blipsCatalog.length; bi++) {
            var brow = blipsCatalog[bi];
            if (brow && typeof brow.name === 'string') blipNameToRow[brow.name] = brow;
        }
        animationsScenarios = (data.animations && data.animations.scenarios) || {};
        animationsClips = (data.animations && data.animations.clips) || {};
        pairSlotA = data.pairSlotA || null;
        pairSlotB = data.pairSlotB || null;
        var catKeys0 = animPickerMode === 'scenario'
            ? Object.keys(animationsScenarios).sort()
            : Object.keys(animationsClips).sort();
        if (!animCategoryKey || catKeys0.indexOf(animCategoryKey) === -1) {
            animCategoryKey = catKeys0[0] || '';
        }
        redLookupBaseUrl = (typeof data.redLookupBaseUrl === 'string' && data.redLookupBaseUrl) ? data.redLookupBaseUrl.replace(/\/$/, '') : 'https://redlookup.com';
        redLookupPedImageUrl = typeof data.redLookupPedImageUrl === 'string' ? data.redLookupPedImageUrl : '';
        redLookupBlipImageUrl = typeof data.redLookupBlipImageUrl === 'string' ? data.redLookupBlipImageUrl : '';
        if (data.resourceName) resourceName = data.resourceName;
        thumbBase = (typeof data.thumbBase === 'string') ? data.thumbBase.replace(/\/$/, '') : '';
        wrapSpooniRoot = data.wrapSpooniRoot !== false;
        spooniRootExpanded = data.spooniRootExpanded !== false;
        lang = (data.lang === 'en') ? 'en' : 'ru';
        placedPageSize = Number(data.placedPageSize) > 0 ? Math.max(20, Math.floor(Number(data.placedPageSize))) : 100;
        catalogPageSize = Number(data.catalogPageSize) > 0 ? Math.max(40, Math.floor(Number(data.catalogPageSize))) : 120;
        refreshFavoritesCache();
        catalogPage = 1;
        placedPage = 1;
        gameObjectsListAvailable = data.gameObjectsListAvailable === true;
        freeCamEnabled = data.freeCamEnabled !== false;
        savedPlacedSetsEnabled = data.savedPlacedSetsEnabled !== false;
        savedPlacedSetNames = Array.isArray(data.savedPlacedSets) ? data.savedPlacedSets.slice() : [];
        assembliesEnabled = data.assembliesEnabled !== false;
        ymapEnabled = data.ymapEnabled !== false;
        placedSelectedPropIds = {};
        applyStaticI18n();
        relabelNuiModalButtons();
        if (typeof data.gameObjectsListPath === 'string' && data.gameObjectsListPath) {
            gameObjectsListPath = data.gameObjectsListPath;
        }
        var goBtn0 = document.getElementById('nav-btn-gameobjects');
        if (goBtn0) goBtn0.classList.toggle('hidden', !gameObjectsListAvailable);
        var fcNav = document.getElementById('nav-btn-freecam');
        if (fcNav) fcNav.classList.toggle('hidden', !freeCamEnabled);
        if (gameObjectsListAvailable && !gameObjectsFetchInProgress && gameObjectsCatalog === null) {
            gameObjectsFetchInProgress = true;
            fetch('https://' + getRes() + '/' + gameObjectsListPath)
                .then(function (r) {
                    if (!r.ok) throw new Error('gameObjects');
                    return r.json();
                })
                .then(function (j) {
                    gameObjectsFetchInProgress = false;
                    gameObjectsCatalog = (j && Array.isArray(j.names)) ? j.names : (Array.isArray(j) ? j : []);
                    if (currentView === 'gameobjects') render();
                })
                .catch(function () {
                    gameObjectsFetchInProgress = false;
                    gameObjectsCatalog = [];
                    if (currentView === 'gameobjects') render();
                });
        }
        var root = document.getElementById('app-root');
        if (root) root.classList.remove('hidden');
        var shell = document.querySelector('.gizmo-shell');
        if (shell) shell.classList.remove('hidden');
        buildCategoryNav();
        setView('all');
    }

    function closeApp() {
        if (isTextModalOpen()) closeTextModalWithValue(null);
        if (isConfirmModalOpen()) closeConfirmModalWithValue(false);
        var root = document.getElementById('app-root');
        if (root) root.classList.add('hidden');
        hidePlacement();
    }

    window.addEventListener('message', function (event) {
        var data = event.data;
        if (!data || !data.action) return;
        if (data.action === 'open') {
            openApp(data);
        }
        if (data.action === 'close') {
            closeApp();
        }
        if (data.action === 'placedList') {
            placedList = normalizeIndexedArrayLike(data.list || []);
            placedFolders = Array.isArray(data.folders) ? data.folders : [];
            if (currentView === 'placed') renderPlaced();
            if (currentView === 'playerSkin') render();
        }
        if (data.action === 'savedPlacedSets') {
            savedPlacedSetNames = Array.isArray(data.names) ? data.names.slice() : [];
            if (currentView === 'placed') renderPlaced();
        }
        if (data.action === 'pairSlots') {
            pairSlotA = data.slotA || null;
            pairSlotB = data.slotB || null;
            if (currentView === 'anims') renderAnimsToolbarAndGrid();
            if (currentView === 'placed') renderPlaced();
        }
        if (data.action === 'ymapFileList') {
            ymapExportNames = Array.isArray(data.names) ? data.names.slice() : [];
            if (currentView === 'placed') renderPlaced();
        }
        if (data.action === 'ymapExportResult' && data.result) {
            ymapExportNames = Array.isArray(ymapExportNames) ? ymapExportNames : [];
            var fn = data.result.fileName;
            if (fn && ymapExportNames.indexOf(fn) === -1) {
                ymapExportNames.push(fn);
                ymapExportNames.sort();
            }
            if (currentView === 'placed') renderPlaced();
        }
        if (data.action === 'clipboardText' && data.text) {
            copyTextToClipboard(String(data.text), function () {});
        }
        if (data.action === 'skinHint') {
            var dock = document.getElementById('skin-hint-dock');
            if (!dock) return;
            if (!data.show) {
                dock.classList.add('hidden');
                return;
            }
            dock.classList.remove('hidden');
            var ht = document.getElementById('skin-hint-title');
            var ul = document.getElementById('skin-hint-list');
            if (ht) ht.textContent = data.title || '';
            if (ul) {
                ul.innerHTML = '';
                var lines = data.lines || [];
                for (var hi = 0; hi < lines.length; hi++) {
                    var li = document.createElement('li');
                    li.textContent = lines[hi];
                    ul.appendChild(li);
                }
            }
        }
        if (data.action === 'skinRosterData') {
            skinRosterCache = data.data && typeof data.data === 'object' ? data.data : { online: [], history: [] };
            var rw = document.getElementById('player-skin-roster-wrap');
            if (rw) renderSkinRosterPanel(rw, skinRosterCache);
        }
        if (data.action === 'showPlacement') {
            showPlacement(data);
        }
        if (data.action === 'hidePlacement') {
            hidePlacement();
        }
    });

    document.getElementById('btn-close').addEventListener('click', function () {
        post('close', {});
    });

    document.getElementById('search-input').addEventListener('input', function (e) {
        if (currentView === 'freecam') return;
        searchQuery = (e.target && e.target.value) || '';
        catalogPage = 1;
        placedPage = 1;
        if (currentView === 'placed') renderPlaced();
        else if (currentView === 'playerSkin') render();
        else if (currentView === 'anims') renderAnimsToolbarAndGrid();
        else if (currentView === 'gameobjects') render();
        else render();
    });

    document.getElementById('sidebar-nav').addEventListener('click', function (e) {
        var t = e.target;
        if (!(t instanceof HTMLElement)) return;
        if (t.classList.contains('nav-group-toggle')) {
            var g = t.closest('.nav-group');
            if (g) {
                g.classList.toggle('open');
                var sub = g.querySelector('.nav-sub');
                if (sub) sub.classList.toggle('hidden');
            }
            return;
        }
        if (!t.classList.contains('nav-btn')) return;
        var v = t.getAttribute('data-view');
        if (!v) return;
        if (v === 'category') {
            var c = t.getAttribute('data-cat');
            var s = t.getAttribute('data-sub');
            if (c && s) setCategoryView(c, s);
        } else {
            setView(v);
        }
    });

    document.addEventListener('keydown', function (e) {
        if (isTextModalOpen()) {
            if (e.key === 'Escape') {
                e.preventDefault();
                closeTextModalWithValue(null);
            }
            return;
        }
        if (isConfirmModalOpen()) {
            if (e.key === 'Escape') {
                e.preventDefault();
                closeConfirmModalWithValue(false);
            }
            return;
        }
        var root = document.getElementById('app-root');
        if (!root || root.classList.contains('hidden')) return;
        var dock = document.getElementById('placement-dock');
        var placing = dock && !dock.classList.contains('hidden');
        if (placing) {
            if (e.key === 'Escape') {
                e.preventDefault();
                post('placementCancel', {});
            }
            return;
        }
        if (e.key === 'Escape') {
            post('close', {});
        }
    });

    initNuiModals();
    setupPlacementControls();
    (function setupManualModelBar() {
        var btn = document.getElementById('manual-model-action');
        var inp = document.getElementById('manual-model-input');
        if (btn) {
            btn.addEventListener('click', function () {
                submitManualModel();
            });
        }
        if (inp) {
            inp.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submitManualModel();
                }
            });
        }
    })();
    (function setupFreecamActivate() {
        var b = document.getElementById('freecam-activate');
        if (b)
            b.addEventListener('click', function () {
                post('freecamStart', {});
            });
    })();
})();
