local RES = GetCurrentResourceName()
local Fw = GizmoResolveFramework()
local VorpCore = nil
local RSGCoreObj = nil

if Fw == "vorp" then
    VorpCore = exports.vorp_core:GetCore()
elseif Fw == "rsg" then
    local rsgRes = GizmoRsgResourceName()
    RSGCoreObj = exports[rsgRes]:GetCoreObject()
else
    print("^1[rsg_prop_gizmo]^7 Client: start vorp_core or rsg-core before this resource, or set Config.Framework.")
end

local function gizmoNotify(msg, duration)
    duration = duration or 4000
    if Fw == "vorp" and VorpCore then
        VorpCore.NotifyRightTip(msg, duration)
        return
    end
    if Fw == "rsg" then
        -- RSG 2.x ships ox_lib; export works without @ox_lib in this resource manifest.
        local ok = pcall(function()
            exports.ox_lib:notify({ description = msg, type = "inform", duration = duration })
        end)
        if ok then return end
        ok = pcall(function()
            lib.notify({ description = msg, type = "inform", duration = duration })
        end)
        if ok then return end
        TriggerEvent("rNotify:Tip", msg, duration)
        return
    end
    print(("[prop_gizmo] %s"):format(tostring(msg)))
end

local function gizmoTriggerCanOpen(cb)
    if Fw == "vorp" and VorpCore then
        cb(VorpCore.Callback.TriggerAwait("prop_gizmo:canOpen"))
        return
    end
    if Fw == "rsg" and RSGCoreObj then
        RSGCoreObj.Functions.TriggerCallback("prop_gizmo:canOpen", function(access)
            cb(access)
        end)
        return
    end
    cb({ allowed = false })
end

local uiOpen = false
local catalogTree = {}
local allPropsList = {}
--- Model names that appear in data/spooni_catalog.json (for paid / streaming hint on load fail).
local spooniCatalogModelNames = {}
--- data/game_objects_list.json present (NUI fetches list; avoids huge SendNUIMessage payload).
local gameObjectsListAvailable = false
local uiLang = (Config.Language == "ru") and "ru" or "en"
local visibilityRules = {
    allowedCategories = {},
    hiddenCategories = {},
    hiddenBlocks = {},
}

local catalogHintShown = false

local isPlacing = false
local placingProp = nil
local placingModel = nil
local placingPos = nil
local placingStartPos = nil
local placingCenterPos = nil
local placingStartCenterPos = nil
local placingModelCenterLocal = vector3(0.0, 0.0, 0.0)
local placingHeading = 0.0
local placingPitch = 0.0
local placingRoll = 0.0
local placingStartHeading = 0.0
local placingStartPitch = 0.0
local placingStartRoll = 0.0
local placementInput = {
    forward = false, back = false, left = false, right = false,
    rotLeft = false, rotRight = false,
    heightUp = false, heightDown = false,
    pitchUp = false, pitchDown = false,
    rollLeft = false, rollRight = false,
}
local placementCancelPressed = false
local placeConfirmPressed = false
local placementResetPressed = false
local placementSpeedMultiplier = 1.0
local placementFreeMoveEnabled = false

--- Совместное перемещение нескольких синхронных пропов (assemblyId).
local placingAssemblyMode = false
local placingAssemblyId = nil
local placingAssemblyMemberIds = {}
local placingAssemblySnap = {}
local placingAssemblyPivot0 = vector3(0.0, 0.0, 0.0)
local placingAssemblyDriveEnt = {}
local placingAssemblyDriveColl = {}
local placingAssemblyDisposableEnts = {}

local I18N = {
    en = {
        noAccess = "No access to /gizmo.",
        catalogHint = "Few catalog categories. Full list like spooni.pages.dev: run tools\\fetch_spooni_catalog.ps1 or enable Supabase fetch in config, then restart the resource.",
        modelLoadFail = "Failed to load model.",
        modelLoadFailHint = "Use the drawable name only (e.g. pai_01_home_hd). Do not paste .ytd or +hidr — textures load with the model if the asset exists in stream.",
        placementLoading = "Loading model…",
        spooniPaidProp = "This is a paid Spooni prop — buy it on the official site: spooni.pages.dev/store",
        pedSpawnOk = "Ped spawned in front of you.",
        pedLoadFail = "Could not load ped model (invalid name or missing assets).",
        pedAdjustMissing = "Ped is not in the world (too far or deleted).",
        pairImportFail = "Invalid pair scene JSON.",
        pairImportOk = "Pair scene imported.",
        pairExportCopied = "Scene JSON copied to clipboard.",
        propsExportCopied = "Placements JSON copied to clipboard.",
        savedSetSaved = "Prop set saved locally (this PC).",
        savedSetEmpty = "No props to save (server list empty on your client).",
        savedSetBadName = "Invalid set name (letters, digits, _ and -; max 40).",
        savedSetNotFound = "Set not found.",
        savedSetTooBig = "Too many props — raise Config.SavedPlacedSetMaxProps or split the set.",
        savedSetBadFile = "Saved set file is invalid or wrong format.",
        savedSetDisabled = "Saved sets are disabled in config.",
        assemblyDisabled = "Prop assemblies are disabled in config.",
        assemblyMoveNoMembers = "Assembly has no props on this client.",
        assemblyMovePreviewFail = "Could not load preview for an assembly prop.",
        assemblyPlaceLabel = "Assembly",
        ymapExportCopied = "YMAP XML copied to clipboard.",
        scenarioApplied = "Scenario applied to ped.",
        animApplied = "Clip applied to ped.",
        animDictMissing = "Anim dictionary not found.",
    },
    ru = {
        noAccess = "Нет доступа к /gizmo.",
        catalogHint = "Мало категорий каталога. Для полного списка как на spooni.pages.dev запустите tools\\fetch_spooni_catalog.ps1 или включите Supabase загрузку в конфиге, затем перезапустите ресурс.",
        modelLoadFail = "Не удалось загрузить модель.",
        modelLoadFailHint = "Укажите только имя drawable (напр. pai_01_home_hd). Не вставляйте .ytd или +hidr — текстуры идут вместе с моделью, если ассет есть в stream.",
        placementLoading = "Загрузка модели…",
        spooniPaidProp = "Это платный проп — купите его у Spooni на официальном сайте: spooni.pages.dev/store",
        pedSpawnOk = "Пед заспавнен перед вами.",
        pedLoadFail = "Не удалось загрузить модель педа (неверное имя или нет ассетов).",
        pedAdjustMissing = "Педа нет в мире (далеко или удалён).",
        pairImportFail = "Неверный JSON пары.",
        pairImportOk = "Сцена пары импортирована.",
        pairExportCopied = "JSON сцены скопирован в буфер.",
        propsExportCopied = "JSON пропов скопирован в буфер.",
        savedSetSaved = "Набор пропов сохранён локально (на этом ПК).",
        savedSetEmpty = "Нечего сохранять — список пропов с сервера у вас пуст.",
        savedSetBadName = "Неверное имя набора (латиница, цифры, _ и -; макс. 40).",
        savedSetNotFound = "Набор не найден.",
        savedSetTooBig = "Слишком много пропов — увеличьте Config.SavedPlacedSetMaxProps или разбейте набор.",
        savedSetBadFile = "Файл набора повреждён или неверный формат.",
        savedSetDisabled = "Локальные наборы отключены в конфиге.",
        assemblyDisabled = "Сборки пропов отключены в конфиге.",
        assemblyMoveNoMembers = "На клиенте нет пропов этой сборки.",
        assemblyMovePreviewFail = "Не удалось загрузить превью пропа сборки.",
        assemblyPlaceLabel = "Сборка",
        ymapExportCopied = "YMAP XML скопирован в буфер.",
        scenarioApplied = "Сценарий применён к педу.",
        animApplied = "Клип применён к педу.",
        animDictMissing = "Словарь анимации не найден.",
    }
}

local function tr(key)
    local t = I18N[uiLang] or I18N.en
    return t[key] or (I18N.en[key] or key)
end

local function normalizeKey(v)
    if type(v) ~= "string" then return nil end
    v = v:match("^%s*(.-)%s*$")
    if v == "" then return nil end
    return string.lower(v)
end

local function setContains(setTbl, key)
    local n = normalizeKey(key)
    return n and type(setTbl) == "table" and setTbl[n] == true
end

local function applyVisibilityToCatalog(sourceTree)
    if type(sourceTree) ~= "table" then return {} end
    local out = {}
    local allow = visibilityRules.allowedCategories or {}
    local hasAllow = type(allow) == "table" and next(allow) ~= nil
    local hideCats = visibilityRules.hiddenCategories or {}
    local hideBlocks = visibilityRules.hiddenBlocks or {}

    for cat, subs in pairs(sourceTree) do
        if type(subs) == "table" then
            local catN = normalizeKey(cat)
            local hiddenCat = setContains(hideCats, cat)
            local allowedCat = (not hasAllow) or (catN and allow[catN] == true)
            if allowedCat and not hiddenCat then
                out[cat] = {}
                for sub, ids in pairs(subs) do
                    if type(ids) == "table" then
                        local catBlocks = (catN and hideBlocks[catN]) or nil
                        local hiddenSub = setContains(catBlocks, sub)
                        if not hiddenSub then
                            out[cat][sub] = ids
                        end
                    end
                end
                if next(out[cat]) == nil then
                    out[cat] = nil
                end
            end
        end
    end
    return out
end

--- [id] = { id, model, entity }
local placedById = {}
local placedOrder = {}
--- Placed map blips from server
local placedBlipsById = {}
local placedBlipsOrder = {}
--- Folders of placed prop ids (from server JSON).
local placedFoldersSync = {}
--- Peds spawned from NUI (this client only; not synced to server).
local localPlacedPedsById = {}
local localPlacedPedsOrder = {}
--- Pair slots for «Сцены» (export / apply scenario to A or B).
local pairPedSlotA = nil
local pairPedSlotB = nil
--- Move ped with placement dock (separate from prop preview entity).
local placingAdjustPedEntity = nil
local placingAdjustPedRowId = nil
local placingAdjustPedSnap = nil
local animationsCatalog = { scenarios = {}, clips = {} }

--- Client KVP: локальные пресеты наборов пропов (переносятся между серверами вместе с профилем RedM).
local SAVED_PLACED_KVP_PREFIX = "vorp_prop_gizmo_savedset_"

local function sanitizeSavedPlacedSetName(name)
    if type(name) ~= "string" then return nil end
    name = name:match("^%s*(.-)%s*$") or ""
    if name == "" or #name > 40 then return nil end
    if not name:match("^[%w_%-]+$") then return nil end
    return name
end

local function listSavedPlacedSetNamesFromKvp()
    if Config.SavedPlacedSetsEnabled == false then return {} end
    local dbs = {}
    local okFind, handle = pcall(function()
        return StartFindKvp(SAVED_PLACED_KVP_PREFIX)
    end)
    if not okFind or not handle then return dbs end
    while true do
        local okN, kvp = pcall(FindKvp, handle)
        if not okN or not kvp then break end
        local suf = string.sub(kvp, #SAVED_PLACED_KVP_PREFIX + 1)
        if suf and suf ~= "" then dbs[#dbs + 1] = suf end
    end
    pcall(EndFindKvp, handle)
    table.sort(dbs)
    return dbs
end

local function pushSavedPlacedSetNamesToNui()
    SendNUIMessage({ action = "savedPlacedSets", names = listSavedPlacedSetNamesFromKvp() })
end

local function collectPlacedPropsForSavedSetPayload()
    local rows = {}
    for _, id in ipairs(placedOrder) do
        local e = placedById[id]
        if e then
            local row = {
                model = e.model,
                x = e.x, y = e.y, z = e.z,
                heading = e.heading, pitch = e.pitch, roll = e.roll,
                group = type(e.group) == "string" and e.group or "",
                assemblyId = type(e.assemblyId) == "string" and e.assemblyId or "",
            }
            if type(e.collisionProxyModel) == "string" and e.collisionProxyModel ~= "" then
                row.collisionProxyModel = e.collisionProxyModel
            end
            rows[#rows + 1] = row
        end
    end
    return rows
end

local function generateLocalPedRowId()
    return ("pg_ped_%s_%s"):format(tostring(GetGameTimer()), tostring(math.random(100000, 999999)))
end

local function removeLocalPlacedPed(id)
    local e = localPlacedPedsById[id]
    if not e then return end
    if e.ped and e.ped ~= 0 and DoesEntityExist(e.ped) then
        SetEntityAsMissionEntity(e.ped, true, true)
        DeleteEntity(e.ped)
    end
    localPlacedPedsById[id] = nil
    for i, pid in ipairs(localPlacedPedsOrder) do
        if pid == id then
            table.remove(localPlacedPedsOrder, i)
            break
        end
    end
    if pairPedSlotA == id then pairPedSlotA = nil end
    if pairPedSlotB == id then pairPedSlotB = nil end
end

local function clearAllLocalPlacedPeds()
    for _, id in ipairs(localPlacedPedsOrder) do
        local e = localPlacedPedsById[id]
        if e and e.ped and e.ped ~= 0 and DoesEntityExist(e.ped) then
            SetEntityAsMissionEntity(e.ped, true, true)
            DeleteEntity(e.ped)
        end
    end
    localPlacedPedsById = {}
    localPlacedPedsOrder = {}
    pairPedSlotA = nil
    pairPedSlotB = nil
end

--- Apply invincible / frozen from row (safe if entity missing).
local function applyLocalPedFlags(e)
    if not e or not e.ped or e.ped == 0 or not DoesEntityExist(e.ped) then return end
    local ped = e.ped
    pcall(function()
        if e.invincible then
            SetEntityInvincible(ped, true)
            SetEntityCanBeDamaged(ped, false)
        else
            SetEntityInvincible(ped, false)
            SetEntityCanBeDamaged(ped, true)
        end
    end)
    pcall(function()
        FreezeEntityPosition(ped, e.frozen == true)
    end)
    pcall(function()
        SetBlockingOfNonTemporaryEvents(ped, e.frozen == true)
    end)
end
local function GetPlayerCoords()
    local ped = PlayerPedId()
    if not ped or ped == 0 then return vector3(0, 0, 0) end
    local c = GetEntityCoords(ped, true, true)
    return vector3(c.x, c.y, c.z)
end

--- RedM has no global GetPlayerHeading (unlike some GTA builds).
local function GetPlayerHeading()
    local ped = PlayerPedId()
    if not ped or ped == 0 then return 0.0 end
    return GetEntityHeading(ped)
end

local function NormAngle360(deg)
    deg = deg % 360.0
    if deg < 0.0 then deg = deg + 360.0 end
    return deg
end

local function AsmRotFlatXY(x, y, degDeg)
    local r = math.rad((tonumber(degDeg) or 0.0) + 0.0)
    local c, s = math.cos(r), math.sin(r)
    return x * c - y * s, x * s + y * c
end

local function GetForwardVector(heading)
    local h = math.rad(heading)
    return vector3(-math.sin(h), math.cos(h), 0.0)
end

local function GetRightVector(heading)
    local h = math.rad(heading)
    return vector3(math.cos(h), math.sin(h), 0.0)
end

--- Horizontal move axes from gameplay camera yaw (screen: ↑ forward, ← left, → right).
local function CamFlatForwardRight()
    local camZ = GetGameplayCamRot(2).z
    return GetForwardVector(camZ), GetRightVector(camZ)
end

local function QuatMul(a, b)
    return {
        w = a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
        x = a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        y = a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        z = a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
    }
end

local function QuatNormalize(q)
    local len = math.sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z)
    if len < 1e-12 then return { w = 1.0, x = 0.0, y = 0.0, z = 0.0 } end
    return { w = q.w / len, x = q.x / len, y = q.y / len, z = q.z / len }
end

local function QuatFromAxisAngleDeg(axis, deg)
    local ax, ay, az = axis.x, axis.y, axis.z
    local len = math.sqrt(ax * ax + ay * ay + az * az)
    if len < 1e-8 then return { w = 1.0, x = 0.0, y = 0.0, z = 0.0 } end
    ax, ay, az = ax / len, ay / len, az / len
    local half = math.rad(deg) * 0.5
    local s = math.sin(half)
    return { w = math.cos(half), x = ax * s, y = ay * s, z = az * s }
end

local function QuatFromEulerDeg(pitch, roll, heading)
    local qx = QuatFromAxisAngleDeg(vector3(1.0, 0.0, 0.0), pitch or 0.0)
    local qy = QuatFromAxisAngleDeg(vector3(0.0, 1.0, 0.0), roll or 0.0)
    local qz = QuatFromAxisAngleDeg(vector3(0.0, 0.0, 1.0), heading or 0.0)
    return QuatNormalize(QuatMul(qz, QuatMul(qy, qx)))
end

local function QuatConjugate(q)
    return { w = q.w, x = -q.x, y = -q.y, z = -q.z }
end

local function QuatRotateVec(q, v)
    local p = { w = 0.0, x = v.x, y = v.y, z = v.z }
    local qq = QuatNormalize(q)
    local r = QuatMul(QuatMul(qq, p), QuatConjugate(qq))
    return vector3(r.x, r.y, r.z)
end

local function modelCenterLocalForHash(hash)
    if not hash or hash == 0 then return vector3(0.0, 0.0, 0.0) end
    local ok, minDim, maxDim = pcall(GetModelDimensions, hash)
    if not ok or not minDim or not maxDim then
        return vector3(0.0, 0.0, 0.0)
    end
    return vector3(
        (minDim.x + maxDim.x) * 0.5,
        (minDim.y + maxDim.y) * 0.5,
        (minDim.z + maxDim.z) * 0.5
    )
end

local function calcOriginFromCenter(centerPos, pitch, roll, heading, centerLocal)
    local q = QuatFromEulerDeg(pitch or 0.0, roll or 0.0, heading or 0.0)
    local localCenterWorld = QuatRotateVec(q, centerLocal or vector3(0.0, 0.0, 0.0))
    return vector3(
        centerPos.x - localCenterWorld.x,
        centerPos.y - localCenterWorld.y,
        centerPos.z - localCenterWorld.z
    )
end

--- Convert unsigned 32-bit to signed int (native hash form).
local function hashFromUInt32(n)
    if type(n) ~= "number" or n ~= n then return nil end
    n = math.floor(n) % 4294967296
    if n >= 2147483648 then n = n - 4294967296 end
    return n
end

--- Strip OpenIV/CodeX file noise; drawable name only (e.g. pai_01_home_hd). +hidr.ytd is not a model id.
local function sanitizePropModelInput(s)
    if type(s) ~= "string" then return "" end
    s = s:match("^%s*(.-)%s*$") or ""
    if s == "" then return "" end
    while true do
        local prev = s
        s = s:gsub("%.[yY][tT][dD]$", "")
            :gsub("%.[yY][dD][rR]$", "")
            :gsub("%.[yY][fF][tT]$", "")
            :gsub("%.[yY][dD][dD]$", "")
            :gsub("%.[yY][bB][nN]$", "")
            :gsub("%.[xX][mM][lL]$", "")
        s = s:gsub("%+[hH][iI][dD][rR]$", "")
        s = s:gsub("%+[lL][oO][dD][sS]?$", "")
        if s == prev then break end
    end
    return s
end

--- Prop placement: joaat(name), or "0xABCD" / decimal hash string (catalog not required).
local function resolvePlacementModelHash(modelName)
    if type(modelName) ~= "string" then return nil end
    local s = modelName:match("^%s*(.-)%s*$") or ""
    if s == "" then return nil end
    if s:match("^0[xX][0-9a-fA-F]+$") then
        local h = tonumber(s:sub(3), 16)
        if h and h ~= 0 then return hashFromUInt32(h) end
        return nil
    end
    if s:match("^%d+$") then
        local h = tonumber(s)
        if h and h ~= 0 then return hashFromUInt32(h) end
        return nil
    end
    s = sanitizePropModelInput(s)
    if s == "" then return nil end
    -- CodeWalker / ymap style: "xKxGvBA_0xC1CC911D" → archetype hash after last "_0x".
    local hexAfterUnderscore = s:match("_0[xX]([0-9a-fA-F]+)$")
    if hexAfterUnderscore then
        local h = tonumber(hexAfterUnderscore, 16)
        if h and h ~= 0 then return hashFromUInt32(h) end
        return nil
    end
    return joaat(s)
end

--- Canonical name for NUI / server (same rules as hash, without hex-only shortcut).
local function canonicalPropModelName(modelName)
    if type(modelName) ~= "string" then return "" end
    local s = modelName:match("^%s*(.-)%s*$") or ""
    if s == "" then return "" end
    if s:match("^0[xX][0-9a-fA-F]+$") or s:match("^%d+$") then return s end
    s = sanitizePropModelInput(s)
    return s
end

--- opts.forPlacement: Wait(0) loop + PropPlaceModelLoadMaxMs (faster feedback for / gizmo place).
local function LoadModel(hash, opts)
    opts = opts or {}
    if not hash or hash == 0 then return false end
    if HasModelLoaded(hash) then return true end
    local hi = Config.PropSpawnRequestModelHighPriority == true
    RequestModel(hash, hi)
    if opts.forPlacement == true then
        local maxMs = tonumber(Config.PropPlaceModelLoadMaxMs) or 12000
        local deadline = GetGameTimer() + maxMs
        while not HasModelLoaded(hash) and GetGameTimer() < deadline do
            RequestModel(hash, hi)
            Wait(0)
        end
        if not HasModelLoaded(hash) and Config.PropPlaceModelRetryOppositeP1 ~= false then
            local hi2 = not hi
            RequestModel(hash, hi2)
            local retryMs = tonumber(Config.PropPlaceModelRetryMs) or 5000
            local t2 = GetGameTimer() + retryMs
            while not HasModelLoaded(hash) and GetGameTimer() < t2 do
                RequestModel(hash, hi2)
                Wait(0)
            end
        end
        return HasModelLoaded(hash)
    end
    local t = 0
    while not HasModelLoaded(hash) and t < 200 do
        Wait(50)
        t = t + 1
    end
    return HasModelLoaded(hash)
end

--- Pull terrain + model collision (and optionally a short map load bubble) so regional assets resolve.
--- mode: "preview" (placement ghost) or "world" (synced prop).
local function preparePropSpawnStreaming(hash, x, y, z, mode)
    if Config.PropSpawnPrepStreaming == false then return end
    if not hash or hash == 0 then return end
    x, y, z = x + 0.0, y + 0.0, z + 0.0
    mode = (mode == "world") and "world" or "preview"
    local radius = tonumber(Config.PropSpawnPrepCollisionRadius) or 14.0
    if radius < 1.0 then radius = 1.0 end
    if mode == "preview" then
        radius = math.min(radius, 8.0)
    end

    local function pingCollisionRing()
        RequestCollisionAtCoord(x, y, z)
        local r = radius
        local ring = {
            { r, 0.0, 0.0 }, { -r, 0.0, 0.0 }, { 0.0, r, 0.0 }, { 0.0, -r, 0.0 },
            { r * 0.65, r * 0.65, 0.0 }, { -r * 0.65, r * 0.65, 0.0 },
            { r * 0.65, -r * 0.65, 0.0 }, { -r * 0.65, -r * 0.65, 0.0 },
            { 0.0, 0.0, r * 0.35 }, { 0.0, 0.0, -r * 0.35 },
        }
        for i = 1, #ring do
            local o = ring[i]
            RequestCollisionAtCoord(x + o[1], y + o[2], z + o[3])
        end
        if type(RequestCollisionForModel) == "function" then
            RequestCollisionForModel(hash)
        end
    end

    local wantLoadScene = false
    if mode == "world" and Config.PropSpawnPrepLoadSceneOnWorld == true then
        wantLoadScene = true
    elseif mode == "preview" and Config.PropSpawnPrepLoadSceneOnPreview == true then
        wantLoadScene = true
    end

    if wantLoadScene and type(NewLoadSceneStart) == "function" and type(IsNewLoadSceneActive) == "function" then
        local bubble = tonumber(Config.PropSpawnPrepLoadSceneRadius) or 18.0
        if bubble < 5.0 then bubble = 5.0 end
        pcall(function()
            NewLoadSceneStart(x, y, z, 0.0, 0.0, 0.0, bubble, 0)
        end)
        local lsMax = GetGameTimer() + (tonumber(Config.PropSpawnPrepLoadSceneMaxMs) or 2500)
        while IsNewLoadSceneActive() and GetGameTimer() < lsMax do
            pingCollisionRing()
            if type(NetworkUpdateLoadScene) == "function" then
                pcall(NetworkUpdateLoadScene)
            end
            Wait(0)
        end
    end

    if mode == "preview" then
        pingCollisionRing()
        return
    end

    local timeout = tonumber(Config.PropSpawnPrepTimeoutMs) or 1200
    local deadline = GetGameTimer() + timeout
    pingCollisionRing()
    local maxFrames = 120
    local frames = 0
    while GetGameTimer() < deadline and frames < maxFrames do
        frames = frames + 1
        pingCollisionRing()
        local okModelCol = true
        if type(HasCollisionForModelLoaded) == "function" then
            okModelCol = HasCollisionForModelLoaded(hash)
        end
        local okPosCol = true
        if type(HasCollisionLoadedAtCoord) == "function" then
            okPosCol = HasCollisionLoadedAtCoord(x, y, z)
        end
        if okModelCol and okPosCol then break end
        Wait(0)
    end
end

--- Custom drawables (YDR / etc.) sometimes spawn invisible or faded until alpha/visibility reset.
local function finalizeWorldPropDraw(ent)
    if not ent or ent == 0 or not DoesEntityExist(ent) then return end
    pcall(function()
        if type(SetEntityVisible) == "function" then
            SetEntityVisible(ent, true, false)
        end
    end)
    pcall(function()
        if type(ResetEntityAlpha) == "function" then
            ResetEntityAlpha(ent)
        end
    end)
    pcall(function()
        if type(SetEntityAlpha) == "function" then
            SetEntityAlpha(ent, 255, false)
        end
    end)
end

--- Companion object that only supplies collision while staying invisible (YDR без YBN).
local function applyInvisibleCollisionProxy(ent)
    if not ent or ent == 0 or not DoesEntityExist(ent) then return end
    pcall(function()
        FreezeEntityPosition(ent, true)
        SetEntityCollision(ent, true, true)
    end)
    pcall(function()
        SetEntityCanBeDamaged(ent, false)
    end)
    pcall(function()
        if type(SetEntityVisible) == "function" then
            SetEntityVisible(ent, true, false)
        end
    end)
    pcall(function()
        if type(SetEntityAlpha) == "function" then
            SetEntityAlpha(ent, 0, false)
        end
    end)
end

local function spawnWorldCollisionProxyCompanion(modelName, x, y, z, heading, pitch, roll)
    local hash = resolvePlacementModelHash(modelName)
    if not hash then return nil end
    if not LoadModel(hash, { forPlacement = true }) then return nil end
    preparePropSpawnStreaming(hash, x, y, z, "world")
    local obj = CreateObject(hash, x, y, z, false, false, false, false, false)
    if not obj or obj == 0 or not DoesEntityExist(obj) then return nil end
    SetEntityCoords(obj, x, y, z, false, false, false, false)
    SetEntityRotation(obj, pitch or 0.0, roll or 0.0, heading or 0.0, 2, true)
    SetEntityAsMissionEntity(obj, true, true)
    RequestCollisionAtCoord(x + 0.0, y + 0.0, z + 0.0)
    applyInvisibleCollisionProxy(obj)
    return obj
end

local function spawnPreviewObject(modelName, x, y, z, heading, pitch, roll)
    local hash = resolvePlacementModelHash(modelName)
    if not hash then return nil end
    if not LoadModel(hash, { forPlacement = true }) then return nil end
    preparePropSpawnStreaming(hash, x, y, z, "preview")
    local obj = CreateObject(hash, x, y, z, false, false, false, false, false)
    if not obj or obj == 0 or not DoesEntityExist(obj) then return nil end
    SetEntityCoords(obj, x, y, z, false, false, false, false)
    SetEntityRotation(obj, pitch or 0.0, roll or 0.0, heading or 0.0, 2, true)
    FreezeEntityPosition(obj, true)
    SetEntityCollision(obj, false, false)
    SetEntityAlpha(obj, 200)
    return obj
end

--- World prop from server data (each client spawns the same coords — everyone sees the same).
local function spawnWorldProp(modelName, x, y, z, heading, pitch, roll)
    local hash = resolvePlacementModelHash(modelName)
    if not hash then return nil end
    if not LoadModel(hash, { forPlacement = true }) then return nil end
    preparePropSpawnStreaming(hash, x, y, z, "world")
    local obj = CreateObject(hash, x, y, z, false, false, false, false, false)
    if not obj or obj == 0 or not DoesEntityExist(obj) then return nil end
    SetEntityCoords(obj, x, y, z, false, false, false, false)
    SetEntityRotation(obj, pitch or 0.0, roll or 0.0, heading or 0.0, 2, true)
    FreezeEntityPosition(obj, true)
    SetEntityCollision(obj, true, true)
    SetEntityAsMissionEntity(obj, true, true)
    RequestCollisionAtCoord(x + 0.0, y + 0.0, z + 0.0)
    finalizeWorldPropDraw(obj)
    return obj
end

local function flattenCatalog(tree)
    local seen = {}
    local out = {}
    local function walk(t)
        if type(t) ~= "table" then return end
        for _, v in pairs(t) do
            if type(v) == "string" then
                if not seen[v] then
                    seen[v] = true
                    out[#out + 1] = v
                end
            elseif type(v) == "table" then
                walk(v)
            end
        end
    end
    walk(tree)
    table.sort(out)
    return out
end

local function stripJsonBom(raw)
    if type(raw) ~= "string" or raw == "" then return raw end
    local b1, b2, b3 = string.byte(raw, 1, 3)
    if b1 == 239 and b2 == 187 and b3 == 191 then
        return raw:sub(4)
    end
    return raw
end

local function mergeCatalogTrees(dst, src)
    if type(src) ~= "table" then return end
    for cat, subs in pairs(src) do
        if type(subs) == "table" then
            if not dst[cat] then
                dst[cat] = {}
            end
            for sub, ids in pairs(subs) do
                if type(ids) == "table" then
                    if not dst[cat][sub] then
                        dst[cat][sub] = {}
                    end
                    local list = dst[cat][sub]
                    local seen = {}
                    for _, id in ipairs(list) do
                        if type(id) == "string" then
                            seen[id] = true
                        end
                    end
                    for _, id in ipairs(ids) do
                        if type(id) == "string" and not seen[id] then
                            seen[id] = true
                            list[#list + 1] = id
                        end
                    end
                end
            end
        end
    end
end

local function collectModelNamesFromTree(tree, set)
    local function walk(t)
        if type(t) ~= "table" then return end
        for _, v in pairs(t) do
            if type(v) == "string" and v ~= "" then
                set[v] = true
            elseif type(v) == "table" then
                walk(v)
            end
        end
    end
    walk(tree)
end

local function loadCatalog()
    catalogTree = {}
    allPropsList = {}
    spooniCatalogModelNames = {}
    --- Сначала bank_props (Bank + вручную добавленные категории), затем spooni_catalog — полный список с сайта.
    local paths = {
        "data/bank_props.json",
        "data/spooni_catalog.json",
    }
    for _, rel in ipairs(paths) do
        local raw = LoadResourceFile(RES, rel)
        if raw and raw ~= "" then
            raw = stripJsonBom(raw)
            local ok, data = pcall(json.decode, raw)
            if not ok then
                print(("[rsg_prop_gizmo] JSON decode failed: %s — %s"):format(rel, tostring(data)))
            end
            if ok and type(data) == "table" then
                local tree = data
                if type(data.categories) == "table" then
                    tree = data.categories
                end
                if type(tree) == "table" and next(tree) ~= nil then
                    mergeCatalogTrees(catalogTree, tree)
                    if rel == "data/spooni_catalog.json" then
                        collectModelNamesFromTree(tree, spooniCatalogModelNames)
                    end
                end
            end
        end
    end
    if next(catalogTree) ~= nil then
        allPropsList = flattenCatalog(catalogTree)
    end
    local nTop = 0
    for _ in pairs(catalogTree) do
        nTop = nTop + 1
    end
    print(("[rsg_prop_gizmo] Каталог: %d верхних категорий, %d пропов в All Props."):format(nTop, #allPropsList))
end

local function refreshGameObjectsListAvailability()
    gameObjectsListAvailable = false
    local rel = (type(Config.GameObjectsListFile) == "string" and Config.GameObjectsListFile ~= "")
        and Config.GameObjectsListFile
        or "data/game_objects_list.json"
    local raw = LoadResourceFile(RES, rel)
    if type(raw) == "string" and #raw > 80 and raw:find("%[") then
        gameObjectsListAvailable = true
    end
end

local function loadPedsCatalogList()
    local rel = (type(Config.PedsCatalogFile) == "string" and Config.PedsCatalogFile ~= "")
        and Config.PedsCatalogFile
        or "data/peds_catalog.json"
    local raw = LoadResourceFile(RES, rel)
    if not raw or raw == "" then return {} end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= "table" then return {} end
    local out = {}
    for _, v in ipairs(data) do
        if type(v) == "string" and v ~= "" then
            out[#out + 1] = v
        elseif type(v) == "table" and type(v.name) == "string" and v.name ~= "" then
            out[#out + 1] = v.name
        end
    end
    table.sort(out)
    return out
end

local function loadBlipsCatalogRows()
    local rel = (type(Config.BlipsCatalogFile) == "string" and Config.BlipsCatalogFile ~= "")
        and Config.BlipsCatalogFile
        or "data/blips_catalog.json"
    local raw = LoadResourceFile(RES, rel)
    if not raw or raw == "" then return {} end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= "table" then return {} end
    local out = {}
    for _, row in ipairs(data) do
        local name = row and row.name
        local sprite = tonumber(row and row.sprite)
        if type(name) == "string" and name ~= "" and sprite then
            out[#out + 1] = { name = name, sprite = sprite }
        end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

local function loadAnimationsCatalog()
    animationsCatalog = { scenarios = {}, clips = {} }
    local rel = (type(Config.AnimationsCatalogFile) == "string" and Config.AnimationsCatalogFile ~= "")
        and Config.AnimationsCatalogFile
        or "data/animations_catalog.json"
    local raw = LoadResourceFile(RES, rel)
    if not raw or raw == "" then return end
    raw = stripJsonBom(raw)
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= "table" then return end
    if type(data.scenarios) == "table" then
        for cat, list in pairs(data.scenarios) do
            if type(cat) == "string" and type(list) == "table" then
                local arr = {}
                for _, s in ipairs(list) do
                    if type(s) == "string" and s ~= "" and s:match("^[%w_]+$") then
                        arr[#arr + 1] = s
                    end
                end
                if #arr > 0 then
                    animationsCatalog.scenarios[cat] = arr
                end
            end
        end
    end
    if type(data.clips) == "table" then
        for cat, list in pairs(data.clips) do
            if type(cat) == "string" and type(list) == "table" then
                local arr = {}
                for _, row in ipairs(list) do
                    if type(row) == "table" and type(row.dict) == "string" and type(row.anim) == "string" then
                        arr[#arr + 1] = {
                            dict = row.dict,
                            anim = row.anim,
                            label = type(row.label) == "string" and row.label or "",
                        }
                    end
                end
                if #arr > 0 then
                    animationsCatalog.clips[cat] = arr
                end
            end
        end
    end
end

local function tryPlayScenarioOnPed(ped, scenarioName)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if type(scenarioName) ~= "string" or scenarioName == "" then return false end
    scenarioName = scenarioName:match("^%s*(.-)%s*$") or scenarioName
    pcall(function()
        ClearPedTasksImmediately(ped)
        FreezeEntityPosition(ped, false)
        SetBlockingOfNonTemporaryEvents(ped, false)
    end)
    local h = GetHashKey(scenarioName)
    if type(TaskStartScenarioInPlaceHash) == "function" then
        TaskStartScenarioInPlaceHash(ped, h, -1, true, 0, 0, false)
    else
        --- RedM: same native as TASK_START_SCENARIO_IN_PLACE_HASH
        Citizen.InvokeNative(0x524B54361229154F, ped, h, -1, true, 0, 0.0, 0)
    end
    return true
end

local function tryPlayAnimOnPed(ped, dict, anim)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    if type(dict) ~= "string" or type(anim) ~= "string" or dict == "" or anim == "" then return false end
    pcall(function()
        ClearPedTasksImmediately(ped)
    end)
    RequestAnimDict(dict)
    local deadline = GetGameTimer() + 8000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < deadline do
        Wait(10)
    end
    if not HasAnimDictLoaded(dict) then return false end
    TaskPlayAnim(ped, dict, anim, 1.0, 1.0, -1, 1, 1.0, false, false, false, "", false)
    return true
end

local function removeLocalPlaced(id)
    local e = placedById[id]
    if not e then return end
    if e.entity and DoesEntityExist(e.entity) then
        SetEntityAsMissionEntity(e.entity, true, true)
        DeleteEntity(e.entity)
    end
    if e.collisionEntity and DoesEntityExist(e.collisionEntity) then
        SetEntityAsMissionEntity(e.collisionEntity, true, true)
        DeleteEntity(e.collisionEntity)
    end
    placedById[id] = nil
    for i, pid in ipairs(placedOrder) do
        if pid == id then
            table.remove(placedOrder, i)
            break
        end
    end
end

local function clearAllPlacedVisuals()
    for _, id in ipairs(placedOrder) do
        local e = placedById[id]
        if e and e.entity and DoesEntityExist(e.entity) then
            SetEntityAsMissionEntity(e.entity, true, true)
            DeleteEntity(e.entity)
        end
        if e and e.collisionEntity and DoesEntityExist(e.collisionEntity) then
            SetEntityAsMissionEntity(e.collisionEntity, true, true)
            DeleteEntity(e.collisionEntity)
        end
    end
    placedById = {}
    placedOrder = {}
end

local function removeLocalPlacedBlip(id)
    local e = placedBlipsById[id]
    if not e then return end
    if e.blipHandle then
        RemoveBlip(e.blipHandle)
    end
    placedBlipsById[id] = nil
    for i, bid in ipairs(placedBlipsOrder) do
        if bid == id then
            table.remove(placedBlipsOrder, i)
            break
        end
    end
end

local function clearAllPlacedBlips()
    for _, id in ipairs(placedBlipsOrder) do
        local e = placedBlipsById[id]
        if e and e.blipHandle then
            RemoveBlip(e.blipHandle)
        end
    end
    placedBlipsById = {}
    placedBlipsOrder = {}
end

local function createWorldBlip(entry)
    local style = tonumber(Config.BlipStyle) or 1664425300
    local blip = BlipAddForCoords(style, entry.x, entry.y, entry.z)
    SetBlipSprite(blip, tonumber(entry.sprite) or 0, true)
    SetBlipScale(blip, tonumber(Config.BlipScale) or 0.2)
    SetBlipName(blip, entry.name or "Blip")
    return blip
end

local function registerBlipFromServer(row)
    if type(row) ~= "table" or type(row.id) ~= "string" then return end
    local x, y, z = tonumber(row.x), tonumber(row.y), tonumber(row.z)
    local sprite = tonumber(row.sprite)
    local name = row.name
    if not x or not y or not z or not sprite or type(name) ~= "string" then return end
    if placedBlipsById[row.id] then
        removeLocalPlacedBlip(row.id)
    end
    local handle = createWorldBlip({ x = x, y = y, z = z, sprite = sprite, name = name })
    placedBlipsById[row.id] = {
        id = row.id,
        name = name,
        sprite = sprite,
        x = x, y = y, z = z,
        blipHandle = handle,
    }
    placedBlipsOrder[#placedBlipsOrder + 1] = row.id
end

local function registerPlacedFromServer(row)
    if not row or type(row.id) ~= "string" or type(row.model) ~= "string" then return end
    if placedById[row.id] then
        removeLocalPlaced(row.id)
    end
    local x, y, z = tonumber(row.x), tonumber(row.y), tonumber(row.z)
    if not x or not y or not z then return end
    local h = tonumber(row.heading) or 0.0
    local p = tonumber(row.pitch) or 0.0
    local r = tonumber(row.roll) or 0.0
    local cproxy = ""
    if type(row.collisionProxyModel) == "string" then
        cproxy = row.collisionProxyModel:match("^%s*(.-)%s*$") or ""
    end
    placedById[row.id] = {
        id = row.id,
        model = row.model,
        collisionProxyModel = (cproxy ~= "") and cproxy or nil,
        x = x, y = y, z = z,
        heading = h, pitch = p, roll = r,
        group = (type(row.group) == "string" and row.group ~= "") and row.group or nil,
        assemblyId = (type(row.assemblyId) == "string" and row.assemblyId ~= "") and row.assemblyId or nil,
        entity = nil,
        collisionEntity = nil,
    }
    placedOrder[#placedOrder + 1] = row.id
end

local function ensurePlacedVisualState(entry, playerPos, spawnDistSq, despawnDistSq)
    if not entry then return false end
    local dx = entry.x - playerPos.x
    local dy = entry.y - playerPos.y
    local dz = entry.z - playerPos.z
    local distSq = dx * dx + dy * dy + dz * dz

    if entry.entity and DoesEntityExist(entry.entity) then
        if distSq > despawnDistSq then
            SetEntityAsMissionEntity(entry.entity, true, true)
            DeleteEntity(entry.entity)
            entry.entity = nil
            if entry.collisionEntity and DoesEntityExist(entry.collisionEntity) then
                SetEntityAsMissionEntity(entry.collisionEntity, true, true)
                DeleteEntity(entry.collisionEntity)
                entry.collisionEntity = nil
            end
        end
        return false
    end

    if distSq <= spawnDistSq then
        local ent = spawnWorldProp(entry.model, entry.x, entry.y, entry.z, entry.heading, entry.pitch, entry.roll)
        entry.entity = ent
        if ent and type(entry.collisionProxyModel) == "string" and entry.collisionProxyModel ~= "" then
            entry.collisionEntity = spawnWorldCollisionProxyCompanion(
                entry.collisionProxyModel,
                entry.x,
                entry.y,
                entry.z,
                entry.heading,
                entry.pitch,
                entry.roll
            )
        end
        return ent ~= nil
    end
    return false
end

local function sendPlacedListToNui()
    local rows = {}
    for _, id in ipairs(placedOrder) do
        local e = placedById[id]
        if e then
            rows[#rows + 1] = {
                id = e.id,
                kind = "prop",
                model = e.model,
                x = e.x, y = e.y, z = e.z,
                heading = e.heading, pitch = e.pitch, roll = e.roll,
                group = e.group or "",
                assemblyId = e.assemblyId or "",
            }
        end
    end
    for _, id in ipairs(placedBlipsOrder) do
        local b = placedBlipsById[id]
        if b then
            rows[#rows + 1] = {
                id = b.id,
                kind = "blip",
                model = b.name,
                sprite = b.sprite,
                x = b.x, y = b.y, z = b.z,
                heading = 0.0, pitch = 0.0, roll = 0.0,
            }
        end
    end
    for _, id in ipairs(localPlacedPedsOrder) do
        local pe = localPlacedPedsById[id]
        if pe then
            local alive = pe.ped and pe.ped ~= 0 and DoesEntityExist(pe.ped)
            rows[#rows + 1] = {
                id = pe.id,
                kind = "ped",
                model = pe.model,
                x = pe.x, y = pe.y, z = pe.z,
                heading = pe.heading or 0.0, pitch = 0.0, roll = 0.0,
                invincible = pe.invincible == true,
                frozen = pe.frozen == true,
                entityAlive = alive,
                scenario = pe.scenario,
                animDict = pe.animDict,
                animName = pe.animName,
            }
        end
    end
    SendNUIMessage({ action = "placedList", list = rows, folders = placedFoldersSync })
end

local function applyFullSync(list)
    clearAllPlacedVisuals()
    if type(list) ~= "table" then
        sendPlacedListToNui()
        return
    end
    for _, row in ipairs(list) do
        registerPlacedFromServer(row)
    end
    sendPlacedListToNui()
end

local function clearNuiFocusStuck()
    SetNuiFocus(false, false)
    CreateThread(function()
        Wait(0)
        SetNuiFocus(false, false)
    end)
end

--- После смены педа / сброса скина NUI иногда оставляет игру без курсора — несколько кадров снимаем фокус.
function PropGizmo_ForceReleaseNuiAndCursor()
    SetNuiFocusKeepInput(false)
    clearNuiFocusStuck()
    CreateThread(function()
        for _ = 1, 10 do
            Wait(0)
            SetNuiFocusKeepInput(false)
            SetNuiFocus(false, false)
        end
    end)
end

AddEventHandler("prop_gizmo:freecamNotify", function(msg, duration)
    if type(msg) == "string" and msg ~= "" then
        gizmoNotify(msg, tonumber(duration) or 5000)
    end
end)

local function closeUi()
    if isPlacing then return end
    uiOpen = false
    clearNuiFocusStuck()
    SendNUIMessage({ action = "close" })
end

local function openUi()
    if isPlacing then return end
    if type(PropGizmo_IsFreeCamActive) == "function" and PropGizmo_IsFreeCamActive() then
        TriggerEvent("prop_gizmo:requestStopFreecam")
        Wait(100)
    end
    gizmoTriggerCanOpen(function(access)
        local allowed = (type(access) == "table") and access.allowed or (access == true)
        if not allowed then
            gizmoNotify(tr("noAccess"), 4000)
            return
        end
        if type(access) == "table" then
            uiLang = (access.lang == "ru") and "ru" or "en"
            if type(access.visibility) == "table" then
                visibilityRules = access.visibility
            end
        end
        uiOpen = true
        local thumbBase = (type(Config.PropThumbnailBaseUrl) == "string") and Config.PropThumbnailBaseUrl or ""
        if thumbBase ~= "" and thumbBase:sub(-1) == "/" then
            thumbBase = thumbBase:sub(1, -2)
        end
        local visibleTree = applyVisibilityToCatalog(catalogTree)
        local visibleAllProps = flattenCatalog(visibleTree)

        local catCount = 0
        for _ in pairs(visibleTree) do
            catCount = catCount + 1
        end
        if not catalogHintShown and Config.CatalogHintIfSingleCategory and catCount <= 1 then
            catalogHintShown = true
            gizmoNotify(tr("catalogHint"), 12000)
        end

        local wrapRoot = Config.NuiWrapSpooniPropsRoot ~= false
        local expandRoot = Config.NuiExpandSpooniRootOnOpen ~= false
        local placedPageSize = math.max(20, math.floor(tonumber(Config.PlacedListPageSize) or 100))
        local catalogPageSize = math.max(40, math.floor(tonumber(Config.CatalogPageSize) or 120))
        local rlBase = (type(Config.RedLookupBaseUrl) == "string" and Config.RedLookupBaseUrl ~= "")
            and Config.RedLookupBaseUrl:gsub("/+$", "")
            or "https://redlookup.com"
        local rlPed = (type(Config.RedLookupPedImageUrl) == "string") and Config.RedLookupPedImageUrl or ""
        local rlBlip = (type(Config.RedLookupBlipImageUrl) == "string") and Config.RedLookupBlipImageUrl or ""
        local goRel = (type(Config.GameObjectsListFile) == "string" and Config.GameObjectsListFile ~= "")
            and Config.GameObjectsListFile
            or "data/game_objects_list.json"
        SendNUIMessage({
            action = "open",
            tree = visibleTree,
            allProps = visibleAllProps,
            peds = loadPedsCatalogList(),
            blips = loadBlipsCatalogRows(),
            animations = animationsCatalog,
            pairSlotA = pairPedSlotA,
            pairSlotB = pairPedSlotB,
            resourceName = RES,
            thumbBase = thumbBase,
            redLookupBaseUrl = rlBase,
            redLookupPedImageUrl = rlPed,
            redLookupBlipImageUrl = rlBlip,
            wrapSpooniRoot = wrapRoot,
            spooniRootExpanded = expandRoot,
            lang = uiLang,
            placedPageSize = placedPageSize,
            catalogPageSize = catalogPageSize,
            gameObjectsListAvailable = gameObjectsListAvailable,
            gameObjectsListPath = goRel,
            freeCamEnabled = Config.FreeCamEnabled ~= false,
            savedPlacedSetsEnabled = Config.SavedPlacedSetsEnabled ~= false,
            savedPlacedSets = listSavedPlacedSetNamesFromKvp(),
            assembliesEnabled = Config.AssembliesEnabled ~= false,
            ymapEnabled = Config.YmapExportEnabled ~= false,
        })
        sendPlacedListToNui()
        if Config.YmapExportEnabled ~= false then
            TriggerServerEvent("prop_gizmo:listYmapExports")
        end
        CreateThread(function()
            Wait(0)
            if not uiOpen then return end
            SetNuiFocus(true, true)
            Wait(50)
            if uiOpen then SetNuiFocus(true, true) end
        end)
    end)
end

local function resetPlacementInput()
    placementCancelPressed = false
    placeConfirmPressed = false
    placementResetPressed = false
    for k in pairs(placementInput) do
        placementInput[k] = false
    end
    placementSpeedMultiplier = 1.0
end

local function applyPlacementInputMode()
    if not isPlacing then
        SetNuiFocusKeepInput(false)
        return
    end
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(placementFreeMoveEnabled == true)
end

local function runPlacementLoop()
    local stepFwd = Config.PlaceStepForward or 0.05
    local stepSide = Config.PlaceStepSide or 0.05
    local stepUp = Config.PlaceStepUp or 0.05
    local stepRotate = Config.PlaceStepRotate or 3.0
    local stepPitch = Config.PlaceStepPitch or 5.0
    local stepRoll = Config.PlaceStepRoll or 5.0
    local maxDist = 0.0
    if Config.PlaceMovementMaxRadius ~= nil then
        maxDist = tonumber(Config.PlaceMovementMaxRadius) or 0.0
    elseif Config.PlaceMaxDistance ~= nil then
        maxDist = tonumber(Config.PlaceMaxDistance) or 0.0
    end

    while isPlacing and placingProp and DoesEntityExist(placingProp) do
        Wait(0)
        if placementCancelPressed then break end
        if placeConfirmPressed then
            local x, y, z = placingPos.x, placingPos.y, placingPos.z
            local p, r, h = placingPitch, placingRoll, placingHeading
            if placingProp and DoesEntityExist(placingProp) then
                DeleteEntity(placingProp)
            end
            placingProp = nil
            local placePayload = {
                model = placingModel,
                x = x, y = y, z = z,
                heading = h, pitch = p, roll = r,
            }
            local cpmCfg = (type(Config.PlaceCollisionProxyModel) == "string") and Config.PlaceCollisionProxyModel:match("^%s*(.-)%s*$") or ""
            if cpmCfg ~= "" then
                placePayload.collisionProxyModel = cpmCfg
            end
            TriggerServerEvent("prop_gizmo:submitPlace", placePayload)
            break
        end

        local speed = placementSpeedMultiplier <= 0 and 1.0 or placementSpeedMultiplier
        local fwdVec, rightVec = CamFlatForwardRight()

        if placementInput.forward then placingCenterPos = placingCenterPos + fwdVec * (stepFwd * speed) end
        if placementInput.back then placingCenterPos = placingCenterPos - fwdVec * (stepFwd * speed) end
        if placementInput.left then placingCenterPos = placingCenterPos - rightVec * (stepSide * speed) end
        if placementInput.right then placingCenterPos = placingCenterPos + rightVec * (stepSide * speed) end
        if placementInput.heightUp then placingCenterPos = placingCenterPos + vector3(0, 0, stepUp * speed) end
        if placementInput.heightDown then placingCenterPos = placingCenterPos - vector3(0, 0, stepUp * speed) end
        if placementInput.rotLeft then placingHeading = (placingHeading + stepRotate * speed) % 360.0 end
        if placementInput.rotRight then placingHeading = (placingHeading - stepRotate * speed + 360.0) % 360.0 end
        if placementInput.pitchUp then placingPitch = math.min(90.0, placingPitch + stepPitch * speed) end
        if placementInput.pitchDown then placingPitch = math.max(-90.0, placingPitch - stepPitch * speed) end
        if placementInput.rollLeft then placingRoll = (placingRoll + stepRoll * speed) % 360.0 end
        if placementInput.rollRight then placingRoll = (placingRoll - stepRoll * speed + 360.0) % 360.0 end
        if placementResetPressed then
            if placingStartPos then
                placingPos = vector3(placingStartPos.x, placingStartPos.y, placingStartPos.z)
            end
            if placingStartCenterPos then
                placingCenterPos = vector3(placingStartCenterPos.x, placingStartCenterPos.y, placingStartCenterPos.z)
            end
            placingHeading = placingStartHeading
            placingPitch = placingStartPitch
            placingRoll = placingStartRoll
            placementResetPressed = false
        end

        if maxDist > 0 then
            local playerPos = GetPlayerCoords()
            local dx = placingCenterPos.x - playerPos.x
            local dy = placingCenterPos.y - playerPos.y
            local dz = placingCenterPos.z - playerPos.z
            local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
            if dist > maxDist and dist > 0.0001 then
                local scale = maxDist / dist
                placingCenterPos = vector3(
                    playerPos.x + dx * scale,
                    playerPos.y + dy * scale,
                    playerPos.z + dz * scale
                )
            end
        end

        placingPos = calcOriginFromCenter(placingCenterPos, placingPitch, placingRoll, placingHeading, placingModelCenterLocal)

        SetEntityCoords(placingProp, placingPos.x, placingPos.y, placingPos.z, false, false, false, false)
        SetEntityRotation(placingProp, placingPitch, placingRoll, placingHeading, 2, true)
    end

    if placingProp and DoesEntityExist(placingProp) then
        DeleteEntity(placingProp)
    end
    placingProp = nil
    isPlacing = false
    placingModel = nil
    placingStartPos = nil
    placingCenterPos = nil
    placingStartCenterPos = nil
    placingModelCenterLocal = vector3(0.0, 0.0, 0.0)
    resetPlacementInput()
    SendNUIMessage({ action = "hidePlacement" })
    if uiOpen then
        CreateThread(function()
            Wait(0)
            if not uiOpen or isPlacing then return end
            SetNuiFocusKeepInput(false)
            SetNuiFocus(true, true)
            Wait(50)
            if uiOpen and not isPlacing then SetNuiFocus(true, true) end
        end)
    else
        clearNuiFocusStuck()
    end
end

local function pushDisposableAssemblyPreviewEnt(ent)
    if ent and ent ~= 0 and DoesEntityExist(ent) then
        placingAssemblyDisposableEnts[#placingAssemblyDisposableEnts + 1] = ent
    end
end

local function purgeAssemblyPlacementPreviewsMade()
    for _, ent in ipairs(placingAssemblyDisposableEnts) do
        if ent and ent ~= 0 and DoesEntityExist(ent) then
            SetEntityAsMissionEntity(ent, true, true)
            DeleteEntity(ent)
        end
    end
    placingAssemblyDisposableEnts = {}
    placingAssemblyDriveEnt = {}
    placingAssemblyDriveColl = {}
end

local function restoreAssemblyDriveEntitiesFromSnap()
    for id, ent in pairs(placingAssemblyDriveEnt) do
        local s = placingAssemblySnap[id]
        if ent and ent ~= 0 and DoesEntityExist(ent) and s then
            SetEntityCoords(ent, s.x + 0.0, s.y + 0.0, s.z + 0.0, false, false, false, false)
            SetEntityRotation(ent, s.p + 0.0, s.r + 0.0, s.h + 0.0, 2, true)
        end
    end
    for id, cent in pairs(placingAssemblyDriveColl) do
        local s = placingAssemblySnap[id]
        if cent and cent ~= 0 and DoesEntityExist(cent) and s then
            SetEntityCoords(cent, s.x + 0.0, s.y + 0.0, s.z + 0.0, false, false, false, false)
            SetEntityRotation(cent, s.p + 0.0, s.r + 0.0, s.h + 0.0, 2, true)
        end
    end
end

local function finishAssemblyPlacementModeUI()
    isPlacing = false
    placingAssemblyMode = false
    placingAssemblyId = nil
    placingAssemblyMemberIds = {}
    placingAssemblySnap = {}
    placingAssemblyPivot0 = vector3(0.0, 0.0, 0.0)
    resetPlacementInput()
    SendNUIMessage({ action = "hidePlacement" })
    if uiOpen then
        CreateThread(function()
            Wait(0)
            if not uiOpen or isPlacing then return end
            SetNuiFocusKeepInput(false)
            SetNuiFocus(true, true)
            Wait(50)
            if uiOpen and not isPlacing then SetNuiFocus(true, true) end
        end)
    else
        clearNuiFocusStuck()
    end
end

local function runAssemblyPlacementLoop()
    local stepFwd = Config.PlaceStepForward or 0.05
    local stepSide = Config.PlaceStepSide or 0.05
    local stepUp = Config.PlaceStepUp or 0.05
    local stepRotate = Config.PlaceStepRotate or 3.0
    local stepPitch = Config.PlaceStepPitch or 5.0
    local stepRoll = Config.PlaceStepRoll or 5.0
    local maxDist = 0.0
    if Config.PlaceMovementMaxRadius ~= nil then
        maxDist = tonumber(Config.PlaceMovementMaxRadius) or 0.0
    elseif Config.PlaceMaxDistance ~= nil then
        maxDist = tonumber(Config.PlaceMaxDistance) or 0.0
    end
    local pv = placingAssemblyPivot0

    while isPlacing and placingAssemblyMode do
        Wait(0)
        if placementCancelPressed then
            restoreAssemblyDriveEntitiesFromSnap()
            purgeAssemblyPlacementPreviewsMade()
            finishAssemblyPlacementModeUI()
            break
        end
        if placeConfirmPressed then
            local rows = {}
            for _, id in ipairs(placingAssemblyMemberIds) do
                local ent = placingAssemblyDriveEnt[id]
                if ent and DoesEntityExist(ent) then
                    local c = GetEntityCoords(ent, true, true)
                    local rot = GetEntityRotation(ent, 2)
                    local hz = tonumber(rot.z) or 0.0
                    local pxv = tonumber(rot.x) or 0.0
                    local rlv = tonumber(rot.y) or 0.0
                    rows[#rows + 1] = {
                        id = id,
                        x = c.x + 0.0, y = c.y + 0.0, z = c.z + 0.0,
                        heading = hz + 0.0, pitch = pxv + 0.0, roll = rlv + 0.0,
                    }
                end
            end
            purgeAssemblyPlacementPreviewsMade()
            TriggerServerEvent("prop_gizmo:submitAssemblyMove", rows)
            finishAssemblyPlacementModeUI()
            break
        end

        local speed = placementSpeedMultiplier <= 0 and 1.0 or placementSpeedMultiplier
        local fwdVec, rightVec = CamFlatForwardRight()

        if placementInput.forward then placingCenterPos = placingCenterPos + fwdVec * (stepFwd * speed) end
        if placementInput.back then placingCenterPos = placingCenterPos - fwdVec * (stepFwd * speed) end
        if placementInput.left then placingCenterPos = placingCenterPos - rightVec * (stepSide * speed) end
        if placementInput.right then placingCenterPos = placingCenterPos + rightVec * (stepSide * speed) end
        if placementInput.heightUp then placingCenterPos = placingCenterPos + vector3(0, 0, stepUp * speed) end
        if placementInput.heightDown then placingCenterPos = placingCenterPos - vector3(0, 0, stepUp * speed) end
        if placementInput.rotLeft then placingHeading = (placingHeading + stepRotate * speed) % 360.0 end
        if placementInput.rotRight then placingHeading = (placingHeading - stepRotate * speed + 360.0) % 360.0 end
        if placementInput.pitchUp then placingPitch = math.min(90.0, placingPitch + stepPitch * speed) end
        if placementInput.pitchDown then placingPitch = math.max(-90.0, placingPitch - stepPitch * speed) end
        if placementInput.rollLeft then placingRoll = (placingRoll + stepRoll * speed) % 360.0 end
        if placementInput.rollRight then placingRoll = (placingRoll - stepRoll * speed + 360.0) % 360.0 end
        if placementResetPressed then
            placingCenterPos = vector3(placingAssemblyPivot0.x, placingAssemblyPivot0.y, placingAssemblyPivot0.z)
            placingHeading = 0.0
            placingPitch = 0.0
            placingRoll = 0.0
            placementResetPressed = false
        end

        if maxDist > 0 then
            local playerPos = GetPlayerCoords()
            local dx = placingCenterPos.x - playerPos.x
            local dy = placingCenterPos.y - playerPos.y
            local dz = placingCenterPos.z - playerPos.z
            local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
            if dist > maxDist and dist > 0.0001 then
                local scale = maxDist / dist
                placingCenterPos = vector3(
                    playerPos.x + dx * scale,
                    playerPos.y + dy * scale,
                    playerPos.z + dz * scale
                )
            end
        end

        local dH = placingHeading
        local dP = placingPitch
        local dR = placingRoll
        for _, id in ipairs(placingAssemblyMemberIds) do
            local s = placingAssemblySnap[id]
            local ent = placingAssemblyDriveEnt[id]
            local coll = placingAssemblyDriveColl[id]
            if s and ent and DoesEntityExist(ent) then
                local relx = s.x - pv.x
                local rely = s.y - pv.y
                local relz = s.z - pv.z
                local rx, ry = AsmRotFlatXY(relx, rely, dH)
                local nx = placingCenterPos.x + rx
                local ny = placingCenterPos.y + ry
                local nz = placingCenterPos.z + relz
                local nh = NormAngle360(s.h + dH)
                local np = s.p + dP
                local nr = s.r + dR
                SetEntityCoords(ent, nx, ny, nz, false, false, false, false)
                SetEntityRotation(ent, np, nr, nh, 2, true)
                if coll and DoesEntityExist(coll) then
                    SetEntityCoords(coll, nx, ny, nz, false, false, false, false)
                    SetEntityRotation(coll, np, nr, nh, 2, true)
                end
            end
        end
    end
end

local function startAssemblyAdjustPlacement(assemblyId)
    if Config.AssembliesEnabled == false then
        gizmoNotify(tr("assemblyDisabled"), 6000)
        return
    end
    if isPlacing or not uiOpen then return end
    if type(assemblyId) ~= "string" or assemblyId == "" then return end
    local ids = {}
    for _, oid in ipairs(placedOrder) do
        local e = placedById[oid]
        if e and e.assemblyId == assemblyId then
            ids[#ids + 1] = oid
        end
    end
    if #ids == 0 then
        gizmoNotify(tr("assemblyMoveNoMembers"), 7000)
        return
    end

    placingAssemblySnap = {}
    local sx, sy, sz = 0.0, 0.0, 0.0
    for _, id in ipairs(ids) do
        local e = placedById[id]
        if not e then return end
        placingAssemblySnap[id] = { x = e.x, y = e.y, z = e.z, h = e.heading, p = e.pitch, r = e.roll }
        sx, sy, sz = sx + e.x, sy + e.y, sz + e.z
    end
    local invn = 1.0 / #ids
    placingAssemblyPivot0 = vector3(sx * invn, sy * invn, sz * invn)
    placingAssemblyMemberIds = ids
    placingAssemblyId = assemblyId

    placingAssemblyDriveEnt = {}
    placingAssemblyDriveColl = {}
    placingAssemblyDisposableEnts = {}
    for _, id in ipairs(ids) do
        local e = placedById[id]
        local s = placingAssemblySnap[id]
        local ent = e.entity
        placingAssemblyDriveColl[id] = nil
        local cproxy = (type(e.collisionProxyModel) == "string" and e.collisionProxyModel ~= "") and e.collisionProxyModel or nil
        local collPersist = e.collisionEntity and e.collisionEntity ~= 0 and DoesEntityExist(e.collisionEntity) and e.collisionEntity or nil

        if ent and ent ~= 0 and DoesEntityExist(ent) then
            placingAssemblyDriveEnt[id] = ent
        else
            ent = spawnWorldProp(e.model, s.x, s.y, s.z, s.h, s.p, s.r)
            if not ent then
                gizmoNotify(tr("assemblyMovePreviewFail"), 8000)
                purgeAssemblyPlacementPreviewsMade()
                placingAssemblySnap = {}
                placingAssemblyMemberIds = {}
                placingAssemblyId = nil
                return
            end
            placingAssemblyDriveEnt[id] = ent
            pushDisposableAssemblyPreviewEnt(ent)
        end

        if cproxy then
            if collPersist then
                placingAssemblyDriveColl[id] = collPersist
            else
                local cent = spawnWorldCollisionProxyCompanion(cproxy, s.x, s.y, s.z, s.h, s.p, s.r)
                if cent then
                    placingAssemblyDriveColl[id] = cent
                    pushDisposableAssemblyPreviewEnt(cent)
                end
            end
        end
    end

    placingCenterPos = vector3(placingAssemblyPivot0.x, placingAssemblyPivot0.y, placingAssemblyPivot0.z)
    placingHeading = 0.0
    placingPitch = 0.0
    placingRoll = 0.0
    placingStartHeading = 0.0
    placingStartPitch = 0.0
    placingStartRoll = 0.0
    placementFreeMoveEnabled = false
    resetPlacementInput()
    placingAssemblyMode = true
    isPlacing = true

    local smin = Config.PlaceSpeedSliderMin or 5
    local smax = Config.PlaceSpeedSliderMax or 100
    local sstep = Config.PlaceSpeedSliderStep or 5
    local spct = math.max(smin, math.min(smax, math.floor(placementSpeedMultiplier * 100 + 0.5)))

    SendNUIMessage({
        action = "showPlacement",
        model = tr("assemblyPlaceLabel") .. (" (%d)"):format(#ids),
        speedMin = smin,
        speedMax = smax,
        speedStep = sstep,
        speedPercent = spct,
        placementAssembly = true,
        pedAdjust = false,
    })
    applyPlacementInputMode()
    CreateThread(runAssemblyPlacementLoop)
end

local function startPlacement(model)
    if placingAssemblyMode or type(model) ~= "string" or model == "" or isPlacing then return end
    if not uiOpen then return end
    local hash = resolvePlacementModelHash(model)
    if not hash then return end
    gizmoNotify(tr("placementLoading"), 4000)
    local camZ = GetGameplayCamRot(2).z
    local fwd = GetForwardVector(camZ)
    local dist = Config.SpawnDistance or 1.8
    local zoff = Config.SpawnHeightOffset or 0.35
    local start = GetPlayerCoords() + vector3(0, 0, zoff) + fwd * dist

    placingHeading = NormAngle360(camZ)
    placingPitch = 0.0
    placingRoll = 0.0

    placingModelCenterLocal = modelCenterLocalForHash(hash)
    local q0 = QuatFromEulerDeg(placingPitch, placingRoll, placingHeading)
    local centerWorld0 = QuatRotateVec(q0, placingModelCenterLocal)
    placingCenterPos = vector3(
        start.x + centerWorld0.x,
        start.y + centerWorld0.y,
        start.z + centerWorld0.z
    )
    placingPos = calcOriginFromCenter(placingCenterPos, placingPitch, placingRoll, placingHeading, placingModelCenterLocal)

    placingStartPos = vector3(placingPos.x, placingPos.y, placingPos.z)
    placingStartCenterPos = vector3(placingCenterPos.x, placingCenterPos.y, placingCenterPos.z)
    placingStartHeading = placingHeading
    placingStartPitch = placingPitch
    placingStartRoll = placingRoll
    placementFreeMoveEnabled = false
    resetPlacementInput()

    placingProp = spawnPreviewObject(model, placingPos.x, placingPos.y, placingPos.z, placingHeading, placingPitch, placingRoll)
    if not placingProp then
        local tip = spooniCatalogModelNames[model] and tr("spooniPaidProp") or tr("modelLoadFail")
        gizmoNotify(tip, 9000)
        if not spooniCatalogModelNames[model] then
            gizmoNotify(tr("modelLoadFailHint"), 14000)
        end
        return
    end

    isPlacing = true
    do
        local canon = canonicalPropModelName(model)
        placingModel = (canon ~= "" and canon) or (model:match("^%s*(.-)%s*$") or model)
    end

    local smin = Config.PlaceSpeedSliderMin or 5
    local smax = Config.PlaceSpeedSliderMax or 100
    local sstep = Config.PlaceSpeedSliderStep or 5
    local spct = math.floor(placementSpeedMultiplier * 100 + 0.5)
    spct = math.max(smin, math.min(smax, spct))

    SendNUIMessage({
        action = "showPlacement",
        model = placingModel,
        speedMin = smin,
        speedMax = smax,
        speedStep = sstep,
        speedPercent = spct,
    })
    applyPlacementInputMode()
    CreateThread(runPlacementLoop)
end

local function runPedAdjustLoop()
    local stepFwd = Config.PlaceStepForward or 0.05
    local stepSide = Config.PlaceStepSide or 0.05
    local stepUp = Config.PlaceStepUp or 0.05
    local stepRotate = Config.PlaceStepRotate or 3.0
    local maxDist = 0.0
    if Config.PlaceMovementMaxRadius ~= nil then
        maxDist = tonumber(Config.PlaceMovementMaxRadius) or 0.0
    elseif Config.PlaceMaxDistance ~= nil then
        maxDist = tonumber(Config.PlaceMaxDistance) or 0.0
    end

    while isPlacing and placingAdjustPedEntity and DoesEntityExist(placingAdjustPedEntity) do
        Wait(0)
        if placementCancelPressed then
            if placingAdjustPedSnap then
                SetEntityCoords(
                    placingAdjustPedEntity,
                    placingAdjustPedSnap.x, placingAdjustPedSnap.y, placingAdjustPedSnap.z,
                    false, false, false, false
                )
                SetEntityHeading(placingAdjustPedEntity, placingAdjustPedSnap.h)
                local e = localPlacedPedsById[placingAdjustPedRowId]
                if e then
                    e.x = placingAdjustPedSnap.x
                    e.y = placingAdjustPedSnap.y
                    e.z = placingAdjustPedSnap.z
                    e.heading = placingAdjustPedSnap.h
                end
            end
            break
        end
        if placeConfirmPressed then
            local e = localPlacedPedsById[placingAdjustPedRowId]
            if e and placingAdjustPedEntity and DoesEntityExist(placingAdjustPedEntity) then
                local c = GetEntityCoords(placingAdjustPedEntity, true, true)
                e.x, e.y, e.z = c.x, c.y, c.z
                e.heading = GetEntityHeading(placingAdjustPedEntity)
            end
            sendPlacedListToNui()
            break
        end

        local speed = placementSpeedMultiplier <= 0 and 1.0 or placementSpeedMultiplier
        local fwdVec, rightVec = CamFlatForwardRight()

        if placementInput.forward then placingPos = placingPos + fwdVec * (stepFwd * speed) end
        if placementInput.back then placingPos = placingPos - fwdVec * (stepFwd * speed) end
        if placementInput.left then placingPos = placingPos - rightVec * (stepSide * speed) end
        if placementInput.right then placingPos = placingPos + rightVec * (stepSide * speed) end
        if placementInput.heightUp then placingPos = placingPos + vector3(0, 0, stepUp * speed) end
        if placementInput.heightDown then placingPos = placingPos - vector3(0, 0, stepUp * speed) end
        if placementInput.rotLeft then placingHeading = (placingHeading + stepRotate * speed) % 360.0 end
        if placementInput.rotRight then placingHeading = (placingHeading - stepRotate * speed + 360.0) % 360.0 end

        if placementResetPressed and placingAdjustPedSnap then
            placingPos = vector3(placingAdjustPedSnap.x, placingAdjustPedSnap.y, placingAdjustPedSnap.z)
            placingHeading = placingAdjustPedSnap.h
            placementResetPressed = false
        end

        if maxDist > 0 then
            local playerPos = GetPlayerCoords()
            local dx = placingPos.x - playerPos.x
            local dy = placingPos.y - playerPos.y
            local dz = placingPos.z - playerPos.z
            local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
            if dist > maxDist and dist > 0.0001 then
                local scale = maxDist / dist
                placingPos = vector3(
                    playerPos.x + dx * scale,
                    playerPos.y + dy * scale,
                    playerPos.z + dz * scale
                )
            end
        end

        SetEntityCoords(placingAdjustPedEntity, placingPos.x, placingPos.y, placingPos.z, false, false, false, false)
        SetEntityHeading(placingAdjustPedEntity, placingHeading)
    end

    placingAdjustPedEntity = nil
    placingAdjustPedRowId = nil
    placingAdjustPedSnap = nil
    isPlacing = false
    resetPlacementInput()
    SendNUIMessage({ action = "hidePlacement" })
    if uiOpen then
        CreateThread(function()
            Wait(0)
            if not uiOpen or isPlacing then return end
            SetNuiFocusKeepInput(false)
            SetNuiFocus(true, true)
            Wait(50)
            if uiOpen and not isPlacing then SetNuiFocus(true, true) end
        end)
    else
        clearNuiFocusStuck()
    end
end

local function startPedAdjustPlacement(rowId)
    if isPlacing then return end
    if not uiOpen then return end
    if type(rowId) ~= "string" then return end
    local e = localPlacedPedsById[rowId]
    if not e or not e.ped or e.ped == 0 or not DoesEntityExist(e.ped) then
        gizmoNotify(tr("pedAdjustMissing"), 5000)
        return
    end
    isPlacing = true
    placingProp = nil
    placingAdjustPedEntity = e.ped
    placingAdjustPedRowId = rowId
    local pos = GetEntityCoords(e.ped, true, true)
    placingAdjustPedSnap = { x = pos.x, y = pos.y, z = pos.z, h = GetEntityHeading(e.ped) }
    placingPos = vector3(pos.x, pos.y, pos.z)
    placingHeading = placingAdjustPedSnap.h
    placingPitch = 0.0
    placingRoll = 0.0
    placementFreeMoveEnabled = false
    resetPlacementInput()
    local smin = Config.PlaceSpeedSliderMin or 5
    local smax = Config.PlaceSpeedSliderMax or 100
    local sstep = Config.PlaceSpeedSliderStep or 5
    local spct = math.floor(placementSpeedMultiplier * 100 + 0.5)
    spct = math.max(smin, math.min(smax, spct))
    SendNUIMessage({
        action = "showPlacement",
        model = (e.model or "?") .. " [ped]",
        speedMin = smin,
        speedMax = smax,
        speedStep = sstep,
        speedPercent = spct,
        pedAdjust = true,
    })
    applyPlacementInputMode()
    CreateThread(runPedAdjustLoop)
end

local function resolveLocalPedRowId(data)
    if type(data) ~= "table" then return nil end
    if type(data.pedId) == "string" and data.pedId ~= "" then
        return data.pedId
    end
    local slot = data.pedSlot
    if slot == "a" then return pairPedSlotA end
    if slot == "b" then return pairPedSlotB end
    return nil
end

local function createAndRegisterLocalPedAt(model, x, y, z, heading)
    if type(model) ~= "string" or model == "" then return nil end
    local hash = joaat(model)
    if not LoadModel(hash) then return nil end
    local npc = CreatePed(hash, x + 0.0, y + 0.0, z + 0.0, heading + 0.0, false, true, true, true)
    if not npc or npc == 0 or not DoesEntityExist(npc) then
        SetModelAsNoLongerNeeded(hash)
        return nil
    end
    SetEntityAsMissionEntity(npc, true, true)
    Citizen.InvokeNative(0x283978A15512B2FE, npc, true)
    Citizen.InvokeNative(0x9587913B9E772D29, npc, true)
    SetModelAsNoLongerNeeded(hash)
    local rowId = generateLocalPedRowId()
    local pos = GetEntityCoords(npc, true, true)
    local entry = {
        id = rowId,
        model = model,
        x = pos.x, y = pos.y, z = pos.z,
        heading = GetEntityHeading(npc),
        ped = npc,
        invincible = false,
        frozen = false,
        scenario = nil,
        animDict = nil,
        animName = nil,
    }
    localPlacedPedsById[rowId] = entry
    localPlacedPedsOrder[#localPlacedPedsOrder + 1] = rowId
    applyLocalPedFlags(entry)
    return rowId
end

RegisterCommand("gizmo", function()
    if uiOpen then
        closeUi()
    else
        openUi()
    end
end, false)

RegisterNUICallback("close", function(_, cb)
    if isPlacing then
        cb("ok")
        return
    end
    closeUi()
    cb("ok")
end)

RegisterNUICallback("freecamStart", function(_, cb)
    if isPlacing then
        cb("ok")
        return
    end
    if Config.FreeCamEnabled == false then
        cb("ok")
        return
    end
    closeUi()
    PropGizmo_ForceReleaseNuiAndCursor()
    CreateThread(function()
        for _ = 1, 8 do
            Wait(0)
            SetNuiFocus(false, false)
        end
        Wait(280)
        TriggerEvent("prop_gizmo:freecamStart")
    end)
    cb("ok")
end)

RegisterNUICallback("beginPlace", function(data, cb)
    local m = data and data.model
    if type(m) == "string" then
        startPlacement(m)
    end
    cb("ok")
end)

RegisterNUICallback("spawnPedAtPlayer", function(data, cb)
    local m = data and data.model
    if type(m) ~= "string" or m == "" or isPlacing then cb("ok") return end
    if not uiOpen then cb("ok") return end
    local camZ = GetGameplayCamRot(2).z
    local fwd = GetForwardVector(camZ)
    local p = GetPlayerCoords()
    local dist = tonumber(Config.PedSpawnDistance) or 2.5
    local zoff = tonumber(Config.PedSpawnHeightOffset) or 0.0
    local x, y, z = p.x + fwd.x * dist, p.y + fwd.y * dist, p.z + zoff
    local heading = NormAngle360(camZ + 180.0)
    local rowId = createAndRegisterLocalPedAt(m, x, y, z, heading)
    if not rowId then
        gizmoNotify(tr("pedLoadFail"), 7000)
        cb("ok")
        return
    end
    sendPlacedListToNui()
    gizmoNotify(tr("pedSpawnOk"), 5000)
    cb("ok")
end)

RegisterNUICallback("beginPlaceBlip", function(data, cb)
    local name = data and data.name
    if type(name) == "string" and name ~= "" then
        local p = GetPlayerCoords()
        TriggerServerEvent("prop_gizmo:submitBlip", {
            name = name,
            x = p.x, y = p.y, z = p.z,
        })
    end
    cb("ok")
end)

RegisterNUICallback("placementSetSpeed", function(data, cb)
    local p = data and tonumber(data.percent)
    if not p then cb("ok") return end
    local smin = Config.PlaceSpeedSliderMin or 5
    local smax = Config.PlaceSpeedSliderMax or 100
    p = math.max(smin, math.min(smax, p))
    placementSpeedMultiplier = p / 100.0
    cb("ok")
end)

RegisterNUICallback("placementMove", function(data, cb)
    local dir = data and data.direction
    local pressed = data.pressed == true
    if dir == "forward" then placementInput.forward = pressed
    elseif dir == "back" then placementInput.back = pressed
    elseif dir == "left" then placementInput.left = pressed
    elseif dir == "right" then placementInput.right = pressed
    elseif dir == "rotLeft" then placementInput.rotLeft = pressed
    elseif dir == "rotRight" then placementInput.rotRight = pressed
    elseif dir == "heightUp" then placementInput.heightUp = pressed
    elseif dir == "heightDown" then placementInput.heightDown = pressed
    elseif dir == "pitchUp" then placementInput.pitchUp = pressed
    elseif dir == "pitchDown" then placementInput.pitchDown = pressed
    elseif dir == "rollLeft" then placementInput.rollLeft = pressed
    elseif dir == "rollRight" then placementInput.rollRight = pressed
    end
    cb("ok")
end)

RegisterNUICallback("placeConfirm", function(_, cb)
    placeConfirmPressed = true
    cb("ok")
end)

RegisterNUICallback("placementReset", function(_, cb)
    placementResetPressed = true
    cb("ok")
end)

RegisterNUICallback("placementSetFreeMove", function(data, cb)
    placementFreeMoveEnabled = data and data.enabled == true
    applyPlacementInputMode()
    cb("ok")
end)

RegisterNUICallback("placementCancel", function(_, cb)
    placementCancelPressed = true
    cb("ok")
end)

RegisterNUICallback("placedTeleport", function(data, cb)
    local id = data and data.id
    if not id then cb("ok") return end
    local e = placedById[id] or placedBlipsById[id] or localPlacedPedsById[id]
    if not e then cb("ok") return end
    local px, py, pz = e.x, e.y, e.z
    if e.ped and e.ped ~= 0 and DoesEntityExist(e.ped) then
        local c = GetEntityCoords(e.ped, true, true)
        px, py, pz = c.x, c.y, c.z
    end
    local ped = PlayerPedId()
    SetEntityCoords(ped, px, py, pz + 0.5, false, false, false, false)
    cb("ok")
end)

RegisterNUICallback("placedDelete", function(data, cb)
    local id = data and data.id
    local kind = data and data.kind
    if id then
        if kind == "blip" then
            TriggerServerEvent("prop_gizmo:removeBlip", id)
        elseif kind == "ped" then
            removeLocalPlacedPed(id)
            sendPlacedListToNui()
        else
            TriggerServerEvent("prop_gizmo:removeProp", id)
        end
    end
    cb("ok")
end)

RegisterNUICallback("placedPedSetFlags", function(data, cb)
    local id = data and data.id
    if not id or type(id) ~= "string" then cb("ok") return end
    local e = localPlacedPedsById[id]
    if not e then cb("ok") return end
    if data.invincible ~= nil then
        e.invincible = data.invincible == true
    end
    if data.frozen ~= nil then
        e.frozen = data.frozen == true
    end
    applyLocalPedFlags(e)
    sendPlacedListToNui()
    cb("ok")
end)

RegisterNUICallback("setPairPedSlot", function(data, cb)
    if type(data) ~= "table" then cb("ok") return end
    local slot = data.slot
    local id = data.id
    if (slot ~= "a" and slot ~= "b") or type(id) ~= "string" then cb("ok") return end
    if slot == "a" then
        pairPedSlotA = id
        if pairPedSlotB == id then pairPedSlotB = nil end
    else
        pairPedSlotB = id
        if pairPedSlotA == id then pairPedSlotA = nil end
    end
    SendNUIMessage({ action = "pairSlots", slotA = pairPedSlotA, slotB = pairPedSlotB })
    cb("ok")
end)

RegisterNUICallback("pedPlayScenario", function(data, cb)
    local id = resolveLocalPedRowId(data)
    local scenario = data and data.scenario
    if type(scenario) == "string" then
        scenario = scenario:match("^%s*(.-)%s*$") or scenario
    end
    if not id or type(scenario) ~= "string" or scenario == "" then cb("ok") return end
    local e = localPlacedPedsById[id]
    if not e or not e.ped or e.ped == 0 or not DoesEntityExist(e.ped) then cb("ok") return end
    if tryPlayScenarioOnPed(e.ped, scenario) then
        e.scenario = scenario
        e.animDict = nil
        e.animName = nil
        e.frozen = false
        applyLocalPedFlags(e)
        gizmoNotify(tr("scenarioApplied"), 4000)
    end
    sendPlacedListToNui()
    cb("ok")
end)

RegisterNUICallback("pedPlayClip", function(data, cb)
    local id = resolveLocalPedRowId(data)
    local dict = data and data.dict
    local anim = data and data.anim
    if not id or type(dict) ~= "string" or type(anim) ~= "string" then cb("ok") return end
    local e = localPlacedPedsById[id]
    if not e or not e.ped or e.ped == 0 or not DoesEntityExist(e.ped) then cb("ok") return end
    if tryPlayAnimOnPed(e.ped, dict, anim) then
        e.animDict = dict
        e.animName = anim
        e.scenario = nil
        gizmoNotify(tr("animApplied"), 4000)
    else
        gizmoNotify(tr("animDictMissing"), 6000)
    end
    sendPlacedListToNui()
    cb("ok")
end)

RegisterNUICallback("beginPedAdjust", function(data, cb)
    local id = resolveLocalPedRowId(data)
    if not id and type(data) == "table" and type(data.id) == "string" then
        id = data.id
    end
    if type(id) == "string" then
        startPedAdjustPlacement(id)
    end
    cb("ok")
end)

RegisterNUICallback("exportPairScene", function(_, cb)
    local peds = {}
    local function push(slot, rowId)
        if type(rowId) ~= "string" then return end
        local e = localPlacedPedsById[rowId]
        if not e then return end
        local x, y, z = e.x, e.y, e.z
        local h = tonumber(e.heading) or 0.0
        if e.ped and e.ped ~= 0 and DoesEntityExist(e.ped) then
            local c = GetEntityCoords(e.ped, true, true)
            x, y, z = c.x, c.y, c.z
            h = GetEntityHeading(e.ped)
        end
        peds[#peds + 1] = {
            slot = slot,
            model = e.model,
            x = x, y = y, z = z,
            heading = h,
            scenario = e.scenario,
            animDict = e.animDict,
            animName = e.animName,
        }
    end
    push("a", pairPedSlotA)
    push("b", pairPedSlotB)
    local payload = { format = "vorp_prop_gizmo_pairscene_v1", peds = peds }
    local ok, jsonStr = pcall(json.encode, payload)
    if ok and type(jsonStr) == "string" then
        SendNUIMessage({ action = "clipboardText", text = jsonStr, hint = tr("pairExportCopied") })
    end
    cb("ok")
end)

RegisterNUICallback("exportPlacedPropsJson", function(_, cb)
    local rows = {}
    for _, id in ipairs(placedOrder) do
        local e = placedById[id]
        if e then
            local r = {
                model = e.model,
                x = e.x, y = e.y, z = e.z,
                heading = e.heading, pitch = e.pitch, roll = e.roll,
            }
            if type(e.collisionProxyModel) == "string" and e.collisionProxyModel ~= "" then
                r.collisionProxyModel = e.collisionProxyModel
            end
            rows[#rows + 1] = r
        end
    end
    local payload = { format = "vorp_prop_gizmo_placements_v1", props = rows }
    local ok, jsonStr = pcall(json.encode, payload)
    if ok and type(jsonStr) == "string" then
        SendNUIMessage({ action = "clipboardText", text = jsonStr, hint = tr("propsExportCopied") })
    end
    cb("ok")
end)

RegisterNUICallback("importPairScene", function(data, cb)
    local raw = data and data.json
    if type(raw) ~= "string" or raw == "" then cb("ok") return end
    local ok, t = pcall(json.decode, raw)
    if not ok or type(t) ~= "table" or t.format ~= "vorp_prop_gizmo_pairscene_v1" or type(t.peds) ~= "table" then
        gizmoNotify(tr("pairImportFail"), 7000)
        cb("ok")
        return
    end
    pairPedSlotA = nil
    pairPedSlotB = nil
    for _, row in ipairs(t.peds) do
        if type(row) == "table" and type(row.model) == "string" then
            local x, y, z = tonumber(row.x), tonumber(row.y), tonumber(row.z)
            local h = tonumber(row.heading) or 0.0
            if x and y and z then
                local newId = createAndRegisterLocalPedAt(row.model, x, y, z, h)
                if newId then
                    local e = localPlacedPedsById[newId]
                    if e then
                        if type(row.scenario) == "string" and row.scenario ~= "" then
                            tryPlayScenarioOnPed(e.ped, row.scenario)
                            e.scenario = row.scenario
                        elseif type(row.animDict) == "string" and type(row.animName) == "string" then
                            tryPlayAnimOnPed(e.ped, row.animDict, row.animName)
                            e.animDict = row.animDict
                            e.animName = row.animName
                        end
                    end
                    if row.slot == "a" then pairPedSlotA = newId end
                    if row.slot == "b" then pairPedSlotB = newId end
                end
            end
        end
    end
    sendPlacedListToNui()
    SendNUIMessage({ action = "pairSlots", slotA = pairPedSlotA, slotB = pairPedSlotB })
    gizmoNotify(tr("pairImportOk"), 5000)
    cb("ok")
end)

RegisterNUICallback("refreshPlaced", function(_, cb)
    sendPlacedListToNui()
    cb("ok")
end)

RegisterNUICallback("savePlacedSavedSet", function(data, cb)
    if Config.SavedPlacedSetsEnabled == false then
        gizmoNotify(tr("savedSetDisabled"), 6000)
        cb("ok")
        return
    end
    local name = sanitizeSavedPlacedSetName(data and data.name or "")
    if not name then
        gizmoNotify(tr("savedSetBadName"), 7000)
        cb("ok")
        return
    end
    local props = collectPlacedPropsForSavedSetPayload()
    local maxN = math.max(1, math.floor(tonumber(Config.SavedPlacedSetMaxProps) or 800))
    if #props > maxN then
        gizmoNotify(tr("savedSetTooBig"), 9000)
        cb("ok")
        return
    end
    if #props == 0 then
        gizmoNotify(tr("savedSetEmpty"), 7000)
        cb("ok")
        return
    end
    local payload = {
        format = "vorp_prop_gizmo_saved_set_v1",
        version = 1,
        savedAtMs = GetGameTimer(),
        props = props,
    }
    local ok, enc = pcall(json.encode, payload)
    if not ok or type(enc) ~= "string" then
        cb("ok")
        return
    end
    SetResourceKvp(SAVED_PLACED_KVP_PREFIX .. name, enc)
    gizmoNotify(tr("savedSetSaved"), 6000)
    pushSavedPlacedSetNamesToNui()
    cb("ok")
end)

RegisterNUICallback("deletePlacedSavedSet", function(data, cb)
    if Config.SavedPlacedSetsEnabled == false then
        cb("ok")
        return
    end
    local name = sanitizeSavedPlacedSetName(data and data.name or "")
    if name then DeleteResourceKvp(SAVED_PLACED_KVP_PREFIX .. name) end
    pushSavedPlacedSetNamesToNui()
    cb("ok")
end)

RegisterNUICallback("applyPlacedSavedSet", function(data, cb)
    if Config.SavedPlacedSetsEnabled == false then
        gizmoNotify(tr("savedSetDisabled"), 6000)
        cb("ok")
        return
    end
    local name = sanitizeSavedPlacedSetName(data and data.name or "")
    if not name then
        gizmoNotify(tr("savedSetBadName"), 7000)
        cb("ok")
        return
    end
    local replace = data and data.replace == true
    local raw = GetResourceKvpString(SAVED_PLACED_KVP_PREFIX .. name)
    if type(raw) ~= "string" or raw == "" then
        gizmoNotify(tr("savedSetNotFound"), 7000)
        cb("ok")
        return
    end
    local ok, t = pcall(json.decode, raw)
    local props
    if ok and type(t) == "table" then
        local fmt = t.format
        if fmt == "vorp_prop_gizmo_saved_set_v1" or fmt == "vorp_prop_gizmo_placements_v1" then
            props = t.props
        end
    end
    if type(props) ~= "table" then
        gizmoNotify(tr("savedSetBadFile"), 8000)
        cb("ok")
        return
    end
    local maxN = math.max(1, math.floor(tonumber(Config.SavedPlacedSetMaxProps) or 800))
    if #props > maxN then
        gizmoNotify(tr("savedSetTooBig"), 9000)
        cb("ok")
        return
    end
    TriggerServerEvent("prop_gizmo:applySavedPropSet", { props = props, replace = replace })
    cb("ok")
end)

RegisterNUICallback("setPropGroup", function(data, cb)
    if type(data) == "table" and type(data.id) == "string" then
        TriggerServerEvent("prop_gizmo:setPropGroup", {
            id = data.id,
            group = type(data.group) == "string" and data.group or "",
        })
    end
    cb("ok")
end)

RegisterNUICallback("setPropGroupBatch", function(data, cb)
    if type(data) == "table" and type(data.propIds) == "table" then
        TriggerServerEvent("prop_gizmo:setPropGroupBatch", {
            propIds = data.propIds,
            group = type(data.group) == "string" and data.group or "",
        })
    end
    cb("ok")
end)

RegisterNUICallback("requestYmapFileList", function(_, cb)
    TriggerServerEvent("prop_gizmo:listYmapExports")
    cb("ok")
end)

RegisterNUICallback("exportYmap", function(data, cb)
    if type(data) == "table" then
        TriggerServerEvent("prop_gizmo:exportYmap", data)
    end
    cb("ok")
end)

RegisterNUICallback("importYmap", function(data, cb)
    if type(data) == "table" then
        TriggerServerEvent("prop_gizmo:importYmap", data)
    end
    cb("ok")
end)

RegisterNetEvent("prop_gizmo:ymapExportResult", function(payload)
    if type(payload) ~= "table" then return end
    if type(payload.xml) == "string" and payload.xml ~= "" then
        SendNUIMessage({
            action = "clipboardText",
            text = payload.xml,
            hint = tr("ymapExportCopied"),
        })
    end
    SendNUIMessage({ action = "ymapExportResult", result = payload })
end)

RegisterNetEvent("prop_gizmo:ymapFileList", function(names)
    SendNUIMessage({ action = "ymapFileList", names = type(names) == "table" and names or {} })
end)

RegisterNUICallback("createPropAssembly", function(data, cb)
    if type(data) == "table" and type(data.propIds) == "table" then
        TriggerServerEvent("prop_gizmo:createAssembly", { propIds = data.propIds })
    end
    cb("ok")
end)

RegisterNUICallback("dissolvePropAssembly", function(data, cb)
    if type(data) == "table" and type(data.assemblyId) == "string" then
        TriggerServerEvent("prop_gizmo:dissolveAssembly", { assemblyId = data.assemblyId })
    end
    cb("ok")
end)

RegisterNUICallback("leavePropAssemblyProp", function(data, cb)
    if type(data) == "table" and type(data.propId) == "string" then
        TriggerServerEvent("prop_gizmo:leaveAssemblyProp", { propId = data.propId })
    end
    cb("ok")
end)

RegisterNUICallback("beginAssemblyAdjust", function(data, cb)
    if type(data) == "table" and type(data.assemblyId) == "string" then
        startAssemblyAdjustPlacement(data.assemblyId)
    end
    cb("ok")
end)

RegisterNUICallback("playerSkinApply", function(data, cb)
    if type(data) == "table" and type(data.model) == "string" then
        TriggerServerEvent("prop_gizmo:setPersistedPlayerSkin", {
            model = data.model,
            targetSteam = type(data.targetSteam) == "string" and data.targetSteam or "",
            targetServerId = data.targetServerId,
        })
    end
    cb("ok")
end)

RegisterNUICallback("createPlacedFolder", function(data, cb)
    if type(data) == "table" and type(data.name) == "string" then
        TriggerServerEvent("prop_gizmo:createPlacedFolder", { name = data.name })
    end
    cb("ok")
end)

RegisterNUICallback("addPlacedPropToFolder", function(data, cb)
    if type(data) == "table" and type(data.folderId) == "string" and type(data.propId) == "string" then
        TriggerServerEvent("prop_gizmo:addPlacedPropToFolder", {
            folderId = data.folderId,
            propId = data.propId,
        })
    end
    cb("ok")
end)

RegisterNUICallback("removePlacedPropFromFolder", function(data, cb)
    if type(data) == "table" and type(data.folderId) == "string" and type(data.propId) == "string" then
        TriggerServerEvent("prop_gizmo:removePlacedPropFromFolder", {
            folderId = data.folderId,
            propId = data.propId,
        })
    end
    cb("ok")
end)

RegisterNUICallback("deletePlacedFolder", function(data, cb)
    if type(data) == "table" and type(data.folderId) == "string" then
        TriggerServerEvent("prop_gizmo:deletePlacedFolder", { folderId = data.folderId })
    end
    cb("ok")
end)

RegisterNUICallback("skinRosterRefresh", function(_, cb)
    TriggerServerEvent("prop_gizmo:requestSkinRoster")
    cb("ok")
end)

RegisterNUICallback("playerSkinClear", function(data, cb)
    if type(data) == "table" then
        TriggerServerEvent("prop_gizmo:clearPersistedPlayerSkin", {
            targetSteam = type(data.targetSteam) == "string" and data.targetSteam or "",
            targetServerId = data.targetServerId,
        })
    end
    cb("ok")
end)

local function restorePedVisualStateAfterSkinClear()
    local ped = PlayerPedId()
    if not ped or ped == 0 then
        return
    end
    pcall(function()
        SetEntityVisible(ped, true)
    end)
    pcall(function()
        SetEntityAlpha(ped, 255, false)
    end)
    pcall(function()
        SetEntityCollision(ped, true, true)
    end)
    pcall(function()
        FreezeEntityPosition(ped, false)
    end)
end

RegisterNetEvent("prop_gizmo:clearPersistedSkinApply", function()
    CreateThread(function()
        local keepUiOpen = uiOpen == true and not isPlacing
        if not keepUiOpen then
            PropGizmo_ForceReleaseNuiAndCursor()
        end
        Wait(120)
        TriggerEvent("vorp_character:forceReloadSkin")
        restorePedVisualStateAfterSkinClear()
        Wait(400)
        local ped = PlayerPedId()
        local mm = GetEntityModel(ped)
        if mm ~= joaat("mp_male") and mm ~= joaat("mp_female") then
            TriggerEvent("vorpcharacter:reloadafterdeath")
            Wait(500)
            TriggerEvent("vorp_character:forceReloadSkin")
        end
        restorePedVisualStateAfterSkinClear()
        Wait(100)
        if (not keepUiOpen) and PropGizmo_HideSkinHintAndReleaseNui then
            PropGizmo_HideSkinHintAndReleaseNui()
        end
        if PropGizmo_StopAnimalAssist then
            PropGizmo_StopAnimalAssist()
        end
        if keepUiOpen then
            SetNuiFocusKeepInput(false)
            SetNuiFocus(true, true)
        else
            PropGizmo_ForceReleaseNuiAndCursor()
        end
    end)
end)

RegisterNetEvent("prop_gizmo:skinRosterData", function(payload)
    SendNUIMessage({ action = "skinRosterData", data = type(payload) == "table" and payload or {} })
end)

RegisterNetEvent("prop_gizmo:syncAll", function(list)
    applyFullSync(list)
end)

RegisterNetEvent("prop_gizmo:addOne", function(entry)
    if type(entry) ~= "table" then return end
    registerPlacedFromServer(entry)
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:removeOne", function(propId)
    if type(propId) ~= "string" then return end
    removeLocalPlaced(propId)
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:syncBlips", function(list)
    clearAllPlacedBlips()
    if type(list) == "table" then
        for _, row in ipairs(list) do
            registerBlipFromServer(row)
        end
    end
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:addBlip", function(entry)
    if type(entry) ~= "table" then return end
    registerBlipFromServer(entry)
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:removeBlip", function(blipId)
    if type(blipId) ~= "string" then return end
    removeLocalPlacedBlip(blipId)
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:syncFolders", function(list)
    if type(list) == "table" then
        placedFoldersSync = list
    else
        placedFoldersSync = {}
    end
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:updatePropGroup", function(id, group)
    if type(id) ~= "string" then return end
    local e = placedById[id]
    if not e then return end
    if type(group) == "string" and group ~= "" then
        e.group = group
    else
        e.group = nil
    end
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:patchPropAssembly", function(id, asm)
    if type(id) ~= "string" then return end
    local e = placedById[id]
    if not e then return end
    if type(asm) == "string" and asm ~= "" then
        e.assemblyId = asm
    else
        e.assemblyId = nil
    end
    sendPlacedListToNui()
end)

RegisterNetEvent("prop_gizmo:patchPlacedPropTransforms", function(patch)
    if type(patch) ~= "table" then return end
    for _, row in ipairs(patch) do
        if type(row) == "table" and type(row.id) == "string" then
            local e = placedById[row.id]
            if e then
                local x = tonumber(row.x)
                local y = tonumber(row.y)
                local z = tonumber(row.z)
                if x and y and z then
                    e.x, e.y, e.z = x + 0.0, y + 0.0, z + 0.0
                    e.heading = tonumber(row.heading) or e.heading
                    e.pitch = tonumber(row.pitch) or e.pitch
                    e.roll = tonumber(row.roll) or e.roll
                    local ent = e.entity
                    if ent and ent ~= 0 and DoesEntityExist(ent) then
                        SetEntityCoords(ent, e.x, e.y, e.z, false, false, false, false)
                        SetEntityRotation(ent, e.pitch + 0.0, e.roll + 0.0, e.heading + 0.0, 2, true)
                    end
                    local centr = e.collisionEntity
                    if centr and centr ~= 0 and DoesEntityExist(centr) then
                        SetEntityCoords(centr, e.x, e.y, e.z, false, false, false, false)
                        SetEntityRotation(centr, e.pitch + 0.0, e.roll + 0.0, e.heading + 0.0, 2, true)
                    end
                end
            end
        end
    end
    sendPlacedListToNui()
end)

local function applyPersistedSkinModel(modelName)
    if type(modelName) ~= "string" or modelName == "" then return end
    local hash = joaat(modelName)
    if not LoadModel(hash) then return end
    local pid = PlayerId()
    SetPlayerModel(pid, hash, false)
    Wait(800)
    if type(PropGizmo_ModelKindForSkin) == "function" and PropGizmo_ModelKindForSkin(modelName) == "bird" then
        Wait(500)
    end
    SetModelAsNoLongerNeeded(hash)
    local ped = PlayerPedId()
    if ped and ped ~= 0 then
        Citizen.InvokeNative(0x283978A15512B2FE, ped, true)
        Citizen.InvokeNative(0x9587913B9E772D29, ped, true)
        if type(PropGizmo_OnSkinApplied) == "function" then
            CreateThread(function()
                PropGizmo_OnSkinApplied(modelName, uiLang or "en", ped)
            end)
        end
    end
end

RegisterNetEvent("prop_gizmo:applyPersistedSkin", function(modelName, instant)
    CreateThread(function()
        if not instant then
            Wait(1500)
        else
            Wait(50)
        end
        applyPersistedSkinModel(modelName)
    end)
end)

RegisterNetEvent("prop_gizmo:clientNotify", function(msg, duration)
    if type(msg) == "string" and msg ~= "" then
        gizmoNotify(msg, tonumber(duration) or 4000)
    end
end)

AddEventHandler("onResourceStop", function(res)
    if res ~= RES then return end
    clearAllPlacedVisuals()
    clearAllPlacedBlips()
    clearAllLocalPlacedPeds()
end)

CreateThread(function()
    loadCatalog()
    refreshGameObjectsListAvailability()
    loadAnimationsCatalog()
    Wait(800)
    TriggerServerEvent("prop_gizmo:requestSync")
end)

--- Persisted Player skin: only after VORP finished spawning (human multichar first), not on a fixed timer at join.
local lastPersistedSkinAutoRequest = 0

local function persistedSkinDelayMs()
    local v = (type(Config) == "table" and tonumber(Config.PersistedSkinAfterSpawnDelayMs)) or 3000
    if v < 0 then v = 0 end
    if v > 120000 then v = 120000 end
    return v
end

local function persistedSkinDebounceMs()
    local v = (type(Config) == "table" and tonumber(Config.PersistedSkinAutoApplyDebounceMs)) or 8000
    if v < 2000 then v = 2000 end
    return v
end

local function requestPersistedSkinAfterSpawn(reason)
    local now = GetGameTimer()
    if now - lastPersistedSkinAutoRequest < persistedSkinDebounceMs() then
        return
    end
    lastPersistedSkinAutoRequest = now
    CreateThread(function()
        Wait(persistedSkinDelayMs())
        TriggerServerEvent("prop_gizmo:requestMySkin")
    end)
end

AddEventHandler("vorp_core:Client:OnPlayerSpawned", function()
    requestPersistedSkinAfterSpawn("vorp_spawn")
end)

--- RSG: fires once core finished loading the character + spawn flow.
RegisterNetEvent("RSGCore:Client:OnPlayerLoaded", function()
    requestPersistedSkinAfterSpawn("rsg_spawn")
end)
RegisterNetEvent("rsg_core:Client:OnPlayerLoaded", function()
    requestPersistedSkinAfterSpawn("rsg_spawn")
end)

AddEventHandler("onClientResourceStart", function(res)
    if res ~= RES then return end
    CreateThread(function()
        Wait(4000)
        if LocalPlayer.state and LocalPlayer.state.IsInSession then
            requestPersistedSkinAfterSpawn("resource_start")
        end
    end)
end)

function PropGizmo_SchedulePersistedSkinReplay()
    requestPersistedSkinAfterSpawn("revive")
end

AddEventHandler("prop_gizmo:internalDeathCloseUi", function()
    if PropGizmo_HideSkinHintAndReleaseNui then
        PropGizmo_HideSkinHintAndReleaseNui()
    end
    if uiOpen then
        closeUi()
    end
end)

CreateThread(function()
    local spawnDist = 180.0
    if Config.PlacedPropLoadDistance ~= nil then
        spawnDist = tonumber(Config.PlacedPropLoadDistance) or 180.0
    elseif Config.PlacedStreamDistance ~= nil then
        spawnDist = tonumber(Config.PlacedStreamDistance) or 180.0
    end
    if spawnDist < 30.0 then spawnDist = 30.0 end
    local despawnDist
    if Config.PlacedPropUnloadDistance ~= nil then
        despawnDist = tonumber(Config.PlacedPropUnloadDistance) or (spawnDist + 40.0)
    elseif Config.PlacedDespawnDistance ~= nil then
        despawnDist = tonumber(Config.PlacedDespawnDistance) or (spawnDist + 40.0)
    else
        despawnDist = spawnDist + 40.0
    end
    if despawnDist < spawnDist then despawnDist = spawnDist + 20.0 end
    local spawnDistSq = spawnDist * spawnDist
    local despawnDistSq = despawnDist * despawnDist
    local refreshMs = math.max(250, math.floor(tonumber(Config.PlacedStreamRefreshMs) or 1200))
    local spawnBudget = math.max(1, math.floor(tonumber(Config.PlacedStreamSpawnBudgetPerTick) or 12))

    while true do
        Wait(refreshMs)
        if #placedOrder > 0 then
            local p = GetPlayerCoords()
            local spawnedThisTick = 0
            for _, id in ipairs(placedOrder) do
                local e = placedById[id]
                if e then
                    local spawnedNow = ensurePlacedVisualState(e, p, spawnDistSq, despawnDistSq)
                    if spawnedNow then
                        spawnedThisTick = spawnedThisTick + 1
                        if spawnedThisTick >= spawnBudget then
                            break
                        end
                    end
                end
            end
        end
    end
end)

--- Re-apply ped flags when options are on (game sometimes clears them).
CreateThread(function()
    while true do
        Wait(2500)
        if #localPlacedPedsOrder > 0 then
            for _, id in ipairs(localPlacedPedsOrder) do
                local e = localPlacedPedsById[id]
                if e and (e.invincible or e.frozen) then
                    applyLocalPedFlags(e)
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        if isPlacing then
            Wait(0)
            if IsControlJustPressed(0, 202) then
                placementCancelPressed = true
            end
        elseif uiOpen then
            Wait(0)
            if IsControlJustPressed(0, 202) then
                closeUi()
            end
        else
            Wait(200)
        end
    end
end)