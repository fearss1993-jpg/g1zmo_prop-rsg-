--- YMAP XML export/import (CodeWalker-compatible CMapData + pg* round-trip fields).

YmapIo = YmapIo or {}

local function xmlEscape(s)
    if type(s) ~= "string" then return "" end
    return s
        :gsub("&", "&amp;")
        :gsub("<", "&lt;")
        :gsub(">", "&gt;")
        :gsub("\"", "&quot;")
end

local function fmt(n)
    if type(n) ~= "number" then n = tonumber(n) or 0.0 end
    return string.format("%.6f", n + 0.0)
end

--- Match SetEntityRotation(pitch, roll, heading, 2) — degrees, ZYX-style quaternion.
function YmapIo.eulerDegToQuat(pitchDeg, rollDeg, headingDeg)
    local function rad(d) return (d + 0.0) * math.pi / 180.0 end
    local p, r, y = rad(pitchDeg or 0.0), rad(rollDeg or 0.0), rad(headingDeg or 0.0)
    local cp, sp = math.cos(p * 0.5), math.sin(p * 0.5)
    local cr, sr = math.cos(r * 0.5), math.sin(r * 0.5)
    local cy, sy = math.cos(y * 0.5), math.sin(y * 0.5)
    local qw = cp * cr * cy + sp * sr * sy
    local qx = sp * cr * cy - cp * sr * sy
    local qy = cp * sr * cy + sp * cr * sy
    local qz = cp * cr * sy - sp * sr * cy
    return qx, qy, qz, qw
end

function YmapIo.quatToEulerDeg(qx, qy, qz, qw)
    qx, qy, qz, qw = qx + 0.0, qy + 0.0, qz + 0.0, qw + 0.0
    local sinr_cosp = 2.0 * (qw * qx + qy * qz)
    local cosr_cosp = 1.0 - 2.0 * (qx * qx + qy * qy)
    local roll = math.deg(math.atan(sinr_cosp, cosr_cosp))
    local sinp = 2.0 * (qw * qy - qz * qx)
    local pitch
    if math.abs(sinp) >= 1.0 then
        pitch = math.deg(math.pi / 2.0 * (sinp > 0 and 1 or -1))
    else
        pitch = math.deg(math.asin(sinp))
    end
    local siny_cosp = 2.0 * (qw * qz + qx * qy)
    local cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
    local heading = math.deg(math.atan(siny_cosp, cosy_cosp))
    return pitch, roll, heading
end

function YmapIo.sanitizeExportFileName(name)
    if type(name) ~= "string" then return "export" end
    name = name:match("^%s*(.-)%s*$") or "export"
    name = name:gsub("%.ymap%.xml$", ""):gsub("%.xml$", ""):gsub("%.ymap$", "")
    name = name:gsub("[^%w%-_]+", "_"):gsub("_+", "_"):gsub("^_", ""):gsub("_$", "")
    if name == "" then name = "export" end
    if #name > 48 then name = name:sub(1, 48) end
    return name
end

local function readTagFloat(block, tag)
    local v = block:match("<" .. tag .. "%s+value=\"([^\"]+)\"")
    if v then return tonumber(v) end
    v = block:match("<" .. tag .. ">([^<]+)</" .. tag .. ">")
    return tonumber(v)
end

local function readTagString(block, tag)
    local v = block:match("<" .. tag .. ">([^<]+)</" .. tag .. ">")
    if v then return v:match("^%s*(.-)%s*$") end
    v = block:match("<" .. tag .. "%s+value=\"([^\"]+)\"")
    if v then return v end
    return nil
end

local function readPosition(block)
    local x = block:match("<position[^>]-x=\"([^\"]+)\"")
    local y = block:match("<position[^>]-y=\"([^\"]+)\"")
    local z = block:match("<position[^>]-z=\"([^\"]+)\"")
    if x and y and z then
        return tonumber(x), tonumber(y), tonumber(z)
    end
    x = readTagFloat(block, "x")
    return x, readTagFloat(block, "y"), readTagFloat(block, "z")
end

local function readRotation(block)
    local x = block:match("<rotation[^>]-x=\"([^\"]+)\"")
    local y = block:match("<rotation[^>]-y=\"([^\"]+)\"")
    local z = block:match("<rotation[^>]-z=\"([^\"]+)\"")
    local w = block:match("<rotation[^>]-w=\"([^\"]+)\"")
    if x and y and z and w then
        return tonumber(x), tonumber(y), tonumber(z), tonumber(w)
    end
    return readTagFloat(block, "x"), readTagFloat(block, "y"), readTagFloat(block, "z"), readTagFloat(block, "w")
end

function YmapIo.parseYmapXml(xml)
    if type(xml) ~= "string" or xml == "" then
        return nil, "empty"
    end
    local exportGroup = xml:match("<pgMeta[^>]-exportGroup=\"([^\"]+)\"") or ""
    local mapName = xml:match("<name>([^<]+)</name>") or "import"
    local props = {}
    for block in xml:gmatch("<Item%s+type=\"CEntityDef\">(.-)</Item>") do
        local model = readTagString(block, "archetypeName")
        if model and model ~= "" then
            local x, y, z = readPosition(block)
            if x and y and z then
                local pitch = readTagFloat(block, "pgPitch") or 0.0
                local roll = readTagFloat(block, "pgRoll") or 0.0
                local heading = readTagFloat(block, "pgHeading")
                if not heading then
                    local qx, qy, qz, qw = readRotation(block)
                    if qx and qy and qz and qw then
                        pitch, roll, heading = YmapIo.quatToEulerDeg(qx, qy, qz, qw)
                    else
                        heading = 0.0
                    end
                end
                local row = {
                    model = model,
                    x = x + 0.0,
                    y = y + 0.0,
                    z = z + 0.0,
                    heading = heading + 0.0,
                    pitch = pitch + 0.0,
                    roll = roll + 0.0,
                }
                local g = readTagString(block, "pgGroup")
                if g and g ~= "" then row.group = g end
                local cpm = readTagString(block, "pgCollisionProxy")
                if cpm and cpm ~= "" then row.collisionProxyModel = cpm end
                local aid = readTagString(block, "pgAssemblyId")
                if aid and aid ~= "" then row.assemblyId = aid end
                props[#props + 1] = row
            end
        end
    end
    if #props == 0 then
        return nil, "no_entities"
    end
    return {
        mapName = mapName,
        exportGroup = exportGroup,
        props = props,
    }, nil
end

function YmapIo.buildYmapXml(opts)
    opts = opts or {}
    local props = opts.props or {}
    local mapName = YmapIo.sanitizeExportFileName(opts.mapName or opts.exportGroup or "export")
    local exportGroup = type(opts.exportGroup) == "string" and opts.exportGroup or ""

    local minX, minY, minZ = 1e9, 1e9, 1e9
    local maxX, maxY, maxZ = -1e9, -1e9, -1e9
    for _, p in ipairs(props) do
        local x, y, z = tonumber(p.x), tonumber(p.y), tonumber(p.z)
        if x and y and z then
            if x < minX then minX = x end
            if y < minY then minY = y end
            if z < minZ then minZ = z end
            if x > maxX then maxX = x end
            if y > maxY then maxY = y end
            if z > maxZ then maxZ = z end
        end
    end
    if minX > maxX then
        minX, minY, minZ, maxX, maxY, maxZ = 0, 0, 0, 0, 0, 0
    end
    local pad = 40.0
    local sminX, sminY, sminZ = minX - pad, minY - pad, minZ - pad
    local smaxX, smaxY, smaxZ = maxX + pad, maxY + pad, maxZ + pad

    local lines = {
        '<?xml version="1.0" encoding="UTF-8"?>',
        "<CMapData>",
        "  <name>" .. xmlEscape(mapName) .. "</name>",
        '  <pgMeta format="rsg_prop_gizmo_ymap_v1" exportGroup="' .. xmlEscape(exportGroup) .. '"/>',
        '  <flags value="2"/>',
        '  <contentFlags value="65"/>',
        ('  <streamingExtentsMin x="%s" y="%s" z="%s"/>'):format(fmt(sminX), fmt(sminY), fmt(sminZ)),
        ('  <streamingExtentsMax x="%s" y="%s" z="%s"/>'):format(fmt(smaxX), fmt(smaxY), fmt(smaxZ)),
        ('  <entitiesExtentsMin x="%s" y="%s" z="%s"/>'):format(fmt(minX), fmt(minY), fmt(minZ)),
        ('  <entitiesExtentsMax x="%s" y="%s" z="%s"/>'):format(fmt(maxX), fmt(maxY), fmt(maxZ)),
        "  <entities>",
    }

    for _, p in ipairs(props) do
        local model = p.model
        if type(model) == "string" and model ~= "" then
            local x = tonumber(p.x) or 0.0
            local y = tonumber(p.y) or 0.0
            local z = tonumber(p.z) or 0.0
            local heading = tonumber(p.heading) or 0.0
            local pitch = tonumber(p.pitch) or 0.0
            local roll = tonumber(p.roll) or 0.0
            local qx, qy, qz, qw = YmapIo.eulerDegToQuat(pitch, roll, heading)
            local g = type(p.group) == "string" and p.group or ""
            local cpm = type(p.collisionProxyModel) == "string" and p.collisionProxyModel or ""
            local aid = type(p.assemblyId) == "string" and p.assemblyId or ""
            lines[#lines + 1] = '    <Item type="CEntityDef">'
            lines[#lines + 1] = "      <archetypeName>" .. xmlEscape(model) .. "</archetypeName>"
            lines[#lines + 1] = '      <flags value="32"/>'
            lines[#lines + 1] = '      <guid value="0"/>'
            lines[#lines + 1] = ('      <position x="%s" y="%s" z="%s"/>'):format(fmt(x), fmt(y), fmt(z))
            lines[#lines + 1] = ('      <rotation x="%s" y="%s" z="%s" w="%s"/>'):format(fmt(qx), fmt(qy), fmt(qz), fmt(qw))
            lines[#lines + 1] = ('      <pgPitch value="%s"/>'):format(fmt(pitch))
            lines[#lines + 1] = ('      <pgRoll value="%s"/>'):format(fmt(roll))
            lines[#lines + 1] = ('      <pgHeading value="%s"/>'):format(fmt(heading))
            lines[#lines + 1] = '      <pgGroup>' .. xmlEscape(g) .. "</pgGroup>"
            lines[#lines + 1] = '      <pgCollisionProxy>' .. xmlEscape(cpm) .. "</pgCollisionProxy>"
            lines[#lines + 1] = '      <pgAssemblyId>' .. xmlEscape(aid) .. "</pgAssemblyId>"
            lines[#lines + 1] = "    </Item>"
        end
    end

    lines[#lines + 1] = "  </entities>"
    lines[#lines + 1] = "</CMapData>"
    return table.concat(lines, "\n")
end
