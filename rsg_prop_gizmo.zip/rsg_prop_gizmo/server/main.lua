local RESOURCE = GetCurrentResourceName()
local Fw = GizmoResolveFramework()
local VorpCore = nil
local RSGCoreObj = nil

if Fw == "vorp" then
    VorpCore = exports.vorp_core:GetCore()
elseif Fw == "rsg" then
    local rsgRes = GizmoRsgResourceName()
    RSGCoreObj = exports[rsgRes]:GetCoreObject()
else
    print("^1[rsg_prop_gizmo]^7 No framework: ensure vorp_core or rsg-core is started before this resource, or set Config.Framework.")
end
local placedList = {}
local nextPropId = 1
local nextAssemblyNum = 0
local placedBlips = {}
local nextBlipId = 1
local blipCatalogByName = {}

local function trimLower(v)
    if type(v) ~= "string" then return nil end
    v = v:match("^%s*(.-)%s*$")
    if v == "" then return nil end
    return string.lower(v)
end

local function dataFile()
    return (type(Config.ServerPlacedPropsFile) == "string" and Config.ServerPlacedPropsFile ~= "")
        and Config.ServerPlacedPropsFile
        or "placed_props_sync.json"
end

local function blipsDataFile()
    return (type(Config.ServerPlacedBlipsFile) == "string" and Config.ServerPlacedBlipsFile ~= "")
        and Config.ServerPlacedBlipsFile
        or "placed_blips_sync.json"
end

local function valueInList(value, list)
    local n = trimLower(value)
    if not n or type(list) ~= "table" then return false end
    for _, x in ipairs(list) do
        if n == trimLower(x) then
            return true
        end
    end
    return false
end

local function getVorpGroupJob(user)
    if not user then return nil, nil end
    local group = user.getGroup
    local job = nil

    local usedChar = nil
    if type(user.getUsedCharacter) == "function" then
        usedChar = user.getUsedCharacter
    elseif type(user.getUsedCharacter) == "table" then
        usedChar = user.getUsedCharacter
    end
    if type(usedChar) == "table" then
        job = usedChar.job or (type(usedChar.getJob) == "function" and usedChar.getJob())
    end
    if not job then
        job = user.job or (type(user.getJob) == "function" and user.getJob())
    end
    return group, job
end

local function getRsgGroupJob(Player)
    if not Player or not Player.PlayerData then return nil, nil end
    local pd = Player.PlayerData
    local group = pd.group
    local job = nil
    if type(pd.job) == "table" then
        job = pd.job.name or pd.job.job or pd.job.type
    elseif type(pd.job) == "string" then
        job = pd.job
    end
    return group, job
end

local function canUseGizmoVorp(user)
    local group, job = getVorpGroupJob(user)
    local access = Config.CommandAccess or {}
    local groups = access.AdminGroups or Config.AdminGroups
    local jobs = access.Jobs or {}
    if valueInList(group, groups) then return true end
    if valueInList(job, jobs) then return true end
    return false
end

local function canUseGizmoRsg(Player, src)
    if not Player then return false end
    local group, job = getRsgGroupJob(Player)
    local access = Config.CommandAccess or {}
    local groups = access.AdminGroups or Config.AdminGroups
    local jobs = access.Jobs or {}
    if RSGCoreObj and type(RSGCoreObj.Functions.HasPermission) == "function" then
        for _, g in ipairs(groups or {}) do
            if type(g) == "string" and RSGCoreObj.Functions.HasPermission(src, g) then
                return true
            end
        end
    end
    if valueInList(group, groups) then return true end
    if valueInList(job, jobs) then return true end
    return false
end

local function normalizeSet(list)
    local set = {}
    if type(list) ~= "table" then return set end
    for _, v in ipairs(list) do
        local n = trimLower(v)
        if n then set[n] = true end
    end
    return set
end

local function normalizeHiddenBlocks(tbl)
    local out = {}
    if type(tbl) ~= "table" then return out end
    for cat, blocks in pairs(tbl) do
        local c = trimLower(cat)
        if c then
            out[c] = normalizeSet(blocks)
        end
    end
    return out
end

local function buildVisibilityRulesForJob(job)
    local rules = Config.CategoryAccess or {}
    local byJob = nil
    if type(rules.Jobs) == "table" then
        byJob = rules.Jobs[trimLower(job or "")]
    end

    local allow = normalizeSet(rules.AllowedCategories)
    local hide = normalizeSet(rules.HiddenCategories)
    local hideBlocks = normalizeHiddenBlocks(rules.HiddenBlocks)

    if type(byJob) == "table" then
        local jobAllow = normalizeSet(byJob.AllowedCategories)
        if next(jobAllow) then
            allow = jobAllow
        end
        for k in pairs(normalizeSet(byJob.HiddenCategories)) do
            hide[k] = true
        end
        local jobHideBlocks = normalizeHiddenBlocks(byJob.HiddenBlocks)
        for cat, blockSet in pairs(jobHideBlocks) do
            hideBlocks[cat] = hideBlocks[cat] or {}
            for block in pairs(blockSet) do
                hideBlocks[cat][block] = true
            end
        end
    end

    return {
        allowedCategories = allow,
        hiddenCategories = hide,
        hiddenBlocks = hideBlocks,
    }
end

local function appendWhitelistFromArray(set, list, prefix)
    if type(list) ~= "table" then return end
    for _, v in ipairs(list) do
        if type(v) == "string" then
            local n = v:match("^%s*(.-)%s*$")
            if n and n ~= "" then
                n = string.lower(n)
                if prefix and not n:find(":", 1, true) then
                    n = prefix .. n
                end
                set[n] = true
            end
        end
    end
end

local function buildWhitelistSet()
    local access = Config.CommandAccess or {}
    local raw = access.Whitelist
    local set = {}
    if type(raw) ~= "table" then return set end
    appendWhitelistFromArray(set, raw, nil)
    appendWhitelistFromArray(set, raw.Steam, "steam:")
    appendWhitelistFromArray(set, raw.License, "license:")
    appendWhitelistFromArray(set, raw.License2, "license2:")
    appendWhitelistFromArray(set, raw.Discord, "discord:")
    appendWhitelistFromArray(set, raw.Fivem, "fivem:")
    appendWhitelistFromArray(set, raw.Live, "live:")
    appendWhitelistFromArray(set, raw.Xbl, "xbl:")
    appendWhitelistFromArray(set, raw.Ip, "ip:")
    return set
end

local function isSourceWhitelisted(src)
    if type(src) ~= "number" or src <= 0 then return false end
    local set = buildWhitelistSet()
    if not next(set) then return false end
    local ids = GetPlayerIdentifiers(src) or {}
    for _, id in ipairs(ids) do
        if type(id) == "string" and set[string.lower(id)] then
            return true
        end
    end
    return false
end

local function isAllowedSource(src)
    if Config.AllowGizmoForEveryone == true then
        return true
    end
    if isSourceWhitelisted(src) then
        return true
    end
    if Fw == "vorp" and VorpCore then
        local user = VorpCore.getUser(src)
        return user and canUseGizmoVorp(user)
    end
    if Fw == "rsg" and RSGCoreObj then
        local Player = RSGCoreObj.Functions.GetPlayer(src)
        return Player and canUseGizmoRsg(Player, src)
    end
    return false
end

local function bumpNextIdFromList()
    nextPropId = 1
    for _, r in ipairs(placedList) do
        local id = r and r.id
        if type(id) == "string" then
            local n = tonumber(id:match("^pg_(%d+)$"))
            if n and n >= nextPropId then
                nextPropId = n + 1
            end
        end
    end
end

local function bumpNextAssemblyNumFromList()
    nextAssemblyNum = 0
    for _, r in ipairs(placedList) do
        local aid = r and r.assemblyId
        if type(aid) == "string" then
            local n = tonumber(aid:match("^asm_(%d+)$"))
            if n and n > nextAssemblyNum then
                nextAssemblyNum = n
            end
        end
    end
end

local function newAssemblyId()
    nextAssemblyNum = nextAssemblyNum + 1
    return ("asm_%d"):format(nextAssemblyNum)
end

local function bumpNextBlipIdFromList()
    nextBlipId = 1
    for _, r in ipairs(placedBlips) do
        local id = r and r.id
        if type(id) == "string" then
            local n = tonumber(id:match("^pb_(%d+)$"))
            if n and n >= nextBlipId then
                nextBlipId = n + 1
            end
        end
    end
end

local function newBlipId()
    local id = ("pb_%d"):format(nextBlipId)
    nextBlipId = nextBlipId + 1
    return id
end

local function loadBlipCatalog()
    blipCatalogByName = {}
    local rel = (type(Config.BlipsCatalogFile) == "string" and Config.BlipsCatalogFile ~= "")
        and Config.BlipsCatalogFile
        or "data/blips_catalog.json"
    local raw = LoadResourceFile(RESOURCE, rel)
    if not raw or raw == "" then
        print(("[rsg_prop_gizmo] Blips catalog missing: %s"):format(rel))
        return
    end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= "table" then
        print(("[rsg_prop_gizmo] Blips catalog JSON error: %s"):format(rel))
        return
    end
    for _, row in ipairs(data) do
        local name = row and row.name
        local sprite = tonumber(row and row.sprite)
        if type(name) == "string" and name ~= "" and sprite then
            blipCatalogByName[name] = sprite
        end
    end
    local n = 0
    for _ in pairs(blipCatalogByName) do n = n + 1 end
    print(("[rsg_prop_gizmo] Blips catalog: %d names."):format(n))
end

local function loadData()
    placedList = {}
    local raw = LoadResourceFile(RESOURCE, dataFile())
    if raw and raw ~= "" then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == "table" then
            placedList = data
        end
    end
    bumpNextIdFromList()
    bumpNextAssemblyNumFromList()
end

local function loadBlipsData()
    placedBlips = {}
    local raw = LoadResourceFile(RESOURCE, blipsDataFile())
    if raw and raw ~= "" then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == "table" then
            placedBlips = data
        end
    end
    bumpNextBlipIdFromList()
end

local function saveData()
    local ok, enc = pcall(json.encode, placedList)
    if ok and enc then
        SaveResourceFile(RESOURCE, dataFile(), enc, -1)
    end
end

local function saveBlipsData()
    local ok, enc = pcall(json.encode, placedBlips)
    if ok and enc then
        SaveResourceFile(RESOURCE, blipsDataFile(), enc, -1)
    end
end

local playerSkinByKey = {}
local pedsModelAllowed = {}

local function skinDataFile()
    return (type(Config.ServerPlayerSkinFile) == "string" and Config.ServerPlayerSkinFile ~= "")
        and Config.ServerPlayerSkinFile
        or "player_skin_persist.json"
end

local function loadPedsCatalogSet()
    pedsModelAllowed = {}
    local rel = (type(Config.PedsCatalogFile) == "string" and Config.PedsCatalogFile ~= "")
        and Config.PedsCatalogFile
        or "data/peds_catalog.json"
    local raw = LoadResourceFile(RESOURCE, rel)
    if not raw or raw == "" then return end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= "table" then return end
    for _, v in ipairs(data) do
        if type(v) == "string" and v ~= "" then
            pedsModelAllowed[string.lower(v)] = true
        end
    end
end

local function loadSkinData()
    playerSkinByKey = {}
    local raw = LoadResourceFile(RESOURCE, skinDataFile())
    if raw and raw ~= "" then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == "table" then
            playerSkinByKey = data
        end
    end
end

local function saveSkinData()
    local ok, enc = pcall(json.encode, playerSkinByKey)
    if ok and enc then
        SaveResourceFile(RESOURCE, skinDataFile(), enc, -1)
    end
end

local skinHistory = {}

local function skinHistoryFile()
    return (type(Config.ServerPlayerSkinHistoryFile) == "string" and Config.ServerPlayerSkinHistoryFile ~= "")
        and Config.ServerPlayerSkinHistoryFile
        or "player_skin_history.json"
end

local function loadSkinHistory()
    skinHistory = {}
    local raw = LoadResourceFile(RESOURCE, skinHistoryFile())
    if raw and raw ~= "" then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == "table" then
            skinHistory = data
        end
    end
end

local function saveSkinHistory()
    local ok, enc = pcall(json.encode, skinHistory)
    if ok and enc then
        SaveResourceFile(RESOURCE, skinHistoryFile(), enc, -1)
    end
end

local function pushSkinHistory(entry)
    if type(entry) ~= "table" then return end
    skinHistory[#skinHistory + 1] = entry
    local maxN = 80
    if type(Config.SkinHistoryMaxEntries) == "number" then
        maxN = math.floor(Config.SkinHistoryMaxEntries)
    end
    if maxN < 20 then maxN = 20 end
    if maxN > 200 then maxN = 200 end
    while #skinHistory > maxN do
        table.remove(skinHistory, 1)
    end
    saveSkinHistory()
end

-- === Placed prop folders (named lists of prop entry ids) ===
local placedFolders = {}
local nextPlacedFolderNum = 0

local function foldersDataFile()
    return (type(Config.ServerPlacedFoldersFile) == "string" and Config.ServerPlacedFoldersFile ~= "")
        and Config.ServerPlacedFoldersFile
        or "placed_prop_folders.json"
end

local function bumpNextPlacedFolderNumFromList()
    local m = 0
    for _, f in ipairs(placedFolders) do
        if type(f) == "table" and type(f.id) == "string" then
            local n = tonumber(f.id:match("^pf_(%d+)$"))
            if n and n > m then m = n end
        end
    end
    nextPlacedFolderNum = m
end

local function loadFoldersData()
    placedFolders = {}
    nextPlacedFolderNum = 0
    local raw = LoadResourceFile(RESOURCE, foldersDataFile())
    if raw and raw ~= "" then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == "table" then
            placedFolders = data
        end
    end
    bumpNextPlacedFolderNumFromList()
end

local function saveFoldersData()
    local ok, enc = pcall(json.encode, placedFolders)
    if ok and enc then
        SaveResourceFile(RESOURCE, foldersDataFile(), enc, -1)
    end
end

local function newPlacedFolderId()
    nextPlacedFolderNum = nextPlacedFolderNum + 1
    return "pf_" .. tostring(nextPlacedFolderNum)
end

local function syncFoldersToClient(targetSrc)
    if targetSrc then
        TriggerClientEvent("prop_gizmo:syncFolders", targetSrc, placedFolders)
    else
        TriggerClientEvent("prop_gizmo:syncFolders", -1, placedFolders)
    end
end

local function placedPropEntryExists(propId)
    if type(propId) ~= "string" then return false end
    for _, r in ipairs(placedList) do
        if r.id == propId then return true end
    end
    return false
end

local function removePropIdFromAllFolders(propId)
    if type(propId) ~= "string" then return false end
    local changed = false
    for _, f in ipairs(placedFolders) do
        if type(f) == "table" and type(f.propIds) == "table" then
            for i = #f.propIds, 1, -1 do
                if f.propIds[i] == propId then
                    table.remove(f.propIds, i)
                    changed = true
                end
            end
        end
    end
    return changed
end

local function findFolderById(folderId)
    if type(folderId) ~= "string" then return nil end
    for _, f in ipairs(placedFolders) do
        if type(f) == "table" and f.id == folderId then return f end
    end
    return nil
end

local function validGroupName(g)
    if g == nil then return true end
    if type(g) ~= "string" then return false end
    g = g:match("^%s*(.-)%s*$") or ""
    if g == "" then return true end
    if #g > 48 then return false end
    return g:match("^[%w%s%-_%.]+$") ~= nil
end

local function validPedModelForSkin(model)
    if type(model) ~= "string" or model == "" or #model > 128 then return false end
    if not model:match("^[%w_%.%-]+$") then return false end
    if next(pedsModelAllowed) == nil then
        return true
    end
    return pedsModelAllowed[string.lower(model)] == true
end

--- Accept steam:… from identifiers (hex after "steam:", not digits-only).
local function normalizeSteamKey(s)
    if type(s) ~= "string" then return nil end
    s = s:match("^%s*(.-)%s*$") or ""
    if s == "" then return nil end
    s = s:lower()
    local embedded = s:match("(steam:[0-9a-f]+)")
    if embedded then return embedded end
    if s:match("^steam:[0-9a-f]+$") then return s end
    return nil
end

local function identifiersList(src)
    local ids = GetPlayerIdentifiers(src)
    if type(ids) ~= "table" then return {} end
    return ids
end

local function findOnlinePlayerBySteamKey(steamKey)
    if not steamKey then return nil end
    for _, sid in ipairs(GetPlayers()) do
        local pid = tonumber(sid)
        if pid then
            for _, id in ipairs(identifiersList(pid)) do
                if type(id) == "string" and id:lower() == steamKey then
                    return pid
                end
            end
        end
    end
    return nil
end

local function persistSkinForSource(src, model)
    for _, id in ipairs(identifiersList(src)) do
        if type(id) == "string" and (id:sub(1, 6) == "steam:" or id:sub(1, 8) == "license:") then
            playerSkinByKey[id:lower()] = model
        end
    end
    saveSkinData()
end

local function pickPersistedModelForSource(src)
    for _, id in ipairs(identifiersList(src)) do
        if type(id) == "string" then
            local m = playerSkinByKey[id:lower()]
            if type(m) == "string" and m ~= "" then
                return m
            end
        end
    end
    return nil
end

--- Remove saved skin for all steam:/license: keys of this player (does not touch other identifiers).
local function clearPersistedSkinKeysForSource(src)
    local changed = false
    for _, id in ipairs(identifiersList(src)) do
        if type(id) == "string" and (id:sub(1, 6) == "steam:" or id:sub(1, 8) == "license:") then
            local k = id:lower()
            if playerSkinByKey[k] ~= nil then
                playerSkinByKey[k] = nil
                changed = true
            end
        end
    end
    if changed then
        saveSkinData()
    end
    return changed
end

local SPOONI_CATALOG_REL = "data/spooni_catalog.json"
local SPOONI_PAGE = 1000

local function urlEncodeQuery(s)
    return (tostring(s):gsub("[^%w%-_.~]", function(c)
        return string.format("%%%02X", string.byte(c, 1))
    end))
end

local function mergeSpooniRow(tree, row)
    if type(row) ~= "table" then return end
    local id = row.id
    if type(id) ~= "string" or id == "" then return end
    local cat, sub = "uncategorized", "uncategorized"
    local c = row.categories
    if type(c) == "table" and c.name then cat = tostring(c.name) end
    local sc = row.subcategories
    if type(sc) == "table" and sc.name then sub = tostring(sc.name) end
    if not tree[cat] then tree[cat] = {} end
    if not tree[cat][sub] then tree[cat][sub] = {} end
    local list = tree[cat][sub]
    for _, v in ipairs(list) do
        if v == id then return end
    end
    list[#list + 1] = id
end

local function parseContentRangeTotal(headers)
    if type(headers) ~= "table" then return nil end
    local cr = nil
    for k, v in pairs(headers) do
        if string.lower(tostring(k)) == "content-range" then
            cr = v
            break
        end
    end
    if type(cr) ~= "string" then return nil end
    local total = cr:match("/(%d+)$")
    return tonumber(total)
end

local function sortCatalogTree(tree)
    for _, subs in pairs(tree) do
        if type(subs) == "table" then
            for _, ids in pairs(subs) do
                if type(ids) == "table" then
                    table.sort(ids)
                end
            end
        end
    end
end

local function tryFetchSpooniCatalog()
    if not Config.SpooniFetchCatalogOnResourceStart then return end
    local key = Config.SpooniSupabaseAnonKey
    if type(key) ~= "string" then key = "" end
    key = key:match("^%s*(.-)%s*$") or ""
    if key == "" then
        print("^3[rsg_prop_gizmo]^7 SpooniFetchCatalogOnResourceStart: set Config.SpooniSupabaseAnonKey (same as apikey in DevTools on spooni.pages.dev).")
        return
    end
    local base = Config.SpooniSupabaseUrl
    if type(base) ~= "string" or base == "" then
        print("^3[rsg_prop_gizmo]^7 SpooniSupabaseUrl is empty.")
        return
    end
    base = base:gsub("/+$", "")
    local selectPart =
        "id,categories!props_category_id_fkey(name),subcategories!props_subcategory_id_fkey(name)"
    local url = base
        .. "/rest/v1/props?select="
        .. urlEncodeQuery(selectPart)
        .. "&order=id.asc"

    local tree = {}

    local function fetchRange(rangeStart, done)
        local rangeHdr = string.format("%d-%d", rangeStart, rangeStart + SPOONI_PAGE - 1)
        PerformHttpRequest(
            url,
            function(statusCode, body, headers)
                if statusCode ~= 200 and statusCode ~= 206 and statusCode ~= 207 then
                    print(("^1[rsg_prop_gizmo]^7 Supabase catalog fetch HTTP %s"):format(tostring(statusCode)))
                    done(false)
                    return
                end
                if type(body) ~= "string" or body == "" then
                    done(false)
                    return
                end
                local ok, rows = pcall(json.decode, body)
                if not ok or rows == nil then
                    print("^1[rsg_prop_gizmo]^7 Catalog response: invalid JSON.")
                    done(false)
                    return
                end
                if rows.id then rows = { rows } end
                if #rows == 0 then
                    done(true)
                    return
                end
                for _, row in ipairs(rows) do
                    mergeSpooniRow(tree, row)
                end
                local total = parseContentRangeTotal(headers)
                if #rows < SPOONI_PAGE then
                    done(true)
                    return
                end
                if total and rangeStart + #rows >= total then
                    done(true)
                    return
                end
                fetchRange(rangeStart + SPOONI_PAGE, done)
            end,
            "GET",
            "",
            {
                ["apikey"] = key,
                ["Authorization"] = "Bearer " .. key,
                ["Accept-Profile"] = "public",
                ["Range"] = rangeHdr,
                ["Prefer"] = "count=exact",
            }
        )
    end

    fetchRange(0, function(ok)
        if not ok then return end
        if next(tree) == nil then
            print("^3[rsg_prop_gizmo]^7 Catalog empty after fetch.")
            return
        end
        sortCatalogTree(tree)
        local payload = {
            _meta = {
                source = "supabase",
                fetchedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
            },
            categories = tree,
        }
        local encOk, jsonStr = pcall(json.encode, payload)
        if not encOk or not jsonStr then
            print("^1[rsg_prop_gizmo]^7 Failed to encode spooni_catalog.json.")
            return
        end
        SaveResourceFile(RESOURCE, SPOONI_CATALOG_REL, jsonStr, -1)
        local n = 0
        for _ in pairs(tree) do n = n + 1 end
        print(("^2[rsg_prop_gizmo]^7 Saved %s (%d top categories). Restart the resource so clients load the file."):format(
            SPOONI_CATALOG_REL,
            n
        ))
    end)
end

local function newEntryId()
    local id = ("pg_%d"):format(nextPropId)
    nextPropId = nextPropId + 1
    return id
end

--- Same rules as client: strip .ytd / +hidr etc. so OpenIV paste still validates.
local function sanitizePropModelName(m)
    if type(m) ~= "string" then return "" end
    m = m:match("^%s*(.-)%s*$") or ""
    if m == "" then return "" end
    while true do
        local prev = m
        m = m:gsub("%.[yY][tT][dD]$", "")
            :gsub("%.[yY][dD][rR]$", "")
            :gsub("%.[yY][fF][tT]$", "")
            :gsub("%.[yY][dD][dD]$", "")
            :gsub("%.[yY][bB][nN]$", "")
            :gsub("%.[xX][mM][lL]$", "")
        m = m:gsub("%+[hH][iI][dD][rR]$", "")
        m = m:gsub("%+[lL][oO][dD][sS]?$", "")
        if m == prev then break end
    end
    return m
end

local function validModelName(model)
    if type(model) ~= "string" or model == "" or #model > 128 then return false end
    if model:match("^0[xX][0-9a-fA-F]+$") then return true end
    if model:match("^%d+$") then return true end
    -- Allow common custom/streamed model ids: letters, digits, underscore, dash, dot.
    return model:match("^[%w_%.%-]+$") ~= nil
end

local function parseOptionalCollisionProxyModel(raw)
    if type(raw) ~= "string" then return nil end
    local m = raw:match("^%s*(.-)%s*$") or ""
    if m == "" then return nil end
    if not m:match("^0[xX][0-9a-fA-F]+$") and not m:match("^%d+$") then
        m = sanitizePropModelName(m)
    end
    if not validModelName(m) then return nil end
    return m
end

local function runCanOpenCallback(source, cb)
    local lang = (Config.Language == "ru") and "ru" or "en"
    if Config.AllowGizmoForEveryone == true then
        cb({
            allowed = true,
            lang = lang,
            group = nil,
            job = nil,
            visibility = buildVisibilityRulesForJob(nil),
        })
        return
    end
    if isSourceWhitelisted(source) then
        cb({
            allowed = true,
            lang = lang,
            group = "whitelist",
            job = nil,
            visibility = buildVisibilityRulesForJob(nil),
        })
        return
    end
    if Fw == "vorp" and VorpCore then
        local user = VorpCore.getUser(source)
        if not user then
            cb({ allowed = false })
            return
        end
        local group, job = getVorpGroupJob(user)
        cb({
            allowed = canUseGizmoVorp(user),
            lang = lang,
            group = group,
            job = job,
            visibility = buildVisibilityRulesForJob(job),
        })
        return
    end
    if Fw == "rsg" and RSGCoreObj then
        local Player = RSGCoreObj.Functions.GetPlayer(source)
        if not Player then
            cb({ allowed = false })
            return
        end
        local group, job = getRsgGroupJob(Player)
        cb({
            allowed = canUseGizmoRsg(Player, source),
            lang = lang,
            group = group,
            job = job,
            visibility = buildVisibilityRulesForJob(job),
        })
        return
    end
    cb({ allowed = false })
end

if Fw == "vorp" and VorpCore then
    VorpCore.Callback.Register("prop_gizmo:canOpen", function(source, cb)
        runCanOpenCallback(source, cb)
    end)
elseif Fw == "rsg" and RSGCoreObj then
    RSGCoreObj.Functions.CreateCallback("prop_gizmo:canOpen", function(source, cb)
        runCanOpenCallback(source, cb)
    end)
else
    print("^1[rsg_prop_gizmo]^7 Callback prop_gizmo:canOpen not registered (no framework).")
end

RegisterNetEvent("prop_gizmo:requestSync", function()
    local src = source
    TriggerClientEvent("prop_gizmo:syncAll", src, placedList)
    TriggerClientEvent("prop_gizmo:syncBlips", src, placedBlips)
    TriggerClientEvent("prop_gizmo:syncFolders", src, placedFolders)
end)

local function wipeAllSyncedPropsForSavedSet()
    local ids = {}
    for i = 1, #placedList do
        ids[#ids + 1] = placedList[i].id
    end
    placedList = {}
    saveData()
    for _, id in ipairs(ids) do
        removePropIdFromAllFolders(id)
    end
    saveFoldersData()
    syncFoldersToClient(nil)
    for _, id in ipairs(ids) do
        TriggerClientEvent("prop_gizmo:removeOne", -1, id)
    end
end

RegisterNetEvent("prop_gizmo:applySavedPropSet", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if Config.SavedPlacedSetsEnabled == false then return end
    if type(data) ~= "table" or type(data.props) ~= "table" then return end
    local maxN = math.max(1, math.floor(tonumber(Config.SavedPlacedSetMaxProps) or 800))
    if #data.props > maxN then
        TriggerClientEvent("prop_gizmo:clientNotify", src, ("Too many props in set (max %d)."):format(maxN), 6000)
        return
    end
    if data.replace == true then
        wipeAllSyncedPropsForSavedSet()
    end
    local added = 0
    for _, p in ipairs(data.props) do
        if type(p) == "table" then
            local model = p.model
            if type(model) == "string" then
                if not model:match("^0[xX][0-9a-fA-F]+$") and not model:match("^%d+$") then
                    model = sanitizePropModelName(model)
                end
            end
            if validModelName(model) then
                local x, y, z = tonumber(p.x), tonumber(p.y), tonumber(p.z)
                local heading = tonumber(p.heading) or 0.0
                local pitch = tonumber(p.pitch) or 0.0
                local roll = tonumber(p.roll) or 0.0
                if x and y and z then
                    local entry = {
                        id = newEntryId(),
                        model = model,
                        x = x, y = y, z = z,
                        heading = heading, pitch = pitch, roll = roll,
                    }
                    local g = p.group
                    if type(g) == "string" and g ~= "" and validGroupName(g) then
                        entry.group = g:match("^%s*(.-)%s*$") or g
                    end
                    local aid = p.assemblyId
                    if type(aid) == "string" and aid:match("^asm_%d+$") then
                        entry.assemblyId = aid
                    end
                    local cpmSet = parseOptionalCollisionProxyModel(p.collisionProxyModel)
                    if cpmSet then
                        entry.collisionProxyModel = cpmSet
                    end
                    placedList[#placedList + 1] = entry
                    TriggerClientEvent("prop_gizmo:addOne", -1, entry)
                    added = added + 1
                end
            end
        end
    end
    saveData()
    TriggerClientEvent(
        "prop_gizmo:clientNotify",
        src,
        added > 0 and ("Saved set applied: %d props."):format(added) or "No valid props in set.",
        5000
    )
end)

RegisterNetEvent("prop_gizmo:submitPlace", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then return end
    local model = data.model
    if type(model) == "string" then
        if not model:match("^0[xX][0-9a-fA-F]+$") and not model:match("^%d+$") then
            model = sanitizePropModelName(model)
        end
    end
    if not validModelName(model) then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Invalid model name.")
        return
    end
    local x, y, z = tonumber(data.x), tonumber(data.y), tonumber(data.z)
    local heading = tonumber(data.heading) or 0.0
    local pitch = tonumber(data.pitch) or 0.0
    local roll = tonumber(data.roll) or 0.0
    if not x or not y or not z then return end

    local maxD = tonumber(Config.PlaceMaxDistanceCheck)
    if maxD and maxD > 0 then
        local ped = GetPlayerPed(src)
        if ped and ped ~= 0 then
            local pc = GetEntityCoords(ped)
            local dx, dy, dz = x - pc.x, y - pc.y, z - pc.z
            local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
            if dist > maxD then
                TriggerClientEvent("prop_gizmo:clientNotify", src, "Placement is too far from you.")
                return
            end
        end
    end

    local entry = {
        id = newEntryId(),
        model = model,
        x = x, y = y, z = z,
        heading = heading, pitch = pitch, roll = roll,
    }
    local cpm = parseOptionalCollisionProxyModel(data.collisionProxyModel)
    if cpm then
        entry.collisionProxyModel = cpm
    end
    placedList[#placedList + 1] = entry
    saveData()
    TriggerClientEvent("prop_gizmo:addOne", -1, entry)
    TriggerClientEvent("prop_gizmo:clientNotify", src, "Prop placed — visible to all players.")
end)

RegisterNetEvent("prop_gizmo:submitBlip", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then return end
    local name = data.name
    local sprite = (type(name) == "string") and blipCatalogByName[name] or nil
    if not sprite then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Invalid blip name.")
        return
    end
    local x, y, z = tonumber(data.x), tonumber(data.y), tonumber(data.z)
    if not x or not y or not z then return end
    local entry = {
        id = newBlipId(),
        name = name,
        sprite = sprite,
        x = x, y = y, z = z,
    }
    placedBlips[#placedBlips + 1] = entry
    saveBlipsData()
    TriggerClientEvent("prop_gizmo:addBlip", -1, entry)
    TriggerClientEvent("prop_gizmo:clientNotify", src, "Blip placed — visible to all players.")
end)

RegisterNetEvent("prop_gizmo:removeBlip", function(blipId)
    local src = source
    if not isAllowedSource(src) then return end
    if type(blipId) ~= "string" then return end
    for i, r in ipairs(placedBlips) do
        if r.id == blipId then
            table.remove(placedBlips, i)
            saveBlipsData()
            TriggerClientEvent("prop_gizmo:removeBlip", -1, blipId)
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Blip removed for everyone.")
            return
        end
    end
end)

RegisterNetEvent("prop_gizmo:removeProp", function(propId)
    local src = source
    if not isAllowedSource(src) then return end
    if type(propId) ~= "string" then return end
    for i, r in ipairs(placedList) do
        if r.id == propId then
            table.remove(placedList, i)
            saveData()
            if removePropIdFromAllFolders(propId) then
                saveFoldersData()
                syncFoldersToClient(nil)
            end
            TriggerClientEvent("prop_gizmo:removeOne", -1, propId)
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Prop removed for everyone.")
            return
        end
    end
end)

local function srvAsmMsg(en, ru)
    return (type(Config.Language) == "string" and Config.Language:lower() == "ru") and ru or en
end

RegisterNetEvent("prop_gizmo:createAssembly", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if Config.AssembliesEnabled == false then return end
    local ids = data and data.propIds
    if type(ids) ~= "table" or #ids < 2 then
        TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Select at least two props.", "Отметьте минимум два пропа."), 5000)
        return
    end
    local maxM = math.max(2, math.floor(tonumber(Config.AssemblyMaxMembers) or 32))
    if #ids > maxM then
        TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg(("Too many props (max %d)."):format(maxM), ("Слишком много пропов (макс. %d)."):format(maxM)), 6000)
        return
    end
    local want = {}
    for _, pid in ipairs(ids) do
        if type(pid) ~= "string" then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Invalid prop id.", "Неверный id пропа."), 4000)
            return
        end
        if want[pid] then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Duplicate prop in selection.", "Проп отмечен дважды."), 4000)
            return
        end
        want[pid] = true
    end
    local rows = {}
    for _, r in ipairs(placedList) do
        if want[r.id] then
            if type(r.assemblyId) == "string" and r.assemblyId ~= "" then
                TriggerClientEvent(
                    "prop_gizmo:clientNotify",
                    src,
                    srvAsmMsg("Props already in an assembly leave it first.", "Сначала отвяжите проп от другой сборки."),
                    6000
                )
                return
            end
            rows[#rows + 1] = r
            want[r.id] = false
        end
    end
    for pid, pending in pairs(want) do
        if pending then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Some props were not found on the server.", "Часть пропов не найдена на сервере."), 6000)
            return
        end
    end
    if #rows < 2 then
        TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Need at least two valid props.", "Нужно минимум два валидных пропа."), 5000)
        return
    end
    bumpNextAssemblyNumFromList()
    local aid = newAssemblyId()
    for _, r in ipairs(rows) do
        r.assemblyId = aid
    end
    saveData()
    for _, r in ipairs(rows) do
        TriggerClientEvent("prop_gizmo:patchPropAssembly", -1, r.id, aid)
    end
    TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg(("Assembly saved (%d props): %s"):format(#rows, aid), ("Сборка из %d пропов: %s"):format(#rows, aid)), 5500)
end)

RegisterNetEvent("prop_gizmo:dissolveAssembly", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if Config.AssembliesEnabled == false then return end
    local asm = type(data) == "table" and data.assemblyId or nil
    if type(asm) ~= "string" or asm == "" then return end
    local changed = false
    for _, r in ipairs(placedList) do
        if r.assemblyId == asm then
            r.assemblyId = nil
            changed = true
            TriggerClientEvent("prop_gizmo:patchPropAssembly", -1, r.id, nil)
        end
    end
    if changed then
        saveData()
        TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Assembly dissolved.", "Сборка расформирована."), 4500)
    end
end)

RegisterNetEvent("prop_gizmo:leaveAssemblyProp", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if Config.AssembliesEnabled == false then return end
    local propId = type(data) == "table" and data.propId or nil
    if type(propId) ~= "string" then return end
    for _, r in ipairs(placedList) do
        if r.id == propId then
            if type(r.assemblyId) ~= "string" then return end
            r.assemblyId = nil
            saveData()
            TriggerClientEvent("prop_gizmo:patchPropAssembly", -1, propId, nil)
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Prop removed from assembly.", "Проп отвязан от сборки."), 4000)
            return
        end
    end
end)

RegisterNetEvent("prop_gizmo:submitAssemblyMove", function(rows)
    local src = source
    if not isAllowedSource(src) then return end
    if Config.AssembliesEnabled == false then return end
    if type(rows) ~= "table" or #rows == 0 then return end
    local asm0 = nil
    local idsByAsm = {}
    for _, r in ipairs(placedList) do
        if type(r.assemblyId) == "string" and r.assemblyId ~= "" then
            idsByAsm[r.assemblyId] = (idsByAsm[r.assemblyId] or 0) + 1
        end
    end
    for _, u in ipairs(rows) do
        if type(u) ~= "table" or type(u.id) ~= "string" then return end
        local found = nil
        for _, r in ipairs(placedList) do
            if r.id == u.id then
                found = r
                break
            end
        end
        if not found then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Prop missing on server.", "Проп отсутствует на сервере."), 5000)
            return
        end
        local aid = found.assemblyId
        if type(aid) ~= "string" or aid == "" then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Prop is not in an assembly.", "Проп не в сборке."), 5000)
            return
        end
        if asm0 == nil then
            asm0 = aid
        elseif asm0 ~= aid then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Mixed assemblies in payload.", "Смешанные сборки."), 5000)
            return
        end
    end
    if asm0 == nil then return end
    local seen = {}
    for _, u in ipairs(rows) do
        if seen[u.id] then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Duplicate prop in move payload.", "Дубликат пропа в перемещении."), 5000)
            return
        end
        seen[u.id] = true
    end
    if #rows ~= (idsByAsm[asm0] or 0) then
        TriggerClientEvent(
            "prop_gizmo:clientNotify",
            src,
            srvAsmMsg("Movement must include every prop in the assembly.", "В перемещение должны входить все пропы сборки."),
            7000
        )
        return
    end

    local patch = {}
    for _, u in ipairs(rows) do
        local x, y, z = tonumber(u.x), tonumber(u.y), tonumber(u.z)
        local h = tonumber(u.heading) or 0.0
        local p = tonumber(u.pitch) or 0.0
        local ro = tonumber(u.roll) or 0.0
        if not x or not y or not z then
            TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Invalid coordinates.", "Неверные координаты."), 5000)
            return
        end
        for _, r in ipairs(placedList) do
            if r.id == u.id then
                r.x, r.y, r.z = x + 0.0, y + 0.0, z + 0.0
                r.heading, r.pitch, r.roll = h + 0.0, p + 0.0, ro + 0.0
                patch[#patch + 1] = {
                    id = r.id,
                    model = r.model,
                    x = r.x, y = r.y, z = r.z,
                    heading = r.heading, pitch = r.pitch, roll = r.roll,
                    assemblyId = r.assemblyId,
                }
                break
            end
        end
    end

    saveData()
    TriggerClientEvent("prop_gizmo:patchPlacedPropTransforms", -1, patch)
    TriggerClientEvent("prop_gizmo:clientNotify", src, srvAsmMsg("Assembly placement saved.", "Положение сборки сохранено."), 4500)
end)

RegisterNetEvent("prop_gizmo:setPropGroup", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then return end
    local id = data.id
    local g = data.group
    if type(id) ~= "string" then return end
    if g == nil then g = "" end
    if type(g) ~= "string" then return end
    if not validGroupName(g) then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Invalid group name.", 4000)
        return
    end
    g = g:match("^%s*(.-)%s*$") or ""
    for _, r in ipairs(placedList) do
        if r.id == id then
            if g == "" then
                r.group = nil
            else
                r.group = g
            end
            saveData()
            TriggerClientEvent("prop_gizmo:updatePropGroup", -1, id, r.group or "")
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Group updated.", 3000)
            return
        end
    end
end)

RegisterNetEvent("prop_gizmo:createPlacedFolder", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    local name = type(data) == "table" and data.name or ""
    if type(name) ~= "string" then return end
    name = name:match("^%s*(.-)%s*$") or ""
    if name == "" then return end
    if not validGroupName(name) then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Invalid folder name.", 4000)
        return
    end
    local nl = name:lower()
    for _, f in ipairs(placedFolders) do
        if type(f) == "table" and type(f.name) == "string" and f.name:lower() == nl then
            TriggerClientEvent("prop_gizmo:clientNotify", src, "A folder with that name already exists.", 4000)
            return
        end
    end
    local id = newPlacedFolderId()
    placedFolders[#placedFolders + 1] = { id = id, name = name, propIds = {} }
    saveFoldersData()
    syncFoldersToClient(nil)
    TriggerClientEvent("prop_gizmo:clientNotify", src, "Folder created.", 2500)
end)

RegisterNetEvent("prop_gizmo:addPlacedPropToFolder", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then return end
    local folderId = data.folderId
    local propId = data.propId
    if type(folderId) ~= "string" or type(propId) ~= "string" then return end
    local f = findFolderById(folderId)
    if not f then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Folder not found.", 3000)
        return
    end
    if not placedPropEntryExists(propId) then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "That prop is not in the placed list.", 4000)
        return
    end
    if type(f.propIds) ~= "table" then f.propIds = {} end
    for _, pid in ipairs(f.propIds) do
        if pid == propId then
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Already in that folder.", 2500)
            return
        end
    end
    f.propIds[#f.propIds + 1] = propId
    saveFoldersData()
    syncFoldersToClient(nil)
    TriggerClientEvent("prop_gizmo:clientNotify", src, "Added to folder.", 2500)
end)

RegisterNetEvent("prop_gizmo:removePlacedPropFromFolder", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then return end
    local folderId = data.folderId
    local propId = data.propId
    if type(folderId) ~= "string" or type(propId) ~= "string" then return end
    local f = findFolderById(folderId)
    if not f or type(f.propIds) ~= "table" then return end
    local removed = false
    for i = #f.propIds, 1, -1 do
        if f.propIds[i] == propId then
            table.remove(f.propIds, i)
            removed = true
        end
    end
    if removed then
        saveFoldersData()
        syncFoldersToClient(nil)
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Removed from folder.", 2500)
    end
end)

RegisterNetEvent("prop_gizmo:deletePlacedFolder", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" or type(data.folderId) ~= "string" then return end
    for i, f in ipairs(placedFolders) do
        if type(f) == "table" and f.id == data.folderId then
            table.remove(placedFolders, i)
            saveFoldersData()
            syncFoldersToClient(nil)
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Folder deleted.", 2500)
            return
        end
    end
end)

RegisterNetEvent("prop_gizmo:setPersistedPlayerSkin", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then return end
    local model = data.model
    if not validPedModelForSkin(model) then
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Неверная модель педа для скина.", 5000)
        return
    end
    local instant = true
    local adminName = GetPlayerName(src) or "?"
    local tid = tonumber(data.targetServerId)
    if tid and tid > 0 and tid < 2048 and GetPlayerName(tid) then
        persistSkinForSource(tid, model)
        TriggerClientEvent("prop_gizmo:applyPersistedSkin", tid, model, instant)
        pushSkinHistory({
            ts = os.time(),
            admin = adminName,
            target = "server",
            targetName = GetPlayerName(tid) or ("#" .. tostring(tid)),
            model = model,
        })
        TriggerClientEvent(
            "prop_gizmo:clientNotify",
            src,
            ("Скин сохранён для игрока #%d и применён."):format(tid),
            5000
        )
        return
    end
    local targetSteam = data.targetSteam
    if type(targetSteam) == "string" and targetSteam:match("%S") then
        local sk = normalizeSteamKey(targetSteam)
        if not sk then
            TriggerClientEvent(
                "prop_gizmo:clientNotify",
                src,
                "Steam: вставьте полный steam:1100001… из F8 (после steam: допускаются цифры и a–f).",
                8000
            )
            return
        end
        playerSkinByKey[sk] = model
        saveSkinData()
        local tgt = findOnlinePlayerBySteamKey(sk)
        if tgt then
            TriggerClientEvent("prop_gizmo:applyPersistedSkin", tgt, model, instant)
            pushSkinHistory({
                ts = os.time(),
                admin = adminName,
                target = "steam",
                targetName = GetPlayerName(tgt) or "?",
                model = model,
            })
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Скин сохранён и применён к игроку в сети.", 5000)
        else
            pushSkinHistory({
                ts = os.time(),
                admin = adminName,
                target = "steam",
                targetName = "не в сети",
                model = model,
            })
            TriggerClientEvent("prop_gizmo:clientNotify", src, "Скин сохранён. Игрок не в сети — применится при входе.", 6000)
        end
        return
    end
    persistSkinForSource(src, model)
    TriggerClientEvent("prop_gizmo:applyPersistedSkin", src, model, instant)
    pushSkinHistory({
        ts = os.time(),
        admin = adminName,
        target = "self",
        targetName = GetPlayerName(src) or "?",
        model = model,
    })
    TriggerClientEvent("prop_gizmo:clientNotify", src, "Ваш скин сохранён и применён.", 5000)
end)

local function buildSkinRosterPayload()
    local online = {}
    for _, sid in ipairs(GetPlayers()) do
        local pid = tonumber(sid)
        if pid then
            local m = pickPersistedModelForSource(pid)
            if m then
                online[#online + 1] = {
                    serverId = pid,
                    name = GetPlayerName(pid) or ("#" .. tostring(pid)),
                    model = m,
                }
            end
        end
    end
    return { online = online, history = skinHistory }
end

RegisterNetEvent("prop_gizmo:requestSkinRoster", function()
    local src = source
    if not isAllowedSource(src) then return end
    TriggerClientEvent("prop_gizmo:skinRosterData", src, buildSkinRosterPayload())
end)

RegisterNetEvent("prop_gizmo:clearPersistedPlayerSkin", function(data)
    local src = source
    if not isAllowedSource(src) then return end
    if type(data) ~= "table" then data = {} end
    local adminName = GetPlayerName(src) or "?"
    local tid = tonumber(data.targetServerId)
    if tid and tid > 0 and tid < 2048 and GetPlayerName(tid) then
        clearPersistedSkinKeysForSource(tid)
        TriggerClientEvent("prop_gizmo:clearPersistedSkinApply", tid)
        pushSkinHistory({
            ts = os.time(),
            admin = adminName,
            target = "clear",
            targetName = GetPlayerName(tid) or ("#" .. tostring(tid)),
            model = "—",
        })
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Сохранённый скин снят: игрок вернёт обычный облик.", 5000)
        TriggerClientEvent("prop_gizmo:skinRosterData", src, buildSkinRosterPayload())
        return
    end
    local sk = normalizeSteamKey(type(data.targetSteam) == "string" and data.targetSteam or "")
    if sk then
        local tgt = findOnlinePlayerBySteamKey(sk)
        if tgt then
            clearPersistedSkinKeysForSource(tgt)
            TriggerClientEvent("prop_gizmo:clearPersistedSkinApply", tgt)
        else
            if playerSkinByKey[sk] ~= nil then
                playerSkinByKey[sk] = nil
                saveSkinData()
            end
        end
        pushSkinHistory({
            ts = os.time(),
            admin = adminName,
            target = "clear",
            targetName = tgt and (GetPlayerName(tgt) or "?") or "офлайн",
            model = "—",
        })
        TriggerClientEvent("prop_gizmo:clientNotify", src, "Запись скина удалена (steam). Если игрок был онлайн — облик сброшен.", 6000)
        TriggerClientEvent("prop_gizmo:skinRosterData", src, buildSkinRosterPayload())
        return
    end
    clearPersistedSkinKeysForSource(src)
    TriggerClientEvent("prop_gizmo:clearPersistedSkinApply", src)
    pushSkinHistory({
        ts = os.time(),
        admin = adminName,
        target = "clear",
        targetName = adminName,
        model = "—",
    })
    TriggerClientEvent("prop_gizmo:clientNotify", src, "Ваш сохранённый скин удалён. Восстановлен облик персонажа.", 5000)
    TriggerClientEvent("prop_gizmo:skinRosterData", src, buildSkinRosterPayload())
end)

RegisterNetEvent("prop_gizmo:requestMySkin", function()
    local src = source
    local m = pickPersistedModelForSource(src)
    if m and validPedModelForSkin(m) then
        TriggerClientEvent("prop_gizmo:applyPersistedSkin", src, m, false)
    end
end)

loadData()
loadBlipCatalog()
loadBlipsData()
loadPedsCatalogSet()
loadSkinData()
loadSkinHistory()
loadFoldersData()

if Config.SpooniFetchCatalogOnResourceStart then
    CreateThread(function()
        Wait(4000)
        tryFetchSpooniCatalog()
    end)
end
