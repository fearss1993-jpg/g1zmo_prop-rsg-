--- Свободная скриптовая камера для облёта карты (движение, обзор, скорость).

local RES = GetCurrentResourceName()

local fcCam = nil
local fcActive = false
local fcPed = nil
local fcFreezePed = true
local fcHidePed = false
local fcSpeed = 0.12

local CTRL = {
    SPEED_UP = { `INPUT_CREATOR_LT`, `INPUT_PREV_WEAPON` },
    SPEED_DOWN = { `INPUT_CREATOR_RT`, `INPUT_NEXT_WEAPON` },
    UP = `INPUT_JUMP`,
    DOWN = `INPUT_SPRINT`,
    FWD = `INPUT_MOVE_UP_ONLY`,
    BACK = `INPUT_MOVE_DOWN_ONLY`,
    LEFT = `INPUT_MOVE_LEFT_ONLY`,
    RIGHT = `INPUT_MOVE_RIGHT_ONLY`,
    STOP = `INPUT_FRONTEND_DELETE`,
    LOOK_LR = `INPUT_LOOK_LR`,
    LOOK_UD = `INPUT_LOOK_UD`,
}

local function cfgNum(key, fallback)
    if type(Config) ~= "table" then return fallback end
    local v = Config[key]
    return (type(v) == "number" and v == v and v >= 0) and v or fallback
end

local function cfgBool(key, fallback)
    if type(Config) ~= "table" then return fallback end
    if Config[key] == nil then return fallback end
    return Config[key] == true
end

local function checkControls(pred, controls)
    if type(controls) == "number" then
        return pred(0, controls)
    end
    if type(controls) == "table" then
        for _, c in ipairs(controls) do
            if pred(0, c) then return true end
        end
    end
    return false
end

local function drawBottomHint(txt)
    if type(txt) ~= "string" or txt == "" then return end
    DisplayText(CreateVarString(10, "LITERAL_STRING", txt), 0.5, 0.86)
end

local function fcDisable(reason)
    if not fcActive and not fcCam then return end
    fcActive = false

    local ped = PlayerPedId()
    if fcCam then
        RenderScriptCams(false, true, 400, true, true)
        SetCamActive(fcCam, false)
        DestroyCam(fcCam, true)
        fcCam = nil
    end
    ClearFocus()
    if ped and ped ~= 0 then
        FreezeEntityPosition(ped, false)
        if fcHidePed then
            SetEntityVisible(ped, true, false)
            pcall(NetworkSetEntityInvisibleToNetwork, ped, false)
        end
    end
    fcPed = nil
    TriggerEvent("prop_gizmo:freeCamStopped", reason or "")
end

local function vec3Unpack(v, fallbackPed)
    local x, y, z
    if type(v) == "vector3" or (type(v) == "userdata" and v.x and v.y and v.z) then
        x, y, z = v.x + 0.0, v.y + 0.0, v.z + 0.0
    elseif type(v) == "table" then
        x, y, z = tonumber(v[1]), tonumber(v[2]), tonumber(v[3])
        if x and y and z then x, y, z = x + 0.0, y + 0.0, z + 0.0 end
    end
    if (not x or not y or not z) and fallbackPed and fallbackPed ~= 0 then
        local c = GetEntityCoords(fallbackPed)
        x, y, z = c.x + 0.0, c.y + 0.0, (c.z + 1.5)
    elseif not x then
        x, y, z = 0.0, 0.0, 0.0
    end
    return x, y, z
end

local function rot3Unpack(v, ped)
    local pitch, roll, yaw = 0.0, 0.0, 0.0
    if type(v) == "vector3" or (type(v) == "userdata" and v.x and v.y and v.z) then
        pitch, roll, yaw = v.x + 0.0, v.y + 0.0, v.z + 0.0
    elseif type(v) == "table" then
        pitch = tonumber(v[1]) or 0.0
        roll = tonumber(v[2]) or 0.0
        yaw = tonumber(v[3]) or 0.0
    end
    return pitch, roll, yaw
end

local function fcEnable()
    if not cfgBool("FreeCamEnabled", true) then return end
    fcSpeed = cfgNum("FreeCamDefaultSpeed", 0.12)
    local smin = cfgNum("FreeCamMinSpeed", 0.02)
    local smax = cfgNum("FreeCamMaxSpeed", 2.0)
    if fcSpeed < smin then fcSpeed = smin end
    if fcSpeed > smax then fcSpeed = smax end

    fcFreezePed = cfgBool("FreeCamFreezePed", true)
    fcHidePed = cfgBool("FreeCamHidePed", false)

    local ped = PlayerPedId()
    fcPed = ped
    local cx, cy, cz = vec3Unpack(GetGameplayCamCoord(), ped)
    local pitch, roll, yaw = rot3Unpack(GetGameplayCamRot(2), ped)
    local fov = tonumber(GetGameplayCamFov()) or 50.0

    fcCam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    local camBad = (not fcCam or fcCam == 0)
    if not camBad and type(DoesCamExist) == "function" then
        local okDex, dex = pcall(DoesCamExist, fcCam)
        if okDex and dex == false then
            camBad = true
        end
    end
    if camBad then
        TriggerEvent(
            "prop_gizmo:freecamNotify",
            Config.Language == "ru" and "Не удалось создать камеру." or "Could not create camera.",
            7000
        )
        fcCam = nil
        fcActive = false
        fcPed = nil
        return
    end

    SetCamCoord(fcCam, cx, cy, cz)
    SetCamRot(fcCam, pitch, roll, yaw, 2)
    SetCamFov(fcCam, fov + 0.0)
    --- Как в типичном RDR паттерне: активируем затем включаем рендер.
    SetCamActive(fcCam, true)
    RenderScriptCams(true, true, 450, true, true)

    fcActive = true

    if ped and ped ~= 0 then
        if fcFreezePed then
            FreezeEntityPosition(ped, true)
        end
        if fcHidePed then
            SetEntityVisible(ped, false, false)
            pcall(NetworkSetEntityInvisibleToNetwork, ped, true)
        end
    end

    TriggerEvent(
        "prop_gizmo:freecamNotify",
        (Config.Language == "ru") and "Свободная камера. Del — выход. Колёсо мыши / PgUp PgDn — скорость."
            or "Free camera. Del — exit. Scroll / Page Up Down — speed.",
        8500
    )
end

function PropGizmo_IsFreeCamActive()
    return fcActive == true
end

local function fcApplyNotify(str, ms)
    TriggerEvent("prop_gizmo:freecamNotify", str, tonumber(ms) or 5000)
end

local function fcRunLoop()
    local spin = cfgNum("FreeCamSpeedInc", 0.02)
    local spdLr = cfgNum("FreeCamLookMultLr", 8.0)
    local spdUd = cfgNum("FreeCamLookMultUd", 8.0)
    local smin = cfgNum("FreeCamMinSpeed", 0.02)
    local smax = cfgNum("FreeCamMaxSpeed", 2.0)
    local stopHash = `INPUT_FRONTEND_DELETE`
    if type(Config) == "table" and type(Config.FreeCamStopControl) == "number" then
        stopHash = Config.FreeCamStopControl
    end
    local ru = (Config.Language == "ru")

    while fcActive and fcCam do
        DisableAllControlActions(0)
        EnableControlAction(0, `INPUT_FRONTEND_PAUSE_ALTERNATE`, true)
        EnableControlAction(0, `INPUT_MP_TEXT_CHAT_ALL`, true)

        local x1, y1, z1 = vec3Unpack(GetCamCoord(fcCam), fcPed)
        local pitch1, _, yaw1 = rot3Unpack(GetCamRot(fcCam, 2), fcPed)
        local x2, y2, z2 = x1, y1, z1
        local pitch2, yaw2 = pitch1, yaw1

        if checkControls(IsDisabledControlPressed, CTRL.SPEED_UP) then
            fcSpeed = fcSpeed + spin
        end
        if checkControls(IsDisabledControlPressed, CTRL.SPEED_DOWN) then
            fcSpeed = fcSpeed - spin
        end
        if fcSpeed < smin then fcSpeed = smin elseif fcSpeed > smax then fcSpeed = smax end

        if IsDisabledControlPressed(0, CTRL.UP) then
            z2 = z2 + fcSpeed
        end
        if IsDisabledControlPressed(0, CTRL.DOWN) then
            z2 = z2 - fcSpeed
        end

        local ax = GetDisabledControlNormal(0, CTRL.LOOK_LR)
        local ay = GetDisabledControlNormal(0, CTRL.LOOK_UD)
        if ax ~= 0.0 or ay ~= 0.0 then
            yaw2 = yaw2 + ax * -1.0 * spdUd
            pitch2 = math.max(-89.5, math.min(89.5, pitch2 + ay * -1.0 * spdLr))
        end

        local r1 = -yaw2 * math.pi / 180.0
        local dx1 = fcSpeed * math.sin(r1)
        local dy1 = fcSpeed * math.cos(r1)
        local r2 = math.floor(yaw2 + 90.0) % 360 * -1.0 * math.pi / 180.0
        local dx2 = fcSpeed * math.sin(r2)
        local dy2 = fcSpeed * math.cos(r2)

        if IsDisabledControlPressed(0, CTRL.FWD) then
            x2, y2 = x2 + dx1, y2 + dy1
        end
        if IsDisabledControlPressed(0, CTRL.BACK) then
            x2, y2 = x2 - dx1, y2 - dy1
        end
        if IsDisabledControlPressed(0, CTRL.LEFT) then
            x2, y2 = x2 + dx2, y2 + dy2
        end
        if IsDisabledControlPressed(0, CTRL.RIGHT) then
            x2, y2 = x2 - dx2, y2 - dy2
        end

        SetCamCoord(fcCam, x2, y2, z2)
        SetCamRot(fcCam, pitch2, 0.0, yaw2, 2)

        RequestCollisionAtCoord(x2, y2, z2)

        if IsDisabledControlJustPressed(0, stopHash) then
            fcDisable("toggle")
            break
        end

        drawBottomHint(string.format(
            ru and "~o~Свободная камера~s~  |  Del выход  |  W/A/S/D  |  Пролёт/Присесть вверх-вниз  |  ~y~%.2f"
                or "~o~Free cam~s~  |  Del exit  |  W/A/S/D  |  Jump/Sprint up-down  |  ~y~%.2f",
            fcSpeed
        ))

        Wait(0)
    end
end

AddEventHandler("prop_gizmo:requestStopFreecam", function()
    fcDisable("request")
end)

AddEventHandler("prop_gizmo:freecamStart", function()
    if not cfgBool("FreeCamEnabled", true) then
        fcApplyNotify(Config.Language == "ru" and "Режим отключён в config." or "Disabled in config.", 4000)
        return
    end
    if fcActive then return end
    fcEnable()
    CreateThread(fcRunLoop)
end)

RegisterCommand("prop_gizmo_freecam", function()
    if not cfgBool("FreeCamEnabled", true) then return end
    if fcActive then
        fcDisable("command")
        return
    end
    fcEnable()
    CreateThread(fcRunLoop)
end, false)

CreateThread(function()
    local desc = Config.Language == "ru" and "Gizmo — свободная камера" or "Gizmo — free camera"
    RegisterKeyMapping("prop_gizmo_freecam", desc, "keyboard", "f6")
end)

AddEventHandler("onResourceStop", function(name)
    if name ~= RES then return end
    fcDisable("resource_stop")
end)
